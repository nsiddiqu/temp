Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "SELECT top 1000 cast(SERVERPROPERTY('ServerName') as varchar) [SQL_Instance_Name],''[AlwaysOn], cast(getdate() as smalldatetime) as [Pull_Time], qv.spid [SessionID], qv.status, blocked [Blocking_Session]
        ,qv.open_tran,login_name,qv.cmd, qv.lastwaittype AS [Last_Wait_Type], qv.waittime AS [WaitTime]
        ,case when [host_name] like '%.%' and ISNUMERIC(LEFT([host_name], 1)) <> 1 then (replace ([host_name],(Select substring([host_name],charindex('.',[host_name]),len([host_name]))),'')) else [host_name] end AS [Host]
        ,qa.program_name AS [Program],cast(last_batch as smalldatetime)[last_batch]
        ,db_name(qv.dbid) [Database_Name], client_interface_name,cast(qa.login_time as smalldatetime)[login_time]
	    FROM [master].[dbo].[sysprocesses] qv with (nolock)
        inner JOIN sys.dm_exec_sessions qa with (nolock)
        On qa.session_id = qv.spid
	    where qa.session_id <> @@SPID and qa.session_id > 50 and login_name not like 'NT %' and [host_name] is not null
        order by qa.login_time desc" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Sessions_Catalog_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 90 -ErrorAction SilentlyContinue

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Sessions_Catalog_Current]
        ([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[SessionID],[status],[Blocking_Session],[open_tran],[login_name],[cmd],[Last_Wait_Type],[WaitTime],[Host],[Program]
        ,[last_batch],[Database_Name],[client_interface_name],[login_time]) VALUES
        ('"+$resultList.SQL_Instance_Name+"','"+$resultList.AlwaysOn +"',cast(getdate() as smalldatetime),'"+$resultList.SessionID+"','"+$resultList.status+"','"+$resultList.Blocking_Session+"'
        ,'"+$resultList.open_tran+"','"+$resultList.login_name+"','"+$resultList.cmd+"','"+$resultList.Last_Wait_Type+"','"+$resultList.WaitTime+"','"+$resultList.Host+"'
        ,'"+$resultList.Program+"','"+$resultList.last_batch+"','"+$resultList.Database_Name+"','"+$resultList.client_interface_name+"','"+$resultList.login_time+"')"
        Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Sessions_Catalog_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Sessions_Catalog] select * from [DBA_Watcher_DB].[General].[SQL_Sessions_Catalog_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'


Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Sessions_Login_History] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 90 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Sessions_Login_History]
        SELECT distinct [SQL_Instance_Name],[Pull_Time],[login_name],[Host],[Program],[Database_Name],[client_interface_name],Max([login_time])[Last_Login]
        ,count([login_time])[Login_Count]
        FROM [DBA_Watcher_DB].[General].[SQL_Sessions_Catalog_Current] with (nolock)
        where SQL_Instance_Name not like host and host not like '' and login_name not like 'SVC_ORX_Reporting' and Program not like '%SQL IntelliSense%'
        and login_time > DATEADD(minute, -5,  Pull_Time) and SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])
        group by [SQL_Instance_Name],[Pull_Time],[login_name],[Host],[Program],[Database_Name],[client_interface_name]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

Invoke-Sqlcmd -Query "Declare @month varchar(20)
        Declare @sql nvarchar(1000)
        Set @month = (SELECT convert(varchar(7), getdate(), 126))

        if not exists(select * FROM DBA_Watcher_DB.INFORMATION_SCHEMA.COLUMNS where TABLE_NAME like 'SQL_Sessions_Login_History' AND [COLUMN_NAME] = (SELECT convert(varchar(7), getdate(), 126)))
	    BEGIN
	    SET @sql = 'ALTER TABLE [DBA_Watcher_DB].[General].[SQL_Sessions_Login_History] ADD [' + @month + '] [bigint] NULL default 0'
	    EXEC sp_executesql @sql
	    SET @sql = 'update [DBA_Watcher_DB].[General].[SQL_Sessions_Login_History] set [' + @month + '] = 0  where [' + @month + '] is NULL'
	    EXEC sp_executesql @sql
	    END

	    SET @sql = 'Merge into [DBA_Watcher_DB].[General].[SQL_Sessions_Login_History] AS t 
		using (select * from [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Sessions_Login_History] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])) as s 
		on t.[SQL_Instance_Name] = s.[SQL_Instance_Name] and t.loginname = s.loginname and t.[Host] = s.[Host] and t.[Program] = s.[Program] 
		and t.[Database_Name] = s.[Database_Name] and t.[client_interface_name] = s.[client_interface_name] 
		when matched then 
		update set t.[' + @month + '] = t.[' + @month + '] + s.[Login_Count], t.[LastLogin]= s.[Last_Login]
		when not matched then 
		INSERT([SQL_Instance_Name],[loginname],[Host],[Program],[Database_Name],[client_interface_name], [LastLogin]) VALUES (s.[SQL_Instance_Name],s.[loginname]
		,s.[Host],s.[Program],s.[Database_Name],s.[client_interface_name],s.[Last_Login]);'
	    EXEC sp_executesql @sql" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'


