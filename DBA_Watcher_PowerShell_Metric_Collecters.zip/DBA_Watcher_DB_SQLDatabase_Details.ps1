Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "Select cast(SERVERPROPERTY('ServerName') as varchar) [SQL_Instance_Name], ''[AlwaysOn], cast(getdate() as smalldatetime) as [Pull_Time], rtrim(myPiv.database_name) as [Database_name]
,[compatibility_level],[recovery_model_desc],Data_Size_GB = CASE WHEN [Data File(s) Size (KB)]  = 0 THEN 0 ELSE round(cast([Data File(s) Size (KB)] as float) / 1048576, 2) END 
,Log_Size_GB = CASE WHEN [Log File(s) Size (KB)]  = 0 THEN 0 ELSE round(cast([Log File(s) Size (KB)] as float) / 1048576, 2) END 
,Log_Used_Size_GB = CASE WHEN [Log File(s) Used Size (KB)]  = 0 THEN 0 ELSE round(cast([Log File(s) Used Size (KB)] as float)/ 1048576, 2) END ,[Percent Log Used] as [Percent_Log_Used]
,[log_reuse_wait_desc],  [state_desc],[is_read_only] = CASE WHEN [is_read_only] = 1 THEN 'Read Only' ELSE '' END,[user_access_desc],[snapshot_isolation_state_desc],[is_read_committed_snapshot_on]
,[Active Transactions] as [Active_Transactions],[Transactions/sec] as [Transactions_sec],[Repl. Trans. Rate] as [Repl_Trans_Rate],[Backup/Restore Throughput/sec] as [Backup_Restore_Throughput_sec]
,[DBCC Logical Scan Bytes/sec] as [DBCC_Logical_Scan_Bytes_sec],[Log Growths] as [Log_Growths],[Query Store physical reads] as [Query_Store_physical_reads],[Query Store logical reads] as [Query_Store_logical_reads]
,[Query Store logical writes] as [Query_Store_logical_writes],[Query Store CPU usage] as [Query_Store_CPU_usage],cast([create_date] as smalldatetime)[create_date],[collation_name],[page_verify_option_desc],[is_in_standby],[is_cleanly_shutdown]
,[is_auto_create_stats_on],[is_auto_update_stats_on],[is_auto_update_stats_async_on],[is_ansi_null_default_on],[is_ansi_nulls_on],[is_ansi_padding_on],[is_ansi_warnings_on]
,[is_arithabort_on],[is_concat_null_yields_null_on],[is_numeric_roundabort_on],[is_quoted_identifier_on],[is_fulltext_enabled],[is_trustworthy_on],[is_parameterization_forced]
,[is_master_key_encrypted_by_server],[is_published],[is_subscribed],[is_distributor],[is_broker_enabled],[is_auto_close_on],[is_auto_shrink_on],[is_supplemental_logging_enabled]
,[is_merge_published],[is_date_correlation_on],[is_cdc_enabled],[is_encrypted],[target_recovery_time_in_seconds],cast([is_query_store_on] as int) [is_query_store_on]
From [master].[sys].[databases] d
left outer join (select instance_Name as database_name, counter_name, cntr_value
   From sys.dm_os_performance_counters where object_name like '%Databases%') X
  Pivot (Max(cntr_value) For counter_name
In ([Data File(s) Size (KB)],[Log File(s) Size (KB)],[Log File(s) Used Size (KB)],[Percent Log Used],[Active Transactions],[Transactions/sec]     
,[Repl. Pending Xacts],[Repl. Trans. Rate],[Log Cache Reads_sec],[Bulk Copy Rows/sec],[Bulk Copy Throughput/sec]   
,[Backup/Restore Throughput/sec],[DBCC Logical Scan Bytes/sec],[Shrink Data Movement Bytes/sec],[Log Flushes/sec],[Log Bytes Flushed/sec],[Log Flush Waits/sec]
,[Log Flush Wait Time],[Log Truncations],[Log Growths],[Log Shrinks])) myPiv on myPiv.database_name = d.name and myPiv.database_name not like 'mssqlsystemresource%'
left outer join (select instance_Name as database_name, counter_name, cntr_value
   From sys.dm_os_performance_counters where object_name like '%Query Store%') Xx
  Pivot (Max(cntr_value) For counter_name
In ([Query Store CPU usage],[Query Store physical reads],[Query Store logical reads],[Query Store logical writes])) myPiv2 on myPiv2.database_name = d.name" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Database_Details_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Database_Details_Current]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[Database_name],[compatibility_level],[recovery_model_desc]
,[Data_Size_GB],[Log_Size_GB],[Log_Used_Size_GB],[Percent_Log_Used],[log_reuse_wait_desc],[state_desc],[is_read_only],[user_access_desc],[snapshot_isolation_state_desc]
,[is_read_committed_snapshot_on],[Active_Transactions],[Transactions_sec],[Repl_Trans_Rate],[Backup_Restore_Throughput_sec],[DBCC_Logical_Scan_Bytes_sec]
,[Log_Growths],[Query_Store_physical_reads],[Query_Store_logical_reads],[Query_Store_logical_writes],[Query_Store_CPU_usage],[create_date],[collation_name]
,[page_verify_option_desc],[is_in_standby],[is_cleanly_shutdown],[is_auto_create_stats_on],[is_auto_update_stats_on],[is_auto_update_stats_async_on]
,[is_ansi_null_default_on],[is_ansi_nulls_on],[is_ansi_padding_on],[is_ansi_warnings_on],[is_arithabort_on],[is_concat_null_yields_null_on],[is_numeric_roundabort_on]
,[is_quoted_identifier_on],[is_fulltext_enabled],[is_trustworthy_on],[is_parameterization_forced],[is_master_key_encrypted_by_server],[is_published]
,[is_subscribed],[is_distributor],[is_broker_enabled],[is_auto_close_on],[is_auto_shrink_on],[is_supplemental_logging_enabled],[is_merge_published]
,[is_date_correlation_on],[is_cdc_enabled],[is_encrypted],[target_recovery_time_in_seconds],[is_query_store_on]) VALUES ('"+$resultList.SQL_Instance_Name +"','"+$resultList.AlwaysOn +"',cast(getdate() as smalldatetime)
,'"+$resultList.Database_name +"','"+$resultList.compatibility_level +"','"+$resultList.recovery_model_desc +"','"+$resultList.Data_Size_GB +"'
,'"+$resultList.Log_Size_GB +"','"+$resultList.Log_Used_Size_GB +"','"+$resultList.Percent_Log_Used +"','"+$resultList.log_reuse_wait_desc +"'
,'"+$resultList.state_desc +"','"+$resultList.is_read_only +"','"+$resultList.user_access_desc +"','"+$resultList.snapshot_isolation_state_desc +"'
,'"+$resultList.is_read_committed_snapshot_on +"','"+$resultList.Active_Transactions +"','"+$resultList.Transactions_sec +"','"+$resultList.Repl_Trans_Rate +"'
,'"+$resultList.Backup_Restore_Throughput_sec +"','"+$resultList.DBCC_Logical_Scan_Bytes_sec +"','"+$resultList.Log_Growths +"','"+$resultList.Query_Store_physical_reads +"'
,'"+$resultList.Query_Store_logical_reads +"','"+$resultList.Query_Store_logical_writes +"','"+$resultList.Query_Store_CPU_usage +"','"+$resultList.create_date +"'
,'"+$resultList.collation_name +"','"+$resultList.page_verify_option_desc +"','"+$resultList.is_in_standby +"','"+$resultList.is_cleanly_shutdown +"'
,'"+$resultList.is_auto_create_stats_on +"','"+$resultList.is_auto_update_stats_on +"','"+$resultList.is_auto_update_stats_async_on +"','"+$resultList.is_ansi_null_default_on +"'
,'"+$resultList.is_ansi_nulls_on +"','"+$resultList.is_ansi_padding_on +"','"+$resultList.is_ansi_warnings_on +"','"+$resultList.is_arithabort_on +"'
,'"+$resultList.is_concat_null_yields_null_on +"','"+$resultList.is_numeric_roundabort_on +"','"+$resultList.is_quoted_identifier_on +"','"+$resultList.is_fulltext_enabled +"'
,'"+$resultList.is_trustworthy_on +"','"+$resultList.is_parameterization_forced +"','"+$resultList.is_master_key_encrypted_by_server +"','"+$resultList.is_published +"'
,'"+$resultList.is_subscribed +"','"+$resultList.is_distributor +"','"+$resultList.is_broker_enabled +"','"+$resultList.is_auto_close_on +"','"+$resultList.is_auto_shrink_on +"'
,'"+$resultList.is_supplemental_logging_enabled +"','"+$resultList.is_merge_published +"','"+$resultList.is_date_correlation_on +"','"+$resultList.is_cdc_enabled +"'
,'"+$resultList.is_encrypted +"', '"+$resultList.target_recovery_time_in_seconds +"', '"+$resultList.is_query_store_on +"')" 
Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 30 -ErrorAction SilentlyContinue 
}

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Database_Details_Raw] select * from [DBA_Watcher_DB].[General].[SQL_Database_Details_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "update y
set y.Transactions_sec = abs((y.Transactions_sec - x.Transactions_sec) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)),
y.Backup_Restore_Throughput_sec = abs((y.Backup_Restore_Throughput_sec - x.Backup_Restore_Throughput_sec) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)),
y.DBCC_Logical_Scan_Bytes_sec =  abs((y.DBCC_Logical_Scan_Bytes_sec - x.DBCC_Logical_Scan_Bytes_sec) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time))
from [DBA_Watcher_DB].[General].[SQL_Database_Details_Current] y (nolock)
Inner join [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Database_Details] x (nolock) on y.SQL_Instance_Name = x.SQL_Instance_Name and y.Database_name = x.Database_name
where y.pull_time != x.Pull_Time" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Database_Details_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Database_Details] select * from [DBA_Watcher_DB].[General].[SQL_Database_Details_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue
Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Database_Details] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue
Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Database_Details] select * from [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Database_Details_Raw] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Database_Details_Raw] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

