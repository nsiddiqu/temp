Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "DECLARE @ts_now BIGINT
    SELECT @ts_now = cpu_ticks / CONVERT(FLOAT, (cpu_ticks / ms_ticks)) FROM sys.dm_os_sys_info
	SELECT top (5) cast(SERVERPROPERTY('ServerName') as varchar)[SQL_Instance_Name],''[AlwaysOn], cast(getdate() as smalldatetime)[Pull_Time]
	,cast(DATEADD(ms, -1 * (@ts_now - [TIMESTAMP]), GETDATE() AT TIME ZONE 'Central Standard Time') as smalldatetime) AS Collection_Time, SQLProcessUtilization
	,SystemIdle, 100 - SystemIdle - SQLProcessUtilization AS OtherProcessUtilization, [PageFaults], SQLMemoryUtilization 
		FROM (SELECT record.value('(./Record/@id)[1]', 'int') AS record_id,
				record.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int') AS SystemIdle,
				record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') AS SQLProcessUtilization,
				record.value('(./Record/SchedulerMonitorEvent/SystemHealth/MemoryUtilization)[1]', 'int') AS SQLMemoryUtilization,
				record.value('(//Record/SchedulerMonitorEvent/SystemHealth/PageFaults) [1]', 'bigint') AS [PageFaults],   
			TIMESTAMP FROM (SELECT TIMESTAMP, CONVERT(XML, record) AS record FROM sys.dm_os_ring_buffers 
			WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR' AND record LIKE '%<SystemHealth>%') AS x
    ) AS y ORDER BY record_id DESC" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Statistics_CPU_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Statistics_CPU_Current]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[Collection_Time],[SQLProcessUtilization]
        ,[SystemIdle],[OtherProcessUtilization],[PageFaults],[SQLMemoryUtilization]) VALUES ('"+$resultList.SQL_Instance_Name+"','"+$resultList.AlwaysOn+"'
        ,cast(getdate() as smalldatetime),'"+$resultList.Collection_Time+"','"+$resultList.SQLProcessUtilization+"','"+$resultList.SystemIdle+"'
        ,'"+$resultList.OtherProcessUtilization+"','"+$resultList.PageFaults+"','"+$resultList.SQLMemoryUtilization+"')"
        Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 30 -ErrorAction SilentlyContinue 
}

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Statistics_CPU_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Statistics_CPU] 
        SELECT [SQL_Instance_Name] ,[AlwaysOn],max([Pull_Time]) as [Pull_Time],max([Collection_Time]) as [Collection_Time]
        ,avg([SQLProcessUtilization]) as [SQLProcessUtilization] ,avg([SystemIdle]) as [SystemIdle] ,avg([OtherProcessUtilization]) as [OtherProcessUtilization] 
        ,avg([PageFaults]) as [PageFaults] ,avg([SQLMemoryUtilization]) as [SQLMemoryUtilization]
        FROM [DBA_Watcher_DB].[General].[SQL_Statistics_CPU_Current] with (nolock)
        where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])
		group by [SQL_Instance_Name], [AlwaysOn]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

