Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "SELECT cast(SERVERPROPERTY('ServerName') as varchar) [SQL_Instance_Name],''[AlwaysOn], cast(getdate() as smalldatetime) as [Pull_Time], 
A.name as [Database_name], A.state_desc, A.recovery_model_desc as [Recovery], (SELECT CASE CAST(B.type AS CHAR(2)) WHEN 'D' THEN 'DB Full' WHEN 'I' THEN 'DB INCR' WHEN 'L' THEN 'DB Log' WHEN 'F' THEN 'DB File' ELSE 'None' END)[BackupType] ,
DATEDIFF ( DAY , MAX(B.backup_finish_date) , GETDATE()) as [Days_without_Backup], datediff (minute, MAX(B.backup_start_date) ,MAX(B.backup_finish_date)) as Backup_Duration_Min,
case when CHARINDEX('\',physical_device_name)=0 then case when CHARINDEX('-',physical_device_name)>1 then 'Virtual Path' else physical_device_name end else replace (physical_device_name, RIGHT(physical_device_name ,CHARINDEX('\',REVERSE(physical_device_name ))-1),'') end  as Backup_Path,
cast(MAX(B.backup_start_date) as smalldatetime) AS 'LastBackupStart', cast(MAX(B.backup_finish_date)as smalldatetime) AS 'LastBackupFinish'
,CAST(COALESCE(MAX(B.backup_size),0)/1024.00/1024.00/1024.00 AS NUMERIC(18,2)) [BackupSize_GB]
,CAST(COALESCE(MAX(B.compressed_backup_size),0)/1024.00/1024.00/1024.00 AS NUMERIC(18,2)) [compressed_backup_size_GB]
,CAST(COALESCE(MAX(B.backup_size),0)/1024.00/1024.00 AS NUMERIC(18,2)) [BackupSize_MB]
,CAST(COALESCE(MAX(B.compressed_backup_size),0)/1024.00/1024.00 AS NUMERIC(18,2)) [compressed_backup_size_MB]
FROM master.sys.databases A WITH(NOLOCK) 
left outer JOIN msdb.dbo.backupset B WITH(NOLOCK) ON A.name = B.database_name and B.backup_start_date >  GETDATE() -7
left outer JOIN msdb.dbo.backupmediafamily m WITH(NOLOCK) ON B.media_set_id = m.media_set_id
WHERE A.name not like 'tempdb' and 
A.name in (select name from master.sys.databases where is_read_only = 0 and user_access_desc = 'MULTI_USER' and name is not null) and 
A.name is not null and not exists (select * where B.type = 'L' and A.recovery_model_desc = 'SIMPLE') 
GROUP BY A.name, A.recovery_model_desc, A.state_desc, B.type,
case when CHARINDEX('\',physical_device_name)=0 then case when CHARINDEX('-',physical_device_name)>1 then 'Virtual Path' else physical_device_name end 
else replace (physical_device_name, RIGHT(physical_device_name ,CHARINDEX('\',REVERSE(physical_device_name ))-1),'') end
ORDER BY A.name, B.type;" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 20 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Database_Backup_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Database_Backup_Current]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[Database_name],[state_desc],[Recovery],[BackupType],[Days_without_Backup],[Backup_Duration_Min]
        ,[Backup_Path],[LastBackupStart],[LastBackupFinish],[BackupSize_GB],[compressed_backup_size_GB],[BackupSize_MB],[compressed_backup_size_MB]) VALUES
        ('"+$resultList.SQL_Instance_Name +"','"+$resultList.AlwaysOn +"','"+$resultList.Pull_Time +"','"+$resultList.Database_name +"','"+$resultList.state_desc +"'
        ,'"+$resultList.Recovery +"','"+$resultList.BackupType +"','"+$resultList.Days_without_Backup +"','"+$resultList.Backup_Duration_Min +"','"+$resultList.Backup_Path +"'
        ,'"+$resultList.LastBackupStart +"','"+$resultList.LastBackupFinish +"','"+$resultList.BackupSize_GB +"','"+$resultList.compressed_backup_size_GB +"','"+$resultList.BackupSize_MB +"'
        ,'"+$resultList.compressed_backup_size_MB +"')"
        Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 90 -ErrorAction stop 
}

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Database_Backup_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Database_Backup] select * from [DBA_Watcher_DB].[General].[SQL_Database_Backup_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

