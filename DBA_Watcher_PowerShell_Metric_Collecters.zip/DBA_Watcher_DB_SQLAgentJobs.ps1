Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "SELECT distinct cast(SERVERPROPERTY('ServerName') as varchar) [SQL_Instance_Name],''[AlwaysOn], cast(getdate() as smalldatetime) as [Pull_Time],j.enabled, cast(j.name as varchar) as 'JobName'
,js.step_id,cast(js.step_name as varchar) as step_name, js.last_run_outcome,CASE WHEN js.last_run_outcome = 0 and jh.message is null THEN 'Skipped' WHEN js.last_run_outcome = 0 and jh.message is not null THEN 'Failed' WHEN js.last_run_outcome = 1 THEN 'Success' 
	WHEN js.last_run_outcome = 2 THEN 'Retry' WHEN js.last_run_outcome = 3 THEN 'Cancelled' WHEN js.last_run_outcome = 5 THEN 'Unknown' END AS last_run_outcome_status
,replace(isnull(jh.message,''), '''','''''') as Message, CASE when ja.job_history_id is NULL and start_execution_date> getdate()-7 THEN 'Running' ELSE '' END as [Status],
datediff(minute, ja.start_execution_date, ja.stop_execution_date) as [Last_Job_Duration]
,(select AVG(((jh0.run_duration/10000*3600 + (jh0.run_duration/100)%100*60 + jh0.run_duration%100 + 31 ) / 60)) from msdb.dbo.sysjobhistory jh0 where js.job_id = jh0.job_id and 
js.step_id = jh0.step_id  and msdb.dbo.agent_datetime(jh0.run_date, jh0.run_time) > getdate() -30) as [AVG_Step_Duration_Min] 
,(select MAX(((jh0.run_duration/10000*3600 + (jh0.run_duration/100)%100*60 + jh0.run_duration%100 + 31 ) / 60)) from msdb.dbo.sysjobhistory jh0 where js.job_id = jh0.job_id and 
js.step_id = jh0.step_id and msdb.dbo.agent_datetime(jh0.run_date, jh0.run_time) > getdate() -30) as [Max_Step_Duration_Min] 
, cast(ja.start_execution_date as smalldatetime)as [start_execution_date],    cast(ja.stop_execution_date as smalldatetime) as [stop_execution_date],  cast(ja.next_scheduled_run_date as smalldatetime) as [next_scheduled_run_date]
FROM msdb.dbo.sysjobs j with(nolock)
JOIN msdb.dbo.sysjobsteps js with(nolock) ON j.job_id = js.job_id
left outer JOIN msdb.dbo.sysjobactivity ja with(nolock) ON ja.job_id = j.job_id 
left outer JOIN msdb.dbo.sysjobhistory jh with(nolock) ON jh.job_id = j.job_id  and jh.step_id = js.step_id and msdb.dbo.agent_datetime(jh.run_date, jh.run_time) > getdate() -7 and jh.message like '%fail%'
WHERE ja.start_execution_date is not null and ja.start_execution_date = (select MAX(ja2.start_execution_date) from msdb.dbo.sysjobactivity ja2 where ja2.job_id = j.job_id and ja2.start_execution_date is not null) 
order by JobName, step_id" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 15 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_AgentJobs_History] select distinct * from [DBA_Watcher_DB].[General].[SQL_AgentJobs] with (nolock) 
        where last_run_outcome_status not like '%Success%' and [stop_execution_date] > dateadd(minute, -10, GetDate()) and SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_AgentJobs] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_AgentJobs]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[enabled],[JobName],[step_id],[step_name],[last_run_outcome],[last_run_outcome_status],[Message]
        ,[Status],[Last_Job_Duration],[AVG_Step_Duration_Min],[Max_Step_Duration_Min],[start_execution_date],[stop_execution_date],[next_scheduled_run_date]) VALUES ('"+ $resultList.SQL_Instance_Name +"'
        ,'"+$resultList.AlwaysOn +"',cast(getdate() as smalldatetime),'"+ $resultList.enabled +"','"+ $resultList.JobName +"','"+ $resultList.step_id +"','"+ $resultList.step_name +"','"+ $resultList.last_run_outcome +"'
        ,'"+ $resultList.last_run_outcome_status +"','"+ $resultList.Message +"','"+ $resultList.Status +"','"+ $resultList.Last_Job_Duration +"','"+ $resultList.AVG_Step_Duration_Min +"'
        ,'"+ $resultList.Max_Step_Duration_Min +"','"+ $resultList.start_execution_date +"','"+ $resultList.stop_execution_date +"','"+ $resultList.next_scheduled_run_date +"')"
        Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 30 -ErrorAction SilentlyContinue 
}

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_AgentJobs] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue


