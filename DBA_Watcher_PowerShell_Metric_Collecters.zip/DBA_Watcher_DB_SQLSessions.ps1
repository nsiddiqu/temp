Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

# Create runspace pool
$runspacePool = [runspacefactory]::CreateRunspacePool(1, 20)
$runspacePool.Open()
$runspaces = @()


$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "SELECT cast(SERVERPROPERTY('ServerName') as varchar)[SQL_Instance_Name],''[AlwaysOn], cast(getdate() as smalldatetime)[Pull_Time], qv.spid [SessionID], trim(qv.status) as [status], blocking_session_id [Blocking_Session]
,(case when (er.session_id in (select blocked from [master].[dbo].[sysprocesses] with (nolock) where blocked <> 0) and blocking_session_id = 0) Then 'Lead' ELSE '' end ) AS [LeadBlocker],trim([waitresource])as [waitresource]
,qv.open_tran,login_name,trim(qv.cmd) as [cmd], Isnull(replace(est.text, '''',''),replace('[NO RUNNING SQL. LAST COMMAND RUN]  ' + cast(est2.text as varchar (2000)) +'', '''',''))  AS [Text], trim(qv.lastwaittype) AS [Last_Wait_Type]
, round(cast(qv.waittime as float)/1000,2) AS [WaitTime_Sec], qv.waittime AS [WaitTime],name[transaction] ,cast(transaction_begin_time as smalldatetime)[transaction_start_time]
,DATEDIFF(SECOND, transaction_begin_time, GETDATE())[transaction_time_sec], case transaction_type when 1 then 'Read/Write' when 2 then 'Read-Only' when 3 then 'System' when 4 then 'Distributed' else '' end [transaction_type],    
case transaction_state when 0 then 'Uninitialized' when 1 then 'Not Yet Started' when 2 then 'Active' when 3 then 'Ended (Read-Only)' when 4 then 'Committing' 
when 5 then 'Prepared' when 6 then 'Committed' when 7 then 'Rolling Back' when 8 then 'Rolled Back' else '' end [transaction_State]	,host_name AS [Host],qa.program_name AS [Program],cast(last_batch as smalldatetime)[last_batch]
,db_name(qv.dbid) [Database_Name], client_interface_name,  client_net_address, mg.requested_memory_kb,mg.max_used_memory_kb,qa.cpu_time AS [Session_CPU_Time], qa.memory_usage  AS [Session_Memory]
,qa.reads [Session_Reads], qa.writes [Session_Writes], percent_complete, estimated_completion_time, ROUND (CONVERT (FLOAT, (tsu.user_objects_alloc_page_count - tsu.user_objects_dealloc_page_count) * 8) / 1024.0, 2) AS [UserMB],
ROUND (CONVERT (FLOAT, (tsu.internal_objects_alloc_page_count - tsu.internal_objects_dealloc_page_count) * 8) / 1024.0, 2) AS [InternalMB], 	cast(qa.login_time as smalldatetime)[login_time]
	FROM [master].[dbo].[sysprocesses] qv with (nolock)
    inner JOIN sys.dm_exec_sessions qa with (nolock)
        On qa.session_id = qv.spid
	left outer join sys.dm_exec_requests er with (nolock)
		ON qa.session_id = er.session_id
	left outer join sys.dm_exec_connections ec with (nolock)
		ON qa.session_id = ec.session_id
	left outer join sys.dm_tran_session_transactions st with (nolock)
		ON qa.session_id = st.session_id
	left outer JOIN sys.dm_tran_active_transactions at with (nolock)
		ON st.transaction_id = at.transaction_id
	left outer JOIN sys.dm_exec_query_memory_grants mg with (nolock)
		ON qa.session_id = mg.session_id
	left outer join sys.dm_db_task_space_usage tsu with (nolock)
		ON qa.session_id = tsu.session_id
	outer APPLY sys.dm_exec_sql_text (er.sql_handle) est 
    outer APPLY sys.dm_exec_sql_text (most_recent_sql_handle) est2 
	where tsu.session_id <> @@SPID and qa.session_id > 50
	and (qa.status not like 'sleeping' or qv.open_tran >0) 
order by qv.spid" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 15 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Sessions_Details_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Sessions_Details_Current]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[SessionID],[status],[Blocking_Session],[LeadBlocker],[waitresource],[open_tran]
        ,[login_name],[cmd],[Text],[Last_Wait_Type],[WaitTime_Sec],[WaitTime],[transaction],[transaction_start_time],[transaction_time_sec],[transaction_type]
        ,[transaction_State],[Host],[Program],[last_batch],[Database_Name],[client_interface_name],[client_net_address],[requested_memory_kb],[max_used_memory_kb]
        ,[Session_CPU_Time],[Session_Memory],[Session_Reads],[Session_Writes],[percent_complete],[estimated_completion_time],[UserMB],[InternalMB],[login_time])
         VALUES ('"+$resultList.SQL_Instance_Name +"','"+$resultList.AlwaysOn +"',cast(getdate() as smalldatetime),'"+$resultList.SessionID +"','"+$resultList.status +"'
        ,'"+$resultList.Blocking_Session +"','"+$resultList.LeadBlocker +"','"+$resultList.waitresource +"','"+$resultList.open_tran +"','"+$resultList.login_name +"','"+$resultList.cmd +"'
        ,'"+$resultList.Text +"','"+$resultList.Last_Wait_Type +"','"+$resultList.WaitTime_Sec +"','"+$resultList.WaitTime +"','"+$resultList.transaction +"'
        ,'"+$resultList.transaction_start_time +"','"+$resultList.transaction_time_sec +"','"+$resultList.transaction_type +"','"+$resultList.transaction_State +"'
        ,'"+$resultList.Host +"','"+$resultList.Program +"','"+$resultList.last_batch +"','"+$resultList.Database_Name +"','"+$resultList.client_interface_name +"'
        ,'"+$resultList.client_net_address +"','"+$resultList.requested_memory_kb +"','"+$resultList.max_used_memory_kb +"','"+$resultList.Session_CPU_Time +"'
        ,'"+$resultList.Session_Memory +"','"+$resultList.Session_Reads +"','"+$resultList.Session_Writes +"','"+$resultList.percent_complete +"','"+$resultList.estimated_completion_time +"'
        ,'"+$resultList.UserMB +"','"+$resultList.InternalMB +"','"+$resultList.login_time +"')"
        Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Sessions_Details_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Sessions_Details] select * from [DBA_Watcher_DB].[General].[SQL_Sessions_Details_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'


Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB_Tempdb].[Baseline].[SQL_Sessions_Details]
        select [SQL_Instance_Name], [AlwaysOn],[Pull_Time] , count([Active_Sessions]) as [Active_Sessions], count ([Blocked_Sessions]) as [Blocked_Sessions]
        , count([Open_Trasactions]) as [Open_Trasactions] from(
        SELECT [SQL_Instance_Name],[AlwaysOn],[Pull_Time]
	     ,(select distinct isnull(count([SessionID]),0) where [status] not like 'sleeping%' and [status] not like 'dormant%') as [Active_Sessions]
	     ,(select distinct isnull(count([SessionID]),0) where [Blocking_Session]>0 and [WaitTime_Sec] >= 10) as [Blocked_Sessions]
	     ,(select distinct isnull(count([SessionID]),0) where [open_tran]>0) as [Open_Trasactions]
        FROM [DBA_Watcher_DB].[General].[SQL_Sessions_Details_Current] with (nolock)
        where SQL_Instance_Name in (select SQL_Instance_Name from [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])
        group by [SQL_Instance_Name],[AlwaysOn],[Pull_Time],[status],[Blocking_Session],[open_tran],[Last_Wait_Type],[WaitTime_Sec]) t
        group by [SQL_Instance_Name], [AlwaysOn],[Pull_Time] 
        order by [SQL_Instance_Name], [Pull_Time]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'SilentlyContinue'