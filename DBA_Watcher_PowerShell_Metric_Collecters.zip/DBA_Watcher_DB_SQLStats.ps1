Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "SELECT top 1 cast(SERVERPROPERTY('ServerName') as varchar)[SQL_Instance_Name],''[AlwaysOn], cast(getdate() as smalldatetime)[Pull_Time],
(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Buffer Manager%' and counter_name like 'Page life expectancy%')[Page_Life]
,round(((select cast(cntr_value as float) from [master].[sys].[dm_os_performance_counters] where object_name like '%Buffer Manager%' and rtrim(counter_name) like 'Buffer cache hit ratio')/
(select cast(cntr_value as float) from [master].[sys].[dm_os_performance_counters] where object_name like '%Buffer Manager%' and rtrim(counter_name) like 'Buffer cache hit ratio base'))*100,2)[Buffer_cache_hit_ratio]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%General Statistics%' and counter_name like 'User Connections%')[User_Connections]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%General Statistics%' and counter_name like 'Logical Connections%')[Logical_Connections]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%General Statistics%' and counter_name like 'Transactions%')[Transactions]
,round((cast((select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%SQLServer:Transactions%' and counter_name like 'Free Space in tempdb%') as float)/1024/1024),2)[Free_Space_in_tempdb_GB]
,round((cast((select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%SQLServer:Transactions%' and counter_name like 'Version Store Size (KB)%') as float)/1024/1024),2)[Version_Store_Size_GB]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'Memory Grants Pending%')[Memory_Grants_Pending]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'Memory Grants Outstanding%')[Memory_Grants_Outstanding]
,(select round(cast(cntr_value as float)/1048576,2) from [master].[sys].[dm_os_performance_counters] where object_name like '%SQLServer:Memory Manager%' and counter_name like 'Target Server Memory%')[TargetMemory_GB]
,(select round(cast(cntr_value as float)/1048576,2) from [master].[sys].[dm_os_performance_counters] where object_name like '%SQLServer:Memory Manager%' and counter_name like 'Total Server Memory%')[TotalMemory_GB]
,(select round(cast(cntr_value as float)/1024,2) from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'Connection Memory%')[Connection_Memory_MB]
,(select round(cast(cntr_value as float)/1024,2) from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'Database Cache Memory%')[Database_Cache_Memory_MB]
,(select round(cast(cntr_value as float)/1024,2) from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'Free Memory%')[Free_Memory_MB]
,(select round(cast(cntr_value as float)/1024,2) from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'Granted Workspace Memory%')[Granted_Workspace_Memory_MB]
,(select round(cast(cntr_value as float)/1024,2) from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'Lock Memory%')[Lock_Memory_MB]
,(select round(cast(cntr_value as float)/1024,2) from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'Maximum Workspace Memory%')[Maximum_Workspace_Memory_MB]
,(select round(cast(cntr_value as float)/1024,2) from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'Optimizer Memory%')[Optimizer_Memory_MB]
,(select round(cast(cntr_value as float)/1024,2) from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'Reserved Server Memory%')[Reserved_Server_Memory_MB]
,(select round(cast(cntr_value as float)/1024,2) from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'SQL Cache Memory%')[SQL_Cache_Memory_MB]
,(select round(cast(cntr_value as float)/1024,2) from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'Stolen Server Memory%')[Stolen_Server_Memory_MB]
,(select round(cast(cntr_value as float)/1024,2) from [master].[sys].[dm_os_performance_counters] where object_name like  '%SQLServer:Memory Manager%' and counter_name like 'Log Pool Memory%')[Log_Pool_Memory_MB]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%SQL Statistics%' and counter_name like 'Batch Requests/sec%')[Batch_Requests]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%SQL Statistics%' and counter_name like 'SQL Compilations/sec%')[SQL_Compilations]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%SQL Statistics%' and counter_name like 'SQL Re-Compilations/sec%')[SQL_ReCompilations]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Buffer Manager%' and counter_name like 'Page lookups/sec%')[Page_lookups]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Buffer Manager%' and counter_name like 'Page reads/sec%')[Page_reads]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Buffer Manager%' and counter_name like 'Page writes/sec%')[Page_writes]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Query Store%' and counter_name like 'Query Store CPU usage%' and instance_name like '_Total%')[Query_Store_CPU_usage]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Query Store%' and counter_name like 'Query Store physical reads%' and instance_name like '_Total%')[Query_Store_physical_reads]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Query Store%' and counter_name like 'Query Store logical reads%' and instance_name like '_Total%')[Query_Store_logical_reads]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Query Store%' and counter_name like 'Query Store logical writes%' and instance_name like '_Total%')[Query_Store_logical_writes]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Batch Resp Statistics%' and counter_name like '%>=000500ms%' and instance_name like 'Elapsed Time:Requests%')[Batch_Req_500ms_1000ms]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Batch Resp Statistics%' and counter_name like '%>=001000ms%' and instance_name like 'Elapsed Time:Requests%')[Batch_Req_1000ms_2000ms]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Batch Resp Statistics%' and counter_name like '%>=002000ms%' and instance_name like 'Elapsed Time:Requests%')[Batch_Req_2000ms_5000ms]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Batch Resp Statistics%' and counter_name like '%>=005000ms%' and instance_name like 'Elapsed Time:Requests%')[Batch_Req_5000ms_10000ms]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Batch Resp Statistics%' and counter_name like '%>=010000ms%' and instance_name like 'Elapsed Time:Requests%')[Batch_Req_10000ms_20000ms]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Batch Resp Statistics%' and counter_name like '%>=020000ms%' and instance_name like 'Elapsed Time:Requests%')[Batch_Req_20000ms_50000ms]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Batch Resp Statistics%' and counter_name like '%>=050000ms%' and instance_name like 'Elapsed Time:Requests%')[Batch_Req_50000ms_100000ms]
,(select cntr_value from [master].[sys].[dm_os_performance_counters] where object_name like '%Batch Resp Statistics%' and counter_name like '%>=100000ms%' and instance_name like 'Elapsed Time:Requests%')[Batch_Req_100000ms_Plus]
" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Statistics_Usage_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Statistics_Usage_Current]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[Page_Life],[Buffer_cache_hit_ratio],[User_Connections]
        ,[Logical_Connections],[Transactions],[Free_Space_in_tempdb_GB],[Version_Store_Size_GB],[Memory_Grants_Pending],[Memory_Grants_Outstanding],[TargetMemory_GB]
        ,[TotalMemory_GB],[Connection_Memory_MB],[Database_Cache_Memory_MB],[Free_Memory_MB],[Granted_Workspace_Memory_MB],[Lock_Memory_MB],[Maximum_Workspace_Memory_MB]
        ,[Optimizer_Memory_MB],[Reserved_Server_Memory_MB],[SQL_Cache_Memory_MB],[Stolen_Server_Memory_MB],[Log_Pool_Memory_MB],[Batch_Requests],[SQL_Compilations]
        ,[SQL_ReCompilations],[Page_lookups],[Page_reads],[Page_writes],[Query_Store_CPU_usage],[Query_Store_physical_reads],[Query_Store_logical_reads],[Query_Store_logical_writes]
        ,[Batch_Req_500ms_1000ms],[Batch_Req_1000ms_2000ms],[Batch_Req_2000ms_5000ms],[Batch_Req_5000ms_10000ms],[Batch_Req_10000ms_20000ms],[Batch_Req_20000ms_50000ms]
        ,[Batch_Req_50000ms_100000ms],[Batch_Req_100000ms_Plus]) VALUES ('"+$resultList.SQL_Instance_Name +"','"+$resultList.AlwaysOn +"',cast(getdate() as smalldatetime)
        ,'"+$resultList.Page_Life +"','"+$resultList.Buffer_cache_hit_ratio +"','"+$resultList.User_Connections +"','"+$resultList.Logical_Connections +"'
        ,'"+$resultList.Transactions +"','"+$resultList.Free_Space_in_tempdb_GB +"','"+$resultList.Version_Store_Size_GB +"','"+$resultList.Memory_Grants_Pending +"'
        ,'"+$resultList.Memory_Grants_Outstanding +"','"+$resultList.TargetMemory_GB +"','"+$resultList.TotalMemory_GB +"','"+$resultList.Connection_Memory_MB +"'
        ,'"+$resultList.Database_Cache_Memory_MB +"','"+$resultList.Free_Memory_MB +"','"+$resultList.Granted_Workspace_Memory_MB +"','"+$resultList.Lock_Memory_MB +"'
        ,'"+$resultList.Maximum_Workspace_Memory_MB +"','"+$resultList.Optimizer_Memory_MB +"','"+$resultList.Reserved_Server_Memory_MB +"','"+$resultList.SQL_Cache_Memory_MB +"'
        ,'"+$resultList.Stolen_Server_Memory_MB +"','"+$resultList.Log_Pool_Memory_MB +"','"+$resultList.Batch_Requests +"','"+$resultList.SQL_Compilations +"'
        ,'"+$resultList.SQL_ReCompilations +"','"+$resultList.Page_lookups +"','"+$resultList.Page_reads +"','"+$resultList.Page_writes +"','"+$resultList.Query_Store_CPU_usage +"'
        ,'"+$resultList.Query_Store_physical_reads +"','"+$resultList.Query_Store_logical_reads +"','"+$resultList.Query_Store_logical_writes +"'
        ,'"+$resultList.Batch_Req_500ms_1000ms +"','"+$resultList.Batch_Req_1000ms_2000ms +"','"+$resultList.Batch_Req_2000ms_5000ms +"','"+$resultList.Batch_Req_5000ms_10000ms +"'
        ,'"+$resultList.Batch_Req_10000ms_20000ms +"','"+$resultList.Batch_Req_20000ms_50000ms +"','"+$resultList.Batch_Req_50000ms_100000ms +"'
        ,'"+$resultList.Batch_Req_100000ms_Plus +"')"
        Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 30 -ErrorAction SilentlyContinue 
}

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Statistics_Usage_Raw] select * from [DBA_Watcher_DB].[General].[SQL_Statistics_Usage_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

Invoke-Sqlcmd -Query "update y
set y.Page_reads = (y.Page_reads - x.Page_reads) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Page_writes = (y.Page_writes - x.Page_writes) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Batch_Requests = (y.Batch_Requests - x.Batch_Requests) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.SQL_Compilations = (y.SQL_Compilations - x.SQL_Compilations) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.SQL_ReCompilations = (y.SQL_ReCompilations - x.SQL_ReCompilations) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Page_lookups = (y.Page_lookups - x.Page_lookups) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Query_Store_CPU_usage = (y.Query_Store_CPU_usage - x.Query_Store_CPU_usage) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Query_Store_physical_reads = (y.Query_Store_physical_reads - x.Query_Store_physical_reads) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Query_Store_logical_reads = (y.Query_Store_logical_reads - x.Query_Store_logical_reads) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Query_Store_logical_writes = (y.Query_Store_logical_writes - x.Query_Store_logical_writes) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Batch_Req_500ms_1000ms = (y.Batch_Req_500ms_1000ms - x.Batch_Req_500ms_1000ms) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Batch_Req_1000ms_2000ms = (y.Batch_Req_1000ms_2000ms - x.Batch_Req_1000ms_2000ms) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Batch_Req_2000ms_5000ms = (y.Batch_Req_2000ms_5000ms - x.Batch_Req_2000ms_5000ms) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Batch_Req_5000ms_10000ms = (y.Batch_Req_5000ms_10000ms - x.Batch_Req_5000ms_10000ms) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Batch_Req_10000ms_20000ms = (y.Batch_Req_10000ms_20000ms - x.Batch_Req_10000ms_20000ms) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Batch_Req_20000ms_50000ms = (y.Batch_Req_20000ms_50000ms - x.Batch_Req_20000ms_50000ms) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Batch_Req_50000ms_100000ms = (y.Batch_Req_50000ms_100000ms - x.Batch_Req_50000ms_100000ms) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
, y.Batch_Req_100000ms_Plus = (y.Batch_Req_100000ms_Plus - x.Batch_Req_100000ms_Plus) / DATEDIFF(SECOND, x.pull_time, y.Pull_Time)
from [DBA_Watcher_DB].[General].[SQL_Statistics_Usage_Current] y, [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Statistics_Usage] x
where y.SQL_Instance_Name = x.SQL_Instance_Name and y.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])
and x.pull_time != y.pull_time" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

Invoke-Sqlcmd -Query "update [DBA_Watcher_DB].[General].[SQL_Statistics_Usage_Current] set Buffer_cache_hit_ratio = 100 where Buffer_cache_hit_ratio > 100 and SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Statistics_Usage_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] select * from [DBA_Watcher_DB].[General].[SQL_Statistics_Usage_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Statistics_Usage] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'
Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Statistics_Usage] select * from [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Statistics_Usage_Raw] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'
Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Statistics_Usage_Raw] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'
