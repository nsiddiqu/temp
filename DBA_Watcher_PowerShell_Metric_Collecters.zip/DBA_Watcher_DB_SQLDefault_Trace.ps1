﻿Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "SELECT cast(SERVERPROPERTY('ServerName') as varchar)[SQL_Instance_Name], ''[AlwaysOn], cast(getdate() as smalldatetime)[Pull_Time], TE.name ,
v.subclass_name ,DB_NAME(T.DatabaseID) AS DBName ,T.LoginName,T.HostName ,T.ApplicationName ,T.TargetLoginName,T.Duration ,T.StartTime ,T.EndTime,
T.Reads,T.Writes,T.CPU,T.Permissions,T.Severity,T.ObjectName,T.SPID,cast(T.TextData as varchar) as [TextData],
CASE T.ObjectType
  WHEN 8259 THEN 'Check Constraint'  WHEN 8260 THEN 'Default (constraint or standalone)'  WHEN 8262 THEN 'Foreign-key Constraint'
  WHEN 8272 THEN 'Stored Procedure'  WHEN 8274 THEN 'Rule'  WHEN 8275 THEN 'System Table'  WHEN 8276 THEN 'Trigger on Server'
  WHEN 8277 THEN '(User-defined) Table'  WHEN 8278 THEN 'View'  WHEN 8280 THEN 'Extended Stored Procedure'  WHEN 16724 THEN 'CLR Trigger'
  WHEN 16964 THEN 'Database'  WHEN 16975 THEN 'Object'  WHEN 17222 THEN 'FullText Catalog'  WHEN 17232 THEN 'CLR Stored Procedure'
  WHEN 17235 THEN 'Schema'  WHEN 17475 THEN 'Credential'  WHEN 17491 THEN 'DDL Event'  WHEN 17741 THEN 'Management Event'
  WHEN 17747 THEN 'Security Event'  WHEN 17749 THEN 'User Event'  WHEN 17985 THEN 'CLR Aggregate Function'  WHEN 17993 THEN 'Inline Table-valued SQL Function'
  WHEN 18000 THEN 'Partition Function'  WHEN 18002 THEN 'Replication Filter Procedure'  WHEN 18004 THEN 'Table-valued SQL Function'
  WHEN 18259 THEN 'Server Role'  WHEN 18263 THEN 'Microsoft Windows Group'  WHEN 19265 THEN 'Asymmetric Key'  WHEN 19277 THEN 'Master Key'
  WHEN 19280 THEN 'Primary Key'  WHEN 19283 THEN 'ObfusKey'  WHEN 19521 THEN 'Asymmetric Key Login'  WHEN 19523 THEN 'Certificate Login'
  WHEN 19538 THEN 'Role'  WHEN 19539 THEN 'SQL Login'  WHEN 19543 THEN 'Windows Login'  WHEN 20034 THEN 'Remote Service Binding'
  WHEN 20036 THEN 'Event Notification on Database'  WHEN 20037 THEN 'Event Notification'  WHEN 20038 THEN 'Scalar SQL Function'
  WHEN 20047 THEN 'Event Notification on Object'  WHEN 20051 THEN 'Synonym'  WHEN 20549 THEN 'End Point'  WHEN 20801 THEN 'Adhoc Queries which may be cached'
  WHEN 20816 THEN 'Prepared Queries which may be cached'  WHEN 20819 THEN 'Service Broker Service Queue'  WHEN 20821 THEN 'Unique Constraint'
  WHEN 21057 THEN 'Application Role'  WHEN 21059 THEN 'Certificate'  WHEN 21075 THEN 'Server'  WHEN 21076 THEN 'Transact-SQL Trigger'
  WHEN 21313 THEN 'Assembly'  WHEN 21318 THEN 'CLR Scalar Function'  WHEN 21321 THEN 'Inline scalar SQL Function'  WHEN 21328 THEN 'Partition Scheme'
  WHEN 21333 THEN 'User'  WHEN 21571 THEN 'Service Broker Service Contract'  WHEN 21572 THEN 'Trigger on Database'  WHEN 21574 THEN 'CLR Table-valued Function'
  WHEN 21577 THEN 'Internal Table (For example, XML Node Table, Queue Table.)'  WHEN 21581 THEN 'Service Broker Message Type'
  WHEN 21586 THEN 'Service Broker Route'  WHEN 21587 THEN 'Statistics'  WHEN 21825 THEN 'User'  WHEN 21827 THEN 'User'  WHEN 21831 THEN 'User'
  WHEN 21843 THEN 'User'  WHEN 21847 THEN 'User'  WHEN 22099 THEN 'Service Broker Service'  WHEN 22601 THEN 'Index'  WHEN 22604 THEN 'Certificate Login'
  WHEN 22611 THEN 'XMLSchema'  WHEN 22868 THEN 'Type'  ELSE 'Unknown'END AS ObjectType
FROM    [fn_trace_gettable](CONVERT(VARCHAR(150), ( SELECT TOP 1 value FROM [fn_trace_getinfo](NULL) WHERE [property] = 2)), DEFAULT) T
inner JOIN sys.trace_events TE ON T.EventClass = TE.trace_event_id
inner JOIN  sys.trace_subclass_values v ON v.trace_event_id = TE.trace_event_id AND v.subclass_value = T.EventSubClass
WHERE   DatabaseID <> 2 AND StartTime > dateadd(minute, -10, GetDate())
and name != 'Audit Server Alter Trace Event' and name != 'Sort Warnings' and v.subclass_name != 'View Server State' and T.ObjectName != 'telemetry_xevents' and T.ObjectType != 21587
and name != 'Audit Backup/Restore Event'  and T.ObjectType != 8277
ORDER BY T.StartTime DESC" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 20 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Default_Trace_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Default_Trace_Current]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[name],[subclass_name],[DBName],[LoginName]
        ,[HostName],[ApplicationName],[TargetLoginName],[Duration],[StartTime],[EndTime],[Reads],[Writes],[CPU],[Permissions],[Severity],[ObjectName]
        ,[SPID],[TextData],[ObjectType]) VALUES ('"+$resultList.SQL_Instance_Name+"','"+$resultList.AlwaysOn+"',cast(getdate() as smalldatetime),'"+$resultList.name+"'
        ,'"+$resultList.subclass_name+"','"+$resultList.DBName+"','"+$resultList.LoginName+"','"+$resultList.HostName+"','"+$resultList.ApplicationName+"'
        ,'"+$resultList.TargetLoginName+"','"+$resultList.Duration+"','"+$resultList.StartTime+"','"+$resultList.EndTime+"','"+$resultList.Reads+"'
        ,'"+$resultList.Writes+"','"+$resultList.CPU+"','"+$resultList.Permissions+"','"+$resultList.Severity+"','"+$resultList.ObjectName+"'
        ,'"+$resultList.SPID+"','"+$resultList.TextData+"','"+$resultList.ObjectType+"')" 
Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Default_Trace_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Default_Trace] select * from [DBA_Watcher_DB].[General].[SQL_Default_Trace_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'




