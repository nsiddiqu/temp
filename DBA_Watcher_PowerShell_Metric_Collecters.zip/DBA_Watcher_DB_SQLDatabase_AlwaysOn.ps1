Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "SELECT cast(SERVERPROPERTY('ServerName') as varchar) as SQL_Instance_Name, ''[AlwaysOn],cast(getdate() as smalldatetime) as Pull_Time, dns_name, cast(ag.name as varchar) AS ag_name, 
        cast(RCS.replica_server_name as varchar)[replica_server_name] ,cast(adc.database_name as varchar)[database_name], log_send_queue_size, log_send_rate, redo_queue_size, redo_rate, last_sent_time, last_received_time,  ARS.role_desc,
        database_state_desc, ar.availability_mode_desc, ar.failover_mode_desc, automated_backup_preference_desc, drs.synchronization_state_desc, drs.synchronization_health_desc, 
        secondary_role_allow_connections_desc, drs.last_commit_time, health_check_timeout, is_suspended, endpoint_url, join_state_desc, connected_state_desc, failure_condition_level, create_date ,modify_date
		FROM master.sys.availability_group_listeners AS AGL  with (nolock)
        left outer JOIN master.sys.availability_groups AS ag with (nolock) ON ag.group_id = AGL.group_id
        left outer join master.sys.dm_hadr_database_replica_states AS drs with (nolock) ON drs.group_id = AGL.group_id 
        left outer JOIN master.sys.availability_databases_cluster AS adc  with (nolock) ON drs.group_id = adc.group_id AND drs.group_database_id = adc.group_database_id
        left outer JOIN master.sys.availability_replicas AS ar with (nolock) ON drs.group_id = ar.group_id AND drs.replica_id = ar.replica_id
        left outer JOIN master.sys.dm_hadr_availability_replica_cluster_states AS RCS  with (nolock) ON RCS.group_id = adc.group_id and RCS.replica_id = ar.replica_id
        left outer JOIN master.sys.dm_hadr_availability_replica_states AS ARS  with (nolock) ON ARS.group_id = adc.group_id and ARS.replica_id = RCS.replica_id" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Database_AlwaysOn] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 20 -ErrorAction 'Stop'
Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Database_AlwaysOn] select * from [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 20 -ErrorAction 'Stop'


foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] ([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[dns_name],[ag_name],[replica_server_name],[database_name]
        ,[log_send_queue_size],[log_send_rate],[redo_queue_size],[redo_rate],[last_sent_time],[last_received_time],[role_desc],[database_state_desc],[availability_mode_desc]
        ,[failover_mode_desc],[automated_backup_preference_desc],[synchronization_state_desc],[synchronization_health_desc],[secondary_role_allow_connections_desc]
        ,[last_commit_time],[health_check_timeout],[is_suspended],[endpoint_url],[join_state_desc],[connected_state_desc],[failure_condition_level],[create_date]
        ,[modify_date]) VALUES ('"+$resultList.SQL_Instance_Name +"','"+$resultList.AlwaysOn +"',cast(getdate() as smalldatetime),'"+$resultList.dns_name +"','"+$resultList.ag_name +"'
        ,'"+$resultList.replica_server_name +"','"+$resultList.database_name +"','"+$resultList.log_send_queue_size +"','"+$resultList.log_send_rate +"','"+$resultList.redo_queue_size +"'
        ,'"+$resultList.redo_rate +"','"+$resultList.last_sent_time +"','"+$resultList.last_received_time +"','"+$resultList.role_desc +"','"+$resultList.database_state_desc +"'
        ,'"+$resultList.availability_mode_desc +"','"+$resultList.failover_mode_desc +"','"+$resultList.automated_backup_preference_desc +"','"+$resultList.synchronization_state_desc +"'
        ,'"+$resultList.synchronization_health_desc +"','"+$resultList.secondary_role_allow_connections_desc +"','"+$resultList.last_commit_time +"','"+$resultList.health_check_timeout +"'
        ,'"+$resultList.is_suspended +"','"+$resultList.endpoint_url +"','"+$resultList.join_state_desc +"','"+$resultList.connected_state_desc +"','"+$resultList.failure_condition_level +"'
        ,'"+$resultList.create_date +"','"+$resultList.modify_date +"')"
        Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 30 -ErrorAction stop 
}

Invoke-Sqlcmd -Query "update si
        set si.dns_name = sdao.dns_name
        from [DBA_Watcher_DB].[Config].[SQL_Inventory] si (nolock)
        inner join [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] sdao (nolock) on si.SQL_Instance_Name = sdao.SQL_Instance_Name
        where si.dns_name like ''

        update [DBA_Watcher_DB].[Config].[SQL_Inventory]
        set [dns_name_desc] = ''

        update [DBA_Watcher_DB].[Config].[SQL_Inventory]
        set [dns_name_desc] = ''+ [SQL_Instance_Name] + ' Main' + ''
        where SQL_Instance_Name in (SELECT distinct t.[SQL_Instance_Name]
        FROM [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] t (nolock)
        where t.role_desc like 'PRIMARY%' and t.availability_mode_desc like 'SYNCHRONOUS_COMMIT%')
        and [dns_name_desc] not like '%Main%'

        update [DBA_Watcher_DB].[Config].[SQL_Inventory]
        set [dns_name_desc] = ''+ [SQL_Instance_Name] + ' DR' + ''
        where SQL_Instance_Name in (SELECT distinct t.[SQL_Instance_Name]
        FROM [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] t (nolock)
        where t.availability_mode_desc like 'ASYNCHRONOUS_COMMIT%' and database_state_desc like 'Online' and t.[SQL_Instance_Name] is not null)
        and [dns_name_desc] not like '%DR%'

        update [DBA_Watcher_DB].[Config].[SQL_Inventory]
        set [dns_name_desc] = ''+ [SQL_Instance_Name] + ' HA' + ''
        where dns_name in (SELECT distinct t.dns_name
        FROM [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] t (nolock)
        where t.availability_mode_desc not like 'ASYNCHRONOUS_COMMIT%' and database_state_desc like 'Online')
        and [dns_name_desc] not like '%DR%' and [dns_name_desc] not like '%Main%' and [dns_name_desc] not like '%HA%'" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction stop


Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn] select * from [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'
