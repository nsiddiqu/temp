﻿Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "if object_id('tempdb..#DeadlockXML') is not null
    drop table #DeadlockXML

if object_id('tempdb..#DeadlockEvents') is not null
    drop table #DeadlockEvents

SELECT CAST(target_data AS XML) AS TargetData
INTO #DeadlockXML
FROM sys.dm_xe_session_targets st
JOIN sys.dm_xe_sessions s ON s.address = st.event_session_address
WHERE name = 'xe_DeadlockReport'

SELECT XEvent.query('.') AS event_data
INTO #DeadlockEvents
FROM #DeadlockXML
CROSS APPLY TargetData.nodes('RingBufferTarget/event') AS XEventData(XEvent);

SELECT TOP (100)
    CAST(SERVERPROPERTY('ServerName') AS VARCHAR) AS [SQL_Instance_Name],
    '' AS [AlwaysOn],
    CAST(GETDATE() AS SMALLDATETIME) AS [Pull_Time],
    n.value('(/event/@name)[1]','nvarchar(256)') AS [EventName],
    DATEADD(HOUR, DATEDIFF(HOUR, GETUTCDATE(), CURRENT_TIMESTAMP), n.value('(@timestamp)[1]', 'datetime')) AS [LoginTimestamp],
    n.value('(/event/data/value/deadlock/process-list/process/@hostname)[1]','varchar(128)') AS [VictimHostName],
    n.value('(/event/data/value/deadlock/process-list/process/@loginname)[1]','varchar(256)') AS [VictimLoginName],
    n.value('(/event/data/value/deadlock/process-list/process/@currentdbname)[1]','varchar(256)') AS [VictimDatabase],
    n.value('(/event/data/value/deadlock/process-list/process/@clientapp)[1]','varchar(128)') AS [Victimclientapp],
    n.value('(/event/data/value/deadlock/process-list/process/@isolationlevel)[1]','varchar(256)') AS [Victimisolationlevel],
    REPLACE(n.value('(/event/data/value/deadlock/process-list/process/inputbuf)[1]','varchar(1000)'),'''','''''') AS [VictimSQL],
    n.value('(/event/data/value/deadlock/process-list/process/executionStack/frame/@procname)[1]','varchar(256)') AS [VictimProcName],
    SUBSTRING(n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'),1, CHARINDEX(':', n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'))) AS [VictimKey],
    CASE
        WHEN SUBSTRING(n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'),1, CHARINDEX(':', n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'))) = 'KEY:' THEN n.value('(/event/data/value/deadlock/resource-list/keylock/@objectname)[1]','varchar(256)')
        WHEN SUBSTRING(n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'),1, CHARINDEX(':', n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'))) = 'PAGE:' THEN n.value('(/event/data/value/deadlock/resource-list/pagelock/@objectname)[1]','varchar(256)')
        WHEN SUBSTRING(n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'),1, CHARINDEX(':', n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'))) = 'OBJECT:' THEN n.value('(/event/data/value/deadlock/resource-list/objectlock/@objectname)[1]','varchar(256)')
        WHEN SUBSTRING(n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'),1, CHARINDEX(':', n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'))) = 'RID:' THEN n.value('(/event/data/value/deadlock/resource-list/ridlock/@objectname)[1]','varchar(256)')
        WHEN SUBSTRING(n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'),1, CHARINDEX(':', n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'))) = 'DATABASE:' THEN n.value('(/event/data/value/deadlock/resource-list/databaselock/@objectname)[1]','varchar(256)')
        ELSE ''
    END AS [VictimLockObjectName],
    -- Survivor details
    n.value('(/event/data/value/deadlock/process-list/process/@hostname)[2]','varchar(128)') AS [SurvivorHostName],
    n.value('(/event/data/value/deadlock/process-list/process/@loginname)[2]','varchar(256)') AS [SurvivorLoginName],
    n.value('(/event/data/value/deadlock/process-list/process/@currentdbname)[1]','varchar(256)') AS [SurvivorDatabase],
    n.value('(/event/data/value/deadlock/process-list/process/@clientapp)[1]','varchar(128)') AS [Survivorclientapp],
    n.value('(/event/data/value/deadlock/process-list/process/@isolationlevel)[1]','varchar(256)') AS [Survivorisolationlevel],
    REPLACE(n.value('(/event/data/value/deadlock/process-list/process/inputbuf)[2]','varchar(1000)'),'''','''''') AS [SurvivorSQL],
    n.value('((/event/data/value/deadlock/process-list/process)[2]/executionStack/frame/@procname)[1]','varchar(256)') AS [SurvivorProcName],
    SUBSTRING(n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[2]','varchar(256)'),1, CHARINDEX(':', n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[2]','varchar(256)'))) AS [SurvivorKey],
    CASE
        WHEN SUBSTRING(n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'),1, CHARINDEX(':', n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[2]','varchar(256)'))) = 'KEY:' THEN n.value('(/event/data/value/deadlock/resource-list/keylock/@objectname)[2]','varchar(256)')
        WHEN SUBSTRING(n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'),1, CHARINDEX(':', n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[2]','varchar(256)'))) = 'PAGE:' THEN n.value('(/event/data/value/deadlock/resource-list/pagelock/@objectname)[2]','varchar(256)')
        WHEN SUBSTRING(n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'),1, CHARINDEX(':', n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[2]','varchar(256)'))) = 'OBJECT:' THEN n.value('(/event/data/value/deadlock/resource-list/objectlock/@objectname)[2]','varchar(256)')
        WHEN SUBSTRING(n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'),1, CHARINDEX(':', n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[2]','varchar(256)'))) = 'RID:' THEN n.value('(/event/data/value/deadlock/resource-list/ridlock/@objectname)[2]','varchar(256)')
        WHEN SUBSTRING(n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[1]','varchar(256)'),1, CHARINDEX(':', n.value('(/event/data/value/deadlock/process-list/process/@waitresource)[2]','varchar(256)'))) = 'DATABASE:' THEN n.value('(/event/data/value/deadlock/resource-list/databaselock/@objectname)[2]','varchar(256)')
        ELSE ''
    END AS [SurvivorLockObjectName]
FROM #DeadlockEvents
CROSS APPLY event_data.nodes('event') AS q(n)
WHERE DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP),  n.value('(@timestamp)[1]', 'datetime'))> DATEADD(HOUR, -1, GETDATE()) 
order by [LoginTimestamp] desc

if object_id('tempdb..#DeadlockXML') is not null
    drop table #DeadlockXML

if object_id('tempdb..#DeadlockEvents') is not null
    drop table #DeadlockEvents" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Xevent_Deadlocks_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Xevent_Deadlocks_Current]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[EventName],[LoginTimestamp],[VictimHostName],[VictimLoginName],[VictimDatabase],[Victimclientapp],[Victimisolationlevel]
,[VictimSQL],[VictimProcName],[VictimKey],[VictimLockObjectName],[SurvivorHostName],[SurvivorLoginName],[SurvivorDatabase],[Survivorclientapp],[Survivorisolationlevel],[SurvivorSQL]
,[SurvivorProcName],[SurvivorKey],[SurvivorLockObjectName],[XML_Report]) VALUES ('"+ $resultList.SQL_Instance_Name+"','"+ $resultList.AlwaysOn+"',cast(getdate() as smalldatetime),'"+ $resultList.EventName+"','"+ $resultList.LoginTimestamp+"'
,'"+ $resultList.VictimHostName+"','"+ $resultList.VictimLoginName+"','"+ $resultList.VictimDatabase+"','"+ $resultList.Victimclientapp+"','"+ $resultList.Victimisolationlevel+"','"+ $resultList.VictimSQL+"'
,'"+ $resultList.VictimProcName+"','"+ $resultList.VictimKey+"','"+ $resultList.VictimLockObjectName+"','"+ $resultList.SurvivorHostName+"','"+ $resultList.SurvivorLoginName+"','"+ $resultList.SurvivorDatabase+"'
,'"+ $resultList.Survivorclientapp+"','"+ $resultList.Survivorisolationlevel+"','"+ $resultList.SurvivorSQL+"','"+ $resultList.SurvivorProcName+"','"+ $resultList.SurvivorKey+"','"+ $resultList.SurvivorLockObjectName+"'
,'')" 
Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Xevent_Deadlocks_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Xevent_Deadlocks] select * from [DBA_Watcher_DB].[General].[SQL_Xevent_Deadlocks_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'




