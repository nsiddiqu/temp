Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "SELECT top 1 cast(SERVERPROPERTY('ServerName') as varchar)[SQL_Instance_Name], ''[AlwaysOn], cast(getdate() as smalldatetime)[Pull_Time],
	(cast(record as xml).value('(//Record/MemoryRecord/TotalPhysicalMemory)[1]', 'bigint')/1024) AS [TotalPhysicalMemory_MB], 
	(cast(record as xml).value('(//Record/MemoryRecord/AvailablePhysicalMemory)[1]', 'bigint')/1024) AS [AvailablePhysicalMemory_MB], 
	(cast(record as xml).value('(//Record/MemoryNode/ReservedMemory)[1]', 'bigint')/1024) AS [SQL_ReservedMemory_MB], 
	(cast(record as xml).value('(//Record/MemoryNode/CommittedMemory)[1]', 'bigint')/1024) AS [SQL_CommittedMemory_MB], 
    (cast(record as xml).value('(//Record/MemoryRecord/TotalPageFile)[1]', 'bigint')/1024) AS [TotalPageFile_MB], 
	(cast(record as xml).value('(//Record/MemoryRecord/AvailablePageFile)[1]', 'bigint')/1024) AS [AvailablePageFile_MB], 
	(cast(record as xml).value('(//Record/MemoryRecord/TotalVirtualAddressSpace)[1]', 'bigint')/1024) AS [TotalVirtualAddressSpace_MB],  
	(cast(record as xml).value('(//Record/MemoryRecord/AvailableVirtualAddressSpace)[1]', 'bigint')/1024) AS [AvailableVirtualAddressSpace_MB]
    FROM sys.dm_os_ring_buffers rbf 
    cross join sys.dm_os_sys_info tme 
    where rbf.ring_buffer_type = 'RING_BUFFER_RESOURCE_MONITOR' 
    ORDER BY rbf.timestamp ASC" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Statistics_Memory_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Statistics_Memory_Current]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[TotalPhysicalMemory_MB],[AvailablePhysicalMemory_MB]
        ,[SQL_ReservedMemory_MB],[SQL_CommittedMemory_MB],[TotalPageFile_MB],[AvailablePageFile_MB],[TotalVirtualAddressSpace_MB]
        ,[AvailableVirtualAddressSpace_MB]) VALUES ('"+$resultList.SQL_Instance_Name+"','"+$resultList.AlwaysOn+"',cast(getdate() as smalldatetime)
        ,'"+$resultList.TotalPhysicalMemory_MB+"','"+$resultList.AvailablePhysicalMemory_MB+"','"+$resultList.SQL_ReservedMemory_MB+"'
        ,'"+$resultList.SQL_CommittedMemory_MB+"','"+$resultList.TotalPageFile_MB+"','"+$resultList.AvailablePageFile_MB+"'
        ,'"+$resultList.TotalVirtualAddressSpace_MB+"','"+$resultList.AvailableVirtualAddressSpace_MB+"')"
        Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 30 -ErrorAction SilentlyContinue 
}

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Statistics_Memory_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Statistics_Memory] select * from [DBA_Watcher_DB].[General].[SQL_Statistics_Memory_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

