﻿Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "if object_id('tempdb..#FailedQueriesXML') is not null
    drop table #FailedQueriesXML

if object_id('tempdb..#FailedQueriesEvents') is not null
    drop table #FailedQueriesEvents


SELECT CAST(target_data AS XML) AS TargetData
INTO #FailedQueriesXML
FROM sys.dm_xe_session_targets st
JOIN sys.dm_xe_sessions s ON s.address = st.event_session_address
WHERE name = 'xe_FailedQueries'

SELECT XEvent.query('.') AS event_data
INTO #FailedQueriesEvents
FROM #FailedQueriesXML
CROSS APPLY TargetData.nodes('RingBufferTarget/event') AS XEventData(XEvent);

SELECT TOP (50)
    CAST(SERVERPROPERTY('ServerName') AS VARCHAR) AS [SQL_Instance_Name],
    '' AS [AlwaysOn],
    CAST(GETDATE() AS SMALLDATETIME) AS [Pull_Time],
    n.value('(/event/@name)[1]','nvarchar(160)') AS [EventName],
    DATEADD(HOUR, DATEDIFF(HOUR, GETUTCDATE(), CURRENT_TIMESTAMP), n.value('(@timestamp)[1]', 'datetime')) AS [LoginTimestamp],
    n.value('(action[@name=''username'']/value)[1]','nvarchar(200)') AS [username],
    n.value('(action[@name=''database_name'']/value)[1]','nvarchar(100)') AS [DatabaseName],
    n.value('(action[@name=''client_hostname'']/value)[1]','nvarchar(119)') AS [client_hostname],
    n.value('(action[@name=''client_app_name'']/value)[1]','nvarchar(224)') AS [client_app_name],
    n.value('(data[@name=''error_number'']/value)[1]','nvarchar(100)') AS [error_number],
    REPLACE(n.value('(data[@name=''message'']/value)[1]','nvarchar(2000)'),'''','''''') AS [message],
    REPLACE(n.value('(action[@name=''sql_text'']/value)[1]','varchar(8000)'),'''','''''') AS [sql_text],
    CASE
        WHEN SUBSTRING(n.value('(action[@name=''client_app_name'']/value)[1]','nvarchar(224)'),1,23) = 'SQLAgent - TSQL JobStep'
        THEN SUBSTRING(n.value('(action[@name=''client_app_name'']/value)[1]','nvarchar(224)'),30,34)
        ELSE NULL
    END AS [Job_IDstring],
    n.value('(action[@name=''plan_handle'']/value)[1]','varchar(100)') AS [plan_handle]
FROM #FailedQueriesEvents
CROSS APPLY event_data.nodes('event') AS q(n)
WHERE DATEADD(HOUR, DATEDIFF(HOUR, GETUTCDATE(), CURRENT_TIMESTAMP), n.value('(@timestamp)[1]', 'datetime')) > DATEADD(HOUR, -1, GETDATE())
  AND n.value('(action[@name=''username'']/value)[1]','nvarchar(200)') <> ''
ORDER BY n.value('(@timestamp)[1]', 'datetime') DESC;

if object_id('tempdb..#FailedQueriesXML') is not null
    drop table #FailedQueriesXML

if object_id('tempdb..#FailedQueriesEvents') is not null
    drop table #FailedQueriesEvents" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Xevent_FailedQueries_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Xevent_FailedQueries_Current]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[EventName],[LoginTimestamp],[username],[DatabaseName],[client_hostname],[client_app_name],[error_number],[message]
,[sql_text],[Job_IDstring],[plan_handle]) VALUES ('"+ $resultList.SQL_Instance_Name+"','"+ $resultList.AlwaysOn+"',cast(getdate() as smalldatetime),'"+ $resultList.EventName+"','"+ $resultList.LoginTimestamp+"'
,'"+ $resultList.username+"','"+ $resultList.DatabaseName+"','"+ $resultList.client_hostname+"','"+ $resultList.client_app_name+"','"+ $resultList.error_number+"','"+ $resultList.message+"'
,'"+ $resultList.sql_text+"','"+ $resultList.Job_IDstring+"','"+ $resultList.plan_handle+"')"
        Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 30 -ErrorAction stop
}

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Xevent_FailedQueries_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Xevent_FailedQueries] select * from [DBA_Watcher_DB].[General].[SQL_Xevent_FailedQueries_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

