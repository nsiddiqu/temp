Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "DECLARE @TimeZone VARCHAR(50)
EXEC master.dbo.xp_regread 'HKEY_LOCAL_MACHINE',
'SYSTEM\CurrentControlSet\Control\TimeZoneInformation',
'TimeZoneKeyName',@TimeZone OUT

SELECT cast(SERVERPROPERTY('ServerName') as varchar) as SQL_Instance_Name, ''[AlwaysOn], cast(getdate() as smalldatetime) as Pull_Time
,@TimeZone as [TimeZone], DEFAULT_DOMAIN() AS [DomainName] ,CONNECTIONPROPERTY('local_net_address') AS [IP_Address] ,CONNECTIONPROPERTY('local_tcp_port')  AS [Port]
,(select cpu_count FROM master.sys.dm_os_sys_info with (nolock)) AS [CPU_Count]
,(SELECT top 1 (cast(record as xml).value('(//Record/MemoryRecord/TotalPhysicalMemory)[1]', 'bigint') /1024) FROM master.sys.dm_os_ring_buffers rbf with (nolock) 
       where rbf.ring_buffer_type = 'RING_BUFFER_RESOURCE_MONITOR' ORDER BY rbf.timestamp desc)  AS [PhysicalMemory_MB]
,CASE WHEN SERVERPROPERTY('IsClustered')=1 Then 'Failover' WHEN SERVERPROPERTY('IsHadrEnabled')=1 Then 'AlwaysOn' else'NO' END [Clustered] 
,CASE when (select virtual_machine_type_desc from master.sys.dm_os_sys_info) like 'HYPERVISOR' Then 'Virtual' else 'Physical' END [Server_Type]
,(SELECT 'SQL Server ' + CASE CAST(SERVERPROPERTY('productversion') AS CHAR(4)) WHEN '9.0' THEN '2005' WHEN '10.0' THEN '2008' WHEN '10.5' THEN '2008 R2' WHEN '11.0' THEN '2012'
WHEN '12.0' THEN '2014' WHEN '13.0' THEN '2016' WHEN '14.0' THEN '2017' WHEN '15.0' THEN '2019' WHEN '16.0' THEN '2022' WHEN '17.0' THEN '2025'END) [SQLVersion]
,SERVERPROPERTY('ProductLevel')[SP]  ,SERVERPROPERTY('ProductVersion')[Version], SERVERPROPERTY('ProductUpdateLevel')[Build_Level] ,SERVERPROPERTY('Edition')[Edition]
,(select cast(LEFT(RTRIM(CONVERT(DATETIMEOFFSET, sqlserver_start_time)), 19) as smalldatetime) from master.sys.dm_os_sys_info)[LastRestartTime]
,(SELECT cast(create_date as smalldatetime) FROM sys.server_principals WITH (NOLOCK) WHERE name = N'NT AUTHORITY\SYSTEM')[Install_Date]
,(SELECT status_desc FROM master.sys.dm_server_services with (nolock) where servicename like '%Agent%') [SQL_Agent_Status]
,CASE (SELECT windows_release FROM sys.dm_os_windows_info with (nolock)) WHEN '6.0' THEN 'Windows Server 2008'
WHEN '6.1' THEN 'Windows Server 2008 R2' WHEN '6.2' THEN 'Windows Server 2012' WHEN '6.3' THEN 'Windows Server 2012 R2' WHEN '10.0' THEN 'Windows Server 2016+' ELSE 'Unknown Windows' END AS [WindowsVersionBuild]
,(select round(cast((select cntr_value from [master].[sys].[dm_os_performance_counters] where instance_name like '_Total%' and counter_name like 'Data File(s) Size%') - 
(select cntr_value from [master].[sys].[dm_os_performance_counters] where instance_name like 'tempdb%' and counter_name like 'Data File(s) Size%')as float)/1048576,2))[Total_Data_Size_GB]
,(select round(cast((select cntr_value from [master].[sys].[dm_os_performance_counters] where instance_name like '_Total%' and counter_name like 'Log File(s) Size%') - 
(select cntr_value from [master].[sys].[dm_os_performance_counters] where instance_name like 'tempdb%' and counter_name like 'Log File(s) Size%')as float)/1048576,2))[Total_Log_Size_GB]
,(select round(cast((select cntr_value from [master].[sys].[dm_os_performance_counters] where instance_name like '_Total%' and counter_name like 'Log File(s) Used Size (KB)%') - 
(select cntr_value from [master].[sys].[dm_os_performance_counters] where instance_name like 'tempdb%' and counter_name like 'Log File(s) Used Size (KB)%')as float)/1048576,2))[Total_Log_Size_Used_GB]
,(select  count(*)-4 from master.sys.databases with (nolock) where name not like 'uhtdba')[User_Database_Count]
,isnull(ltrim((Select distinct substring((select ', '+ST1.name  AS [text()] From master.sys.databases ST1 where name not in ('master','tempdb','msdb','model','uhtdba') ORDER BY name For XML PATH ('')), 2, 1000)
       From master.sys.databases ST2 with (nolock))),'') as [Databases]
,SERVERPROPERTY('InstanceDefaultDataPath')[Default_Data_Path],SERVERPROPERTY('InstanceDefaultLogPath')[Default_Log_Path]
,CASE WHEN SERVERPROPERTY('IsIntegratedSecurityOnly')=1 Then 'Windows Auth' else 'Windows/SQL Auth' END [Login_Security]
,SERVERPROPERTY('Collation')[Default_Collation] 
,CASE WHEN SERVERPROPERTY('HadrManagerStatus')=1 Then 'Started' else'Not Started' END [AlwaysOn_Manager_Status]
,CASE WHEN SERVERPROPERTY('IsHadrEnabled')=1 Then 'Enabled' else'Disabled' END [AlwaysOn_Feature_Status]
,CASE WHEN SERVERPROPERTY('IsFullTextInstalled')=1 Then 'Installed' else'Not Installed' END [IsFullTextInstalled]
,CASE WHEN SERVERPROPERTY('FilestreamConfiguredLevel')=1 Then 'Enabled' else'Disabled' END [FilestreamConfiguredLevel]" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 20 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Instances_Details] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 20 -ErrorAction 'Stop'
Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Instances_Details] select * from [DBA_Watcher_DB].[General].[SQL_Instances_Details_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Instances_Details_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Instances_Details_Current]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[TimeZone],[DomainName],[IP_Address],[Port]
        ,[CPU_Count],[PhysicalMemory_MB],[Clustered],[Server_Type],[SQLVersion],[SP],[Version],[Build_Level],[Edition],[LastRestartTime],[Install_Date]
        ,[SQL_Agent_Status],[WindowsVersionBuild],[Total_Data_Size_GB],[Total_Log_Size_GB],[Total_Log_Size_Used_GB],[User_Database_Count],[Databases]
        ,[Default_Data_Path],[Default_Log_Path],[Login_Security],[Default_Collation],[AlwaysOn_Manager_Status],[AlwaysOn_Feature_Status],[IsFullTextInstalled]
        ,[FilestreamConfiguredLevel]) VALUES ('"+$resultList.SQL_Instance_Name +"','"+$resultList.AlwaysOn +"',cast(getdate() as smalldatetime),'"+$resultList.TimeZone +"'
        ,'"+$resultList.DomainName +"','"+$resultList.IP_Address +"','"+$resultList.Port +"','"+$resultList.CPU_Count +"','"+$resultList.PhysicalMemory_MB +"'
        ,'"+$resultList.Clustered +"','"+$resultList.Server_Type +"','"+$resultList.SQLVersion +"','"+$resultList.SP +"','"+$resultList.Version +"','"+$resultList.Build_Level +"'
        ,'"+$resultList.Edition +"','"+$resultList.LastRestartTime +"','"+$resultList.Install_Date +"','"+$resultList.SQL_Agent_Status +"','"+$resultList.WindowsVersionBuild +"'
        ,'"+$resultList.Total_Data_Size_GB +"','"+$resultList.Total_Log_Size_GB +"','"+$resultList.Total_Log_Size_Used_GB +"','"+$resultList.User_Database_Count +"'
        ,'"+$resultList.Databases +"','"+$resultList.Default_Data_Path +"','"+$resultList.Default_Log_Path +"','"+$resultList.Login_Security +"','"+$resultList.Default_Collation +"'
        ,'"+$resultList.AlwaysOn_Manager_Status +"','"+$resultList.AlwaysOn_Feature_Status +"','"+$resultList.IsFullTextInstalled +"','"+$resultList.FilestreamConfiguredLevel +"')"
        Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Instances_Details_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Instances_Details] select * from [DBA_Watcher_DB].[General].[SQL_Instances_Details_Current] with (nolock) where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

