Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "select cast(SERVERPROPERTY('ServerName') as varchar) [SQL_Instance_Name],''[AlwaysOn], cast(getdate() as smalldatetime) as [Pull_Time], db_name(mf.database_id) as database_name ,mf.state_desc ,mf.type_desc,mf.name
	,mf.physical_name,growth,is_percent_growth,round(cast(vfs.size_on_disk_bytes as float) / 1073741824, 2) as [Size_on_disk_GB], vs.volume_mount_point AS [Drive],
	vs.logical_volume_name AS [Drive_Name], vs.total_bytes/1024/1024/1024 AS [Drive_Size_GB], vs.available_bytes/1024/1024/1024 AS [Drive_Free_Space_GB]
	,round(((cast(vs.total_bytes as float)-cast(vs.available_bytes as float))/cast(vs.total_bytes as float))*100 ,0)as [Drive_Full_Percent]
	,round(cast(vfs.num_of_bytes_written as float) / 1073741824, 2) as [GB_Written]	,round(cast(vfs.num_of_bytes_read as float) / 1073741824, 2) as [GB_Read]
	,cast(vfs.io_stall_write_ms as bigint)[io_stall_write_ms],cast(vfs.io_stall_read_ms as bigint)[io_stall_read_ms]
	,WriteLatency = cast(CASE WHEN num_of_writes = 0 THEN 0 ELSE (io_stall_write_ms / num_of_writes) END  as float)
	,ReadLatency = cast(CASE WHEN num_of_reads = 0 THEN 0 ELSE (io_stall_read_ms / num_of_reads) END  as float)
	,Latency = cast(CASE WHEN (num_of_reads = 0 AND num_of_writes = 0) THEN 0 ELSE (io_stall / (num_of_reads + num_of_writes)) END  as float)
	,AvgMBPerRead = CASE WHEN num_of_reads = 0 THEN 0 ELSE round(cast((num_of_bytes_read / num_of_reads) as float) / 1048576, 2) END
	,AvgMBPerWrite = CASE WHEN io_stall_write_ms = 0 THEN 0 ELSE round(cast((num_of_bytes_written / num_of_writes) as float) / 1048576, 2) END 
	from sys.master_files mf
	join sys.dm_io_virtual_file_stats(NULL, NULL) vfs
	on mf.database_id=vfs.database_id and mf.file_id=vfs.file_id
	CROSS APPLY sys.dm_os_volume_stats(mf.database_id, mf.file_id) AS vs
    order by database_name, mf.type, mf.physical_name" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 30 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Database_File_Details] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 20 -ErrorAction 'Stop'
Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB_Tempdb].[Scratch].[SQL_Database_File_Details] select * from [DBA_Watcher_DB].[General].[SQL_Database_File_Details_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Database_File_Details_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Database_File_Details_Current]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[database_name],[state_desc],[type_desc],[name]
        ,[physical_name],[growth],[is_percent_growth],[Size_on_disk_GB],[Drive],[Drive_Name],[Drive_Size_GB],[Drive_Free_Space_GB],[Drive_Full_Percent]
        ,[GB_Written],[GB_Read],[io_stall_write_ms],[io_stall_read_ms],[WriteLatency],[ReadLatency],[Latency],[AvgMBPerRead],[AvgMBPerWrite]) VALUES
        ('"+$resultList.SQL_Instance_Name +"','"+$resultList.AlwaysOn +"',cast(getdate() as smalldatetime),'"+$resultList.database_name +"','"+$resultList.state_desc +"'
        ,'"+$resultList.type_desc +"','"+$resultList.name +"','"+$resultList.physical_name +"','"+$resultList.growth +"','"+$resultList.is_percent_growth +"'
        ,'"+$resultList.Size_on_disk_GB +"','"+$resultList.Drive +"','"+$resultList.Drive_Name +"','"+$resultList.Drive_Size_GB +"','"+$resultList.Drive_Free_Space_GB +"'
        ,'"+$resultList.Drive_Full_Percent +"','"+$resultList.GB_Written +"','"+$resultList.GB_Read +"','"+$resultList.io_stall_write_ms +"','"+$resultList.io_stall_read_ms +"'
        ,'"+$resultList.WriteLatency +"','"+$resultList.ReadLatency +"','"+$resultList.Latency +"','"+$resultList.AvgMBPerRead +"','"+$resultList.AvgMBPerWrite +"')"
        Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 90 -ErrorAction SilentlyContinue 
}

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Database_File_Details_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Database_File_Details] select * from [DBA_Watcher_DB].[General].[SQL_Database_File_Details_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

