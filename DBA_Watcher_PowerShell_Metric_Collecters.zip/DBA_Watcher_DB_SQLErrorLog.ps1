Set-ExecutionPolicy unrestricted
Import-Module SQLPS

$IList = Invoke-Sqlcmd -Query "SELECT [DNS] as [SQL_Instance_Name],[collector_username],[collector_password] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone]" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

$result = foreach ($instance in $IList){
invoke-Sqlcmd -ServerInstance $instance.SQL_Instance_Name -Query "CREATE TABLE #ErrorLog (LogDate DateTime, ProcessInfo Varchar(40), [Text] varchar(4000))
DECLARE @sql nvarchar (1000)
SET @sql = 'INSERT INTO #ErrorLog EXEC master.dbo.xp_readerrorlog 0, 1, NULL, NULL, N''' + rtrim(cast(DATEADD(MINUTE,-5,GETDATE()) as char)) + ''', N''' + rtrim(cast(getdate() as char))+''', ''desc'''
EXEC sp_executesql @sql
Select DISTINCT top 200 cast(SERVERPROPERTY('ServerName') as varchar) [SQL_Instance_Name],''[AlwaysOn], cast(getdate() as smalldatetime) as [Pull_Time]
, cast(LogDate as smalldatetime)[LogDate], ProcessInfo, REPLACE(Text, '''', '') as [Text] FROM #ErrorLog where [Text] not like '%dbghelp%' and 
[Text] not like '%SQL Trace%'
order by LogDate desc
drop table #ErrorLog" -Username $instance.collector_username -Password $instance.collector_password -QueryTimeout 90 -ErrorAction SilentlyContinue
}

Invoke-Sqlcmd -Query "delete from [DBA_Watcher_DB].[General].[SQL_Server_ErrorLog_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

foreach ($resultList in $result){ 
        $sql = "INSERT INTO [DBA_Watcher_DB].[General].[SQL_Server_ErrorLog_Current]([SQL_Instance_Name],[AlwaysOn],[Pull_Time],[LogDate],[ProcessInfo],[Text]) VALUES ('"+ $resultList.SQL_Instance_Name+"','"+$resultList.AlwaysOn+"', cast(getdate() as smalldatetime), '"+$resultList.LogDate +"'
        , '"+$resultList.ProcessInfo +"', '"+$resultList.Text +"')"
        Invoke-Sqlcmd -ServerInstance "localhost" -Query $sql -QueryTimeout 90 -ErrorAction 'Stop'
}

Invoke-Sqlcmd -Query "update i
        set i.[AlwaysOn] = 'Primary'
        from [DBA_Watcher_DB].[General].[SQL_Server_ErrorLog_Current] i with(nolock)
        join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with(nolock) on i.[SQL_Instance_Name] = si.[SQL_Instance_Name] 
        where si.dns_name_desc like '% Main%' and i.SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction SilentlyContinue

Invoke-Sqlcmd -Query "insert into [DBA_Watcher_DB].[General].[SQL_Server_ErrorLog] select * from [DBA_Watcher_DB].[General].[SQL_Server_ErrorLog_Current] where SQL_Instance_Name in (SELECT [SQL_Instance_Name] FROM [DBA_Watcher_DB].[dbo].[Inventory_StandAlone])" -ServerInstance "localhost" -QueryTimeout 30 -ErrorAction 'Stop'

