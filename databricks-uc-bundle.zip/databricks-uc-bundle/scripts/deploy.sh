#!/bin/bash
# Deploy the Unity Catalog bundle to the specified target
set -euo pipefail
TARGET=${1:-dev}
echo "🚀 Deploying Unity Catalog bundle to: $TARGET"
databricks bundle deploy -t "$TARGET"
echo "✅ Deployment complete for: $TARGET"
