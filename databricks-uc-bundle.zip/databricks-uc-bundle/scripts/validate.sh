#!/bin/bash
# Validate the Databricks Asset Bundle before deployment
set -euo pipefail
TARGET=${1:-dev}
echo "🔍 Validating bundle for target: $TARGET"
databricks bundle validate -t "$TARGET"
echo "✅ Validation passed for: $TARGET"
