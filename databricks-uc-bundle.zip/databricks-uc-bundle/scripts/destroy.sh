#!/bin/bash
# Destroy all bundle resources — USE WITH EXTREME CAUTION
set -euo pipefail
TARGET=${1:-dev}
echo "⚠️  WARNING: This will DESTROY all UC resources in target: $TARGET"
read -r -p "Type the environment name to confirm: " CONFIRM
if [ "$CONFIRM" != "$TARGET" ]; then
  echo "❌ Aborted — environment name did not match."
  exit 1
fi
databricks bundle destroy -t "$TARGET"
echo "🗑️  Destroy complete for: $TARGET"
