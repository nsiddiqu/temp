# Databricks Unity Catalog Automation — Asset Bundle

Manages all Unity Catalog objects across **Dev** and **Prod** environments
using **Databricks Asset Bundles (DAB)**, deployed via **Azure DevOps**.

---

## Managed UC Objects

| Object | Bundle File |
|---|---|
| Storage Credentials | `bundles/unity_catalog/storage_credentials/` |
| External Locations | `bundles/unity_catalog/external_locations/` |
| Catalogs | `bundles/unity_catalog/catalogs/` |
| Schemas | `bundles/unity_catalog/schemas/` |
| Tables & Views | `bundles/unity_catalog/tables/` |
| Grants / RBAC | `bundles/unity_catalog/grants/` |

---

## Prerequisites

- Databricks CLI v0.221+
  ```bash
  curl -fsSL https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sh
  ```
- Databricks PAT with **metastore admin** or **catalog admin** privilege
- Azure Databricks Access Connector assigned **Storage Blob Data Contributor** on ADLS Gen2

---

## Local Development

```bash
export DATABRICKS_HOST=https://adb-<workspace-id>.azuredatabricks.net
export DATABRICKS_TOKEN=<your-pat>

# Validate
databricks bundle validate -t dev

# Deploy to dev
databricks bundle deploy -t dev

# Destroy dev (careful!)
./scripts/destroy.sh dev
```

---

## Azure DevOps Setup

### 1. Variable Group
Create **`databricks-unity-catalog-secrets`** in Pipelines → Library:

| Variable | Description |
|---|---|
| `DATABRICKS_HOST_DEV` | Dev workspace URL |
| `DATABRICKS_TOKEN_DEV` | Dev PAT (mark as secret) |
| `DATABRICKS_HOST_PROD` | Prod workspace URL |
| `DATABRICKS_TOKEN_PROD` | Prod PAT (mark as secret) |

### 2. Environments
Create two environments in Pipelines → Environments:
- **`databricks-dev`** — no approval required
- **`databricks-prod`** — add required reviewer approval gate

### 3. Branch Strategy

| Branch | Pipeline Behaviour |
|---|---|
| `feature/*` | Validate only (PR check) |
| `develop` | Validate + Deploy to Dev |
| `main` | Validate + Deploy to Dev + Manual Approval + Deploy to Prod |

---

## Project Structure

```
databricks-uc-bundle/
├── databricks.yml                                  # Root bundle config & env targets
├── README.md
├── .gitignore
│
├── .azure/
│   └── pipelines/
│       └── unity-catalog-pipeline.yml              # Azure DevOps CI/CD pipeline
│
├── bundles/
│   └── unity_catalog/
│       ├── storage_credentials/
│       │   └── storage_credentials.yml             # Azure MI-based credentials
│       ├── external_locations/
│       │   └── external_locations.yml              # ADLS Gen2 external locations
│       ├── catalogs/
│       │   └── catalogs.yml                        # UC catalogs (main + sandbox)
│       ├── schemas/
│       │   └── schemas.yml                         # Medallion schemas (raw/silver/gold)
│       ├── tables/
│       │   └── tables.yml                          # External tables + managed tables + views
│       └── grants/
│           └── grants.yml                          # RBAC grants across all objects
│
├── config/
│   ├── dev/
│   │   └── dev.yml                                 # Dev variable overrides
│   └── prod/
│       └── prod.yml                                # Prod variable overrides
│
└── scripts/
    ├── validate.sh                                 # Local validate helper
    ├── deploy.sh                                   # Local deploy helper
    └── destroy.sh                                  # Destroy with confirmation prompt
```
