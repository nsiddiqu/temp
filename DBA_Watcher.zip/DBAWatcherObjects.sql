
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Config].[SQL_Inventory](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Date_Added] [smalldatetime] NULL,
	[Login_Domain] [varchar](20) NULL,
	[Department] [varchar](50) NULL,
	[Status] [varchar](50) NULL,
	[Peak] [varchar](10) NULL,
	[OnShore] [varchar](20) NULL,
	[Priority_Level] [varchar](50) NULL,
	[Enabled] [varchar](1) NULL,
	[Team] [varchar](50) NULL,
	[DNS] [varchar](250) NULL,
	[IP_Address] [sql_variant] NULL,
	[Host] [varchar](50) NULL,
	[Clustered] [varchar](10) NULL,
	[DNS_Name] [varchar](50) NULL,
	[DNS_Name_desc] [varchar](200) NULL,
	[LastRestartTime] [smalldatetime] NULL,
	[LastFailoverTime] [smalldatetime] NULL,
	[Next_Windows_Patch] [varchar](500) NULL,
	[Maintainence_Window] [varchar](500) NULL,
	[Location] [varchar](50) NULL,
	[Ask_id] [varchar](50) NULL,
	[CI] [varchar](50) NULL,
	[Application_Name] [varchar](300) NULL,
	[CPU_Count] [int] NOT NULL,
	[PhysicalMemory_GB] [bigint] NULL,
	[SQLMaxMemory_GB] [bigint] NULL,
	[SQLVersion] [varchar](50) NULL,
	[Version] [sql_variant] NULL,
	[OSDescription] [varchar](200) NULL,
	[Backup_Location] [varchar](200) NULL,
	[Service_Level_Owner] [varchar](254) NULL,
	[Service_Level_Owner_Email] [varchar](254) NULL,
	[Customer_Email] [varchar](500) NULL,
	[PriorityLevel] [varchar](5) NULL,
	[parentVcenter] [varchar](500) NULL,
	[parentCluster] [varchar](500) NULL,
	[parentDatacenter] [varchar](500) NULL,
	[numa_node_count] [int] NULL,
	[Notes] [varchar](4000) NULL,
	[SQL_Patch_Windows] [varchar](100) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Settings].[Monitoring_Override]    Script Date: 6/6/2026 9:22:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Settings].[Monitoring_Override](
	[SQL_Instance_Name] [varchar](50) NULL,
	[Username] [varchar](50) NULL,
	[Date_Entered] [datetime] NULL,
	[Start_Time] [datetime] NULL,
	[End_Time] [datetime] NULL,
	[Reason] [varchar](500) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240814-064058]    Script Date: 6/6/2026 9:22:38 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240814-064058] ON [Settings].[Monitoring_Override]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Settings].[Pager]    Script Date: 6/6/2026 9:22:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Settings].[Pager](
	[DBA_Name] [varchar](50) NULL,
	[Pager_email] [varchar](50) NULL,
	[email] [varchar](50) NULL,
	[Default] [varchar](1) NULL,
	[enabled] [varchar](1) NULL,
	[TOD] [varchar](1) NULL,
	[Date_Entered] [datetime] NULL,
	[Start_Time] [datetime] NULL,
	[End_Time] [datetime] NULL,
	[OGA_Oncall] [varchar](50) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240813-160955]    Script Date: 6/6/2026 9:22:38 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240813-160955] ON [Settings].[Pager]
(
	[Start_Time] ASC,
	[DBA_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  View [dbo].[Pager]    Script Date: 6/6/2026 9:22:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO










CREATE view [dbo].[Pager] as
select ''+ isnull(ltrim((Select distinct substring((select  distinct ' '+ST1.[Pager_email]  AS [text()] From [DBA_Watcher_DB].[Settings].[Pager] ST1 
Where [enabled] = 'y' and ([Default] = 'y' or ((getdate()>[Start_Time] and getdate()<[End_Time]) 
and (CASE WHEN CONVERT(TIME, GETDATE()) >'8:00:00' and CONVERT(TIME, GETDATE()) <'20:00:00' THEN 'd' else 'n' end) like [TOD]))
ORDER BY ' '+ST1.[Pager_email]  For XML PATH ('')), 2, 1000)
From [DBA_Watcher_DB].[Settings].[Pager] ST2 with (nolock))),'') +' '+


isnull(ltrim((Select distinct substring((select  distinct ' '+ST1.[email]  AS [text()] From [DBA_Watcher_DB].[Settings].[Pager] ST1 
Where [enabled] = 'y' and ((getdate()>[Start_Time] and getdate()<[End_Time]) 
and (CASE WHEN CONVERT(TIME, GETDATE()) >'8:00:00' and CONVERT(TIME, GETDATE()) <'20:00:00' THEN 'd' else 'n' end) like [TOD])
ORDER BY ' '+ST1.[email]  For XML PATH ('')), 2, 1000)
From [DBA_Watcher_DB].[Settings].[Pager] ST2 with (nolock))),'')  +'' as [Pager_String]

GO
/****** Object:  Table [External].[Patching_Windows]    Script Date: 6/6/2026 9:22:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [External].[Patching_Windows](
	[Server] [varchar](500) NULL,
	[Deployment] [varchar](500) NULL,
	[Change] [varchar](500) NULL,
	[Patch Status] [varchar](500) NULL,
	[Customer Status] [varchar](500) NULL,
	[Incident] [varchar](500) NULL,
	[PEX] [varchar](500) NULL,
	[Opted Out] [varchar](500) NULL,
	[Notes] [varchar](500) NULL,
	[Server Start Time] [smalldatetime] NULL,
	[Server End Time] [smalldatetime] NULL,
	[Window Start Time] [smalldatetime] NULL,
	[Window End Time] [smalldatetime] NULL,
	[Pipeline Status] [varchar](500) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240814-064118]    Script Date: 6/6/2026 9:22:38 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240814-064118] ON [External].[Patching_Windows]
(
	[Server] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Settings].[General]    Script Date: 6/6/2026 9:22:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Settings].[General](
	[Team] [varchar](150) NULL,
	[group_email] [varchar](150) NULL,
	[reply_to] [varchar](150) NULL,
	[SQL_username] [varchar](150) NULL,
	[SQL_password] [varchar](150) NULL,
	[windows_username] [varchar](150) NULL,
	[windows_password] [varchar](150) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240814-064000]    Script Date: 6/6/2026 9:22:38 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240814-064000] ON [Settings].[General]
(
	[Team] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  View [dbo].[Inventory_All_Server]    Script Date: 6/6/2026 9:22:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO









CREATE view [dbo].[Inventory_All_Server] as

SELECT [SQL_Instance_Name],[DNS],[SQL_username] as [collector_username] ,[SQL_password] as [collector_password],[group_email],[reply_to]
FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
inner join [DBA_Watcher_DB].[Settings].[General] ss with (nolock) on si.Team = ss.Team
where [enabled] = 'y' and [SQL_Instance_Name] not in (select [SQL_Instance_Name] 
from [DBA_Watcher_DB].[Settings].[Monitoring_Override] with (nolock) where getdate()>[Start_Time]  and getdate()<[End_Time])


GO
/****** Object:  View [dbo].[Inventory_All_Prod]    Script Date: 6/6/2026 9:22:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






create view [dbo].[Inventory_All_Prod] as
SELECT distinct si.[SQL_Instance_Name],si.[AlwaysOn],[Date_Added],[Login_Domain],[Department],ltrim(''+[OnShore]+' '+[Department]+'') as [Department_Detail],[Status],[Peak],si.[Priority_Level],[Enabled],[Team],si.[DNS]
,[IP_Address],si.[Host],[Clustered],[DNS_Name],[DNS_Name_desc],[LastRestartTime],[LastFailoverTime],[Next_Windows_Patch],[Maintainence_Window]
,[Location],[Ask_id],[CI],[Application_Name],[CPU_Count],[numa_node_count],[PhysicalMemory_GB],[SQLMaxMemory_GB],[SQLVersion],[Version],[OSDescription]
,[Backup_Location],[Service_Level_Owner],[Service_Level_Owner_Email],[Customer_Email],''+[group_email]  +' ' + ISNULL([Customer_Email], '') +'' as [Customer_Email_group]
,[PriorityLevel],[parentVcenter]
,isnull(sp.Deployment,'') as [Patch], case when sp.Deployment is null then '' else '[Patch]' END as [Patchtime]
,case when dns_name_desc like '' then si.[SQL_Instance_Name] else dns_name_desc END as [role_desc],ltrim(''+ OnShore + [PriorityLevel] +' '+ (CASE WHEN [Department] like '%prod%' Then 'Prod' else 'Dev' END) +'') as [DepartmentShort]
,[group_email],[reply_to], ww.[collector_username], ww.[collector_password],(SELECT [Pager_String] FROM [DBA_Watcher_DB].[dbo].[Pager]) as [Pager]
FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock) 
left outer join [DBA_Watcher_DB].[dbo].[Inventory_All_Server] ww on si.SQL_Instance_Name = ww.SQL_Instance_Name
left outer join [DBA_Watcher_DB].[External].[Patching_Windows] sp with (nolock) on sp.Server = cast(si.SQL_Instance_Name as varchar) and 
	getdate() between convert(varchar, [Window Start Time], 109) and convert(varchar, [Window End Time], 109)
where [enabled] = 'y' and department like 'prod%' and si.[SQL_Instance_Name] not in (select [SQL_Instance_Name] 
from [DBA_Watcher_DB].[Settings].[Monitoring_Override] with (nolock) where getdate()>[Start_Time]  and getdate()<[End_Time])
GO
/****** Object:  View [dbo].[Inventory_TAS_DMZ]    Script Date: 6/6/2026 9:22:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE   view [dbo].[Inventory_TAS_DMZ] as
SELECT [SQL_Instance_Name],[DNS],[SQL_username] as [collector_username] ,[SQL_password] as [collector_password]
FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
inner join [DBA_Watcher_DB].[Settings].[General] ss with (nolock) on si.Team = ss.Team
where [enabled] = 'y' and ([Login_Domain] like 'TAS' or [Login_Domain] like 'DMZ' or [Login_Domain] like 'SXC' or [Login_Domain] like 'Diplomat') and [SQL_Instance_Name] not in (select [SQL_Instance_Name]
from [DBA_Watcher_DB].[Settings].[Monitoring_Override] with (nolock) where getdate()>[Start_Time]  and getdate()<[End_Time])
GO
/****** Object:  Table [General].[SQL_Statistics_Memory_History]    Script Date: 6/6/2026 9:22:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Statistics_Memory_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[TotalPhysicalMemory_MB] [bigint] NULL,
	[AvailablePhysicalMemory_MB] [bigint] NULL,
	[SQL_ReservedMemory_MB] [bigint] NULL,
	[SQL_CommittedMemory_MB] [bigint] NULL,
	[TotalPageFile_MB] [bigint] NULL,
	[AvailablePageFile_MB] [bigint] NULL,
	[TotalVirtualAddressSpace_MB] [bigint] NULL,
	[AvailableVirtualAddressSpace_MB] [bigint] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240819-145025]    Script Date: 6/6/2026 9:22:38 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240819-145025] ON [General].[SQL_Statistics_Memory_History]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Statistics_Memory]    Script Date: 6/6/2026 9:22:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Statistics_Memory](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[TotalPhysicalMemory_MB] [bigint] NULL,
	[AvailablePhysicalMemory_MB] [bigint] NULL,
	[SQL_ReservedMemory_MB] [bigint] NULL,
	[SQL_CommittedMemory_MB] [bigint] NULL,
	[TotalPageFile_MB] [bigint] NULL,
	[AvailablePageFile_MB] [bigint] NULL,
	[TotalVirtualAddressSpace_MB] [bigint] NULL,
	[AvailableVirtualAddressSpace_MB] [bigint] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240819-145001]    Script Date: 6/6/2026 9:22:38 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240819-145001] ON [General].[SQL_Statistics_Memory]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  View [General].[SQL_Statistics_Memory_View]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [General].[SQL_Statistics_Memory_View]
   AS
SELECT [SQL_Instance_Name],[Pull_Time],[TotalPhysicalMemory_MB],[AvailablePhysicalMemory_MB],[SQL_ReservedMemory_MB]
,[SQL_CommittedMemory_MB],[TotalPageFile_MB],[AvailablePageFile_MB],[TotalVirtualAddressSpace_MB],[AvailableVirtualAddressSpace_MB]
FROM [DBA_Watcher_DB].[General].[SQL_Statistics_Memory] with (nolock)
union
SELECT [SQL_Instance_Name],[Pull_Time],[TotalPhysicalMemory_MB],[AvailablePhysicalMemory_MB],[SQL_ReservedMemory_MB]
,[SQL_CommittedMemory_MB],[TotalPageFile_MB],[AvailablePageFile_MB],[TotalVirtualAddressSpace_MB],[AvailableVirtualAddressSpace_MB]
FROM [DBA_Watcher_DB].[General].[SQL_Statistics_Memory_History] with (nolock)
Union
SELECT si.DNS_Name as [SQL_Instance_Name],[Pull_Time],[TotalPhysicalMemory_MB],[AvailablePhysicalMemory_MB],[SQL_ReservedMemory_MB]
,[SQL_CommittedMemory_MB],[TotalPageFile_MB],[AvailablePageFile_MB],[TotalVirtualAddressSpace_MB],[AvailableVirtualAddressSpace_MB]
FROM [DBA_Watcher_DB].[General].[SQL_Statistics_Memory] ao with (nolock)
join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock) on ao.SQL_Instance_Name = si.SQL_Instance_Name and ao.AlwaysOn = 'Primary'
union
SELECT si.DNS_Name as [SQL_Instance_Name],[Pull_Time],[TotalPhysicalMemory_MB],[AvailablePhysicalMemory_MB],[SQL_ReservedMemory_MB]
,[SQL_CommittedMemory_MB],[TotalPageFile_MB],[AvailablePageFile_MB],[TotalVirtualAddressSpace_MB],[AvailableVirtualAddressSpace_MB]
FROM [DBA_Watcher_DB].[General].[SQL_Statistics_Memory_History] ao with (nolock)
join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock) on ao.SQL_Instance_Name = si.SQL_Instance_Name and ao.AlwaysOn = 'Primary'

GO
/****** Object:  View [dbo].[Inventory_StandAlone]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE view [dbo].[Inventory_StandAlone] as
SELECT [SQL_Instance_Name],[DNS],[SQL_username] as [collector_username] ,[SQL_password] as [collector_password]
FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
inner join [DBA_Watcher_DB].[Settings].[General] ss with (nolock) on si.Team = ss.Team
where [enabled] = 'y' and [SQL_Instance_Name] not in (select [SQL_Instance_Name] 
from [DBA_Watcher_DB].[Settings].[Monitoring_Override] with (nolock) where getdate()>[Start_Time]  and getdate()<[End_Time])
GO
/****** Object:  Table [Team].[Team_Patching]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Team].[Team_Patching](
	[SQL_Instance_Name] [varchar](50) NULL,
	[Version] [varchar](50) NULL,
	[DBA_Name] [varchar](50) NULL,
	[Updated] [datetime] NULL,
	[Emailed] [varchar](200) NULL,
	[Change] [varchar](200) NULL,
	[Change_Status] [varchar](200) NULL,
	[Change_Time] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[Inventory_All]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO













CREATE view [dbo].[Inventory_All] as
SELECT distinct si.[SQL_Instance_Name],si.[AlwaysOn],[Date_Added],[Login_Domain],[Department],ltrim((case when OnShore = '' then OnShore else ' ' + OnShore end) + (case when [PriorityLevel] = '' then [PriorityLevel] else ' ' + [PriorityLevel] end) +' '+ [Department]) as [Department_Detail],[Status],[Peak],si.[Priority_Level],[Enabled],[Team],si.[DNS]
,[IP_Address],si.[Host],[Clustered],[DNS_Name],[DNS_Name_desc],[LastRestartTime],[LastFailoverTime],[Next_Windows_Patch],[Maintainence_Window]
,[Location],si.[Ask_id],[CI],[Application_Name],[CPU_Count],[numa_node_count],[PhysicalMemory_GB],[SQLMaxMemory_GB],[SQLVersion],si.[Version],[OSDescription]
,[Backup_Location],[Service_Level_Owner],[Service_Level_Owner_Email],[Customer_Email],''+[group_email]  +' ' + ISNULL([Customer_Email], '') +'' as [Customer_Email_group]
,[PriorityLevel],[parentVcenter]
,case when sp.Deployment is not null then isnull(sp.Deployment,'') when tp.Change is not null then tp.Change else '' end as [Patch], case when sp.Deployment is not null then '[Patch]' when tp.change is not null then '[Patch]' else '' END as [Patchtime]
,case when dns_name_desc like '' then si.[SQL_Instance_Name] else dns_name_desc END as [role_desc]
,ltrim(''+ Login_Domain + (case when OnShore = '' then OnShore else ' ' + OnShore end) + (case when [PriorityLevel] = '' then [PriorityLevel] else ' ' + [PriorityLevel] end) +' '+ (CASE WHEN [Department] like '%prod%' Then 'Prod' else 'Dev' END) +'') as [DepartmentShort]
,ltrim('' +(case when OnShore = '' then OnShore else ' ' + OnShore end) + ' '+ (CASE WHEN [Department] like '%prod%' Then 'Prod' else 'Dev' END) +'') as [DepartmentShort2]
,[group_email],[reply_to], ww.[collector_username], ww.[collector_password],(SELECT [Pager_String] FROM [DBA_Watcher_DB].[dbo].[Pager]) as [Pager], apd.[service_workgroup_name] as "workgroup"
FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock) 
left outer join [DBA_Watcher_DB].[dbo].[Inventory_All_Server] ww on si.SQL_Instance_Name = ww.SQL_Instance_Name
left outer join [DBA_Watcher_ServiceNow].[ServiceNow].[aide_plus_detail] apd with (nolock) on si.Ask_id = apd.ask_id
left outer join [DBA_Watcher_DB].[External].[Patching_Windows] sp with (nolock) on sp.Server = cast(si.SQL_Instance_Name as varchar) and 
	getdate() between convert(varchar, [Window Start Time], 109) and convert(varchar, [Window End Time], 109)
left outer join [DBA_Watcher_DB].[Team].[Team_Patching] tp with (nolock) on tp.SQL_Instance_Name = si.SQL_Instance_Name and 
	getdate() between [Change_Time] and DateAdd(Hour, 4 , tp.[Change_Time] ) and [Change_Status] not like 'Closed' 
	and [Change_Status] not like 'Draft' 
where [enabled] = 'y' and si.[SQL_Instance_Name] not in (select [SQL_Instance_Name] 
from [DBA_Watcher_DB].[Settings].[Monitoring_Override] with (nolock) where getdate()>[Start_Time]  and getdate()<[End_Time])
GO
/****** Object:  View [dbo].[Inventory_Complete]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE view [dbo].[Inventory_Complete] as
SELECT [SQL_Instance_Name],[DNS],[SQL_username] as [collector_username] ,[SQL_password] as [collector_password]
FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
inner join [DBA_Watcher_DB].[Settings].[General] ss with (nolock) on si.Team = ss.Team
where [enabled] = 'y' and [SQL_Instance_Name] not in (select [SQL_Instance_Name] 
from [DBA_Watcher_DB].[Settings].[Monitoring_Override] with (nolock) where getdate()>[Start_Time]  and getdate()<[End_Time])
GO
/****** Object:  View [dbo].[Inventory_Check]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE view [dbo].[Inventory_Check] as
SELECT [SQL_Instance_Name],[DNS],[SQL_username] as [collector_username] ,[SQL_password] as [collector_password]
FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
inner join [DBA_Watcher_DB].[Settings].[General] ss with (nolock) on si.Team = ss.Team
where [enabled] = 'n' and Login_Domain not like 'OFE' and Login_Domain not like 'Mongo' and Login_Domain not like 'OWCA_FED'
GO
/****** Object:  Table [General].[SQL_Database_AlwaysOn_History]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_AlwaysOn_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[dns_name] [nvarchar](100) NULL,
	[ag_name] [varchar](50) NULL,
	[replica_server_name] [varchar](50) NULL,
	[database_name] [varchar](50) NULL,
	[log_send_queue_size] [bigint] NULL,
	[log_send_rate] [bigint] NULL,
	[redo_queue_size] [bigint] NULL,
	[redo_rate] [bigint] NULL,
	[last_sent_time] [datetime] NULL,
	[last_received_time] [datetime] NULL,
	[role_desc] [nvarchar](100) NULL,
	[database_state_desc] [nvarchar](100) NULL,
	[availability_mode_desc] [nvarchar](100) NULL,
	[failover_mode_desc] [nvarchar](100) NULL,
	[automated_backup_preference_desc] [nvarchar](100) NULL,
	[synchronization_state_desc] [nvarchar](100) NULL,
	[synchronization_health_desc] [nvarchar](100) NULL,
	[secondary_role_allow_connections_desc] [nvarchar](100) NULL,
	[last_commit_time] [datetime] NULL,
	[health_check_timeout] [int] NULL,
	[is_suspended] [bit] NULL,
	[endpoint_url] [nvarchar](500) NULL,
	[join_state_desc] [nvarchar](100) NULL,
	[connected_state_desc] [nvarchar](100) NULL,
	[failure_condition_level] [int] NULL,
	[create_date] [datetime] NULL,
	[modify_date] [datetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-091614]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-091614] ON [General].[SQL_Database_AlwaysOn_History]
(
	[SQL_Instance_Name] ASC,
	[dns_name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Database_AlwaysOn]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_AlwaysOn](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[dns_name] [nvarchar](100) NULL,
	[ag_name] [varchar](50) NULL,
	[replica_server_name] [varchar](50) NULL,
	[database_name] [varchar](50) NULL,
	[log_send_queue_size] [bigint] NULL,
	[log_send_rate] [bigint] NULL,
	[redo_queue_size] [bigint] NULL,
	[redo_rate] [bigint] NULL,
	[last_sent_time] [datetime] NULL,
	[last_received_time] [datetime] NULL,
	[role_desc] [nvarchar](100) NULL,
	[database_state_desc] [nvarchar](100) NULL,
	[availability_mode_desc] [nvarchar](100) NULL,
	[failover_mode_desc] [nvarchar](100) NULL,
	[automated_backup_preference_desc] [nvarchar](100) NULL,
	[synchronization_state_desc] [nvarchar](100) NULL,
	[synchronization_health_desc] [nvarchar](100) NULL,
	[secondary_role_allow_connections_desc] [nvarchar](100) NULL,
	[last_commit_time] [datetime] NULL,
	[health_check_timeout] [int] NULL,
	[is_suspended] [bit] NULL,
	[endpoint_url] [nvarchar](500) NULL,
	[join_state_desc] [nvarchar](100) NULL,
	[connected_state_desc] [nvarchar](100) NULL,
	[failure_condition_level] [int] NULL,
	[create_date] [datetime] NULL,
	[modify_date] [datetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-091511]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-091511] ON [General].[SQL_Database_AlwaysOn]
(
	[SQL_Instance_Name] ASC,
	[dns_name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  View [General].[SQL_Database_AlwaysOn_View]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [General].[SQL_Database_AlwaysOn_View]
   AS
SELECT [SQL_Instance_Name],[Pull_Time],[dns_name],[ag_name],[replica_server_name],[database_name],[log_send_queue_size],[log_send_rate],[redo_queue_size],[redo_rate]
,[last_sent_time],[last_received_time],[role_desc],[database_state_desc],[availability_mode_desc],[failover_mode_desc],[automated_backup_preference_desc],[synchronization_state_desc]
,[synchronization_health_desc],[secondary_role_allow_connections_desc],[last_commit_time],[health_check_timeout],[is_suspended],[endpoint_url],[join_state_desc],[connected_state_desc]
,[failure_condition_level],[create_date],[modify_date]
FROM General.SQL_Database_AlwaysOn with (nolock)
union
SELECT [SQL_Instance_Name],[Pull_Time],[dns_name],[ag_name],[replica_server_name],[database_name],[log_send_queue_size],[log_send_rate],[redo_queue_size],[redo_rate]
,[last_sent_time],[last_received_time],[role_desc],[database_state_desc],[availability_mode_desc],[failover_mode_desc],[automated_backup_preference_desc],[synchronization_state_desc]
,[synchronization_health_desc],[secondary_role_allow_connections_desc],[last_commit_time],[health_check_timeout],[is_suspended],[endpoint_url],[join_state_desc],[connected_state_desc]
,[failure_condition_level],[create_date],[modify_date]
FROM General.SQL_Database_AlwaysOn_History with (nolock)
GO
/****** Object:  View [dbo].[Pager_all]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO











CREATE view [dbo].[Pager_all] as
select ''+ isnull(ltrim((Select distinct substring((select  distinct ' '+ST1.[Pager_email]  AS [text()] From [DBA_Watcher_DB].[Settings].[Pager] ST1 
ORDER BY ' '+ST1.[Pager_email]  For XML PATH ('')), 2, 1000)
From [DBA_Watcher_DB].[Settings].[Pager] ST2 with (nolock))),'') +' '+


isnull(ltrim((Select distinct substring((select  distinct ' '+ST1.[email]  AS [text()] From [DBA_Watcher_DB].[Settings].[Pager] ST1 
ORDER BY ' '+ST1.[email]  For XML PATH ('')), 2, 1000)
From [DBA_Watcher_DB].[Settings].[Pager] ST2 with (nolock))),'')  +'' as [Pager_String]

GO
/****** Object:  Table [Daily].[SQL_Stats_Extended]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Daily].[SQL_Stats_Extended](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[cpu_ticks] [bigint] NULL,
	[ms_ticks] [bigint] NULL,
	[cpu_count] [int] NULL,
	[hyperthread_ratio] [int] NULL,
	[physical_memory_kb] [bigint] NULL,
	[virtual_memory_kb] [bigint] NULL,
	[committed_kb] [bigint] NULL,
	[committed_target_kb] [bigint] NULL,
	[visible_target_kb] [bigint] NULL,
	[stack_size_in_bytes] [int] NULL,
	[os_quantum] [bigint] NULL,
	[os_error_mode] [int] NULL,
	[os_priority_class] [int] NULL,
	[max_workers_count] [int] NULL,
	[scheduler_count] [int] NULL,
	[scheduler_total_count] [int] NULL,
	[deadlock_monitor_serial_number] [int] NULL,
	[sqlserver_start_time_ms_ticks] [bigint] NULL,
	[sqlserver_start_time] [datetime] NULL,
	[affinity_type] [int] NULL,
	[affinity_type_desc] [nvarchar](100) NULL,
	[process_kernel_time_ms] [bigint] NULL,
	[process_user_time_ms] [bigint] NULL,
	[time_source] [int] NULL,
	[time_source_desc] [nvarchar](100) NULL,
	[virtual_machine_type] [int] NULL,
	[virtual_machine_type_desc] [nvarchar](100) NULL,
	[softnuma_configuration] [int] NULL,
	[softnuma_configuration_desc] [nvarchar](100) NULL,
	[sql_memory_model] [int] NULL,
	[sql_memory_model_desc] [nvarchar](100) NULL,
	[socket_count] [int] NULL,
	[cores_per_socket] [int] NULL,
	[numa_node_count] [int] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240809-071721]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240809-071721] ON [Daily].[SQL_Stats_Extended]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[VMWareVMMetrics]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[VMWareVMMetrics](
	[resourceId] [varchar](64) NULL,
	[resourceName] [varchar](16) NULL,
	[metric] [varchar](128) NULL,
	[intervalType] [varchar](8) NULL,
	[rollUpType] [varchar](8) NULL,
	[timestamp] [datetime2](2) NULL,
	[value] [float] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250221-083400]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250221-083400] ON [General].[VMWareVMMetrics]
(
	[resourceName] ASC,
	[metric] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Database_AlwaysOn_Current]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_AlwaysOn_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[dns_name] [nvarchar](100) NULL,
	[ag_name] [varchar](50) NULL,
	[replica_server_name] [varchar](50) NULL,
	[database_name] [varchar](50) NULL,
	[log_send_queue_size] [bigint] NULL,
	[log_send_rate] [bigint] NULL,
	[redo_queue_size] [bigint] NULL,
	[redo_rate] [bigint] NULL,
	[last_sent_time] [datetime] NULL,
	[last_received_time] [datetime] NULL,
	[role_desc] [nvarchar](100) NULL,
	[database_state_desc] [nvarchar](100) NULL,
	[availability_mode_desc] [nvarchar](100) NULL,
	[failover_mode_desc] [nvarchar](100) NULL,
	[automated_backup_preference_desc] [nvarchar](100) NULL,
	[synchronization_state_desc] [nvarchar](100) NULL,
	[synchronization_health_desc] [nvarchar](100) NULL,
	[secondary_role_allow_connections_desc] [nvarchar](100) NULL,
	[last_commit_time] [datetime] NULL,
	[health_check_timeout] [int] NULL,
	[is_suspended] [bit] NULL,
	[endpoint_url] [nvarchar](500) NULL,
	[join_state_desc] [nvarchar](100) NULL,
	[connected_state_desc] [nvarchar](100) NULL,
	[failure_condition_level] [int] NULL,
	[create_date] [datetime] NULL,
	[modify_date] [datetime] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-091557]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-091557] ON [General].[SQL_Database_AlwaysOn_Current]
(
	[SQL_Instance_Name] ASC,
	[dns_name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Statistics_CPU]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Statistics_CPU](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Collection_Time] [smalldatetime] NULL,
	[SQLProcessUtilization] [int] NULL,
	[SystemIdle] [int] NULL,
	[OtherProcessUtilization] [int] NULL,
	[PageFaults] [bigint] NULL,
	[SQLMemoryUtilization] [int] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230913-082125]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230913-082125] ON [General].[SQL_Statistics_CPU]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Statistics_Usage]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Statistics_Usage](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Page_Life] [bigint] NULL,
	[Buffer_cache_hit_ratio] [float] NULL,
	[User_Connections] [bigint] NULL,
	[Logical_Connections] [bigint] NULL,
	[Transactions] [bigint] NULL,
	[Free_Space_in_tempdb_GB] [float] NULL,
	[Version_Store_Size_GB] [float] NULL,
	[Memory_Grants_Pending] [bigint] NULL,
	[Memory_Grants_Outstanding] [bigint] NULL,
	[TargetMemory_GB] [float] NULL,
	[TotalMemory_GB] [float] NULL,
	[Connection_Memory_MB] [float] NULL,
	[Database_Cache_Memory_MB] [float] NULL,
	[Free_Memory_MB] [float] NULL,
	[Granted_Workspace_Memory_MB] [float] NULL,
	[Lock_Memory_MB] [float] NULL,
	[Maximum_Workspace_Memory_MB] [float] NULL,
	[Optimizer_Memory_MB] [float] NULL,
	[Reserved_Server_Memory_MB] [float] NULL,
	[SQL_Cache_Memory_MB] [float] NULL,
	[Stolen_Server_Memory_MB] [float] NULL,
	[Log_Pool_Memory_MB] [float] NULL,
	[Batch_Requests] [bigint] NULL,
	[SQL_Compilations] [bigint] NULL,
	[SQL_ReCompilations] [bigint] NULL,
	[Page_lookups] [bigint] NULL,
	[Page_reads] [bigint] NULL,
	[Page_writes] [bigint] NULL,
	[Query_Store_CPU_usage] [bigint] NULL,
	[Query_Store_physical_reads] [bigint] NULL,
	[Query_Store_logical_reads] [bigint] NULL,
	[Query_Store_logical_writes] [bigint] NULL,
	[Batch_Req_500ms_1000ms] [bigint] NULL,
	[Batch_Req_1000ms_2000ms] [bigint] NULL,
	[Batch_Req_2000ms_5000ms] [bigint] NULL,
	[Batch_Req_5000ms_10000ms] [bigint] NULL,
	[Batch_Req_10000ms_20000ms] [bigint] NULL,
	[Batch_Req_20000ms_50000ms] [bigint] NULL,
	[Batch_Req_50000ms_100000ms] [bigint] NULL,
	[Batch_Req_100000ms_Plus] [bigint] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230913-082330]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230913-082330] ON [General].[SQL_Statistics_Usage]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  View [dbo].[Peak_Performance_Report_By_App_1_hour]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

















CREATE       view [dbo].[Peak_Performance_Report_By_App_1_hour] as


select distinct r.[Application Name] as [Application Name],  getdate() as Date_time, avg(r.[CPU AVG]) as [CPU AVG], avg(r.[CPU Peak]) as [CPU Peak], 
round(avg(r.BCHR),2) as BCHR, isnull(avg(r.[I O Stalls Avg]),0) as [I O Stalls Avg] from
(
SELECT distinct si.SQL_Instance_Name,[Application_Name] as [Application Name],  avg([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) as [CPU AVG], case when max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) >100 then 100 else max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) end as [CPU Peak], 
round(avg(case when ([Buffer_cache_hit_ratio]) >100 then 100 else
	[Buffer_cache_hit_ratio] end),2) as 'BCHR', isnull(dssel.[value],0) as [I O Stalls Avg]
   FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
   join [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] sdao with (nolock) on si.[SQL_Instance_Name] = sdao.[SQL_Instance_Name]  and sdao.[role_desc] not like '' and sdao.[role_desc] not like 'SECONDARY'
   join [DBA_Watcher_DB].[General].[SQL_Statistics_CPU] dssc with (nolock) on dssc.SQL_Instance_Name = si.SQL_Instance_Name and dssc.Pull_Time > dateadd(hh, -1, GETDATE())
   join [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] dss with (nolock) on dss.SQL_Instance_Name = si.SQL_Instance_Name and dss.Pull_Time > dateadd(hh, -1, GETDATE())
   left outer join (select [resourceName] as SQL_Instance_Name, round(avg(value),0) as [Value]
		from [DBA_Watcher_DB].[General].[VMWareVMMetrics] dssel with (nolock)
		where dssel.[timestamp] > dateadd(hh, -1, GETDATE()) and dssel.metric = 'storage|totalWriteLatency_average' 
		group by [resourceName]) dssel on dssel.SQL_Instance_Name like si.SQL_Instance_Name
   left outer join [DBA_Watcher_DB].[Daily].[SQL_Stats_Extended] sie (nolock) on si.SQL_Instance_Name = sie.SQL_Instance_Name and sie.virtual_machine_type_desc not like 'HYPERVISOR'
   where Peak = 'y'
   group by [Application_Name],si.SQL_Instance_Name,dssel.[value]
union
SELECT distinct si.SQL_Instance_Name,[Application_Name] as [Application Name], avg([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) as [CPU AVG], case when max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) >100 then 100 else max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) end as [CPU Peak], 
round(avg(case when ([Buffer_cache_hit_ratio]) >100 then 100 else
	[Buffer_cache_hit_ratio] end),2) as 'BCHR', isnull(dssel.[value],0) as [I O Stalls Avg]
   FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
   join [DBA_Watcher_DB].[General].[SQL_Statistics_CPU]  dssc with (nolock) on dssc.SQL_Instance_Name = si.SQL_Instance_Name and dssc.Pull_Time > dateadd(hh, -1, GETDATE())
   join [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] dss with (nolock) on dss.SQL_Instance_Name = si.SQL_Instance_Name and dss.Pull_Time > dateadd(hh, -1, GETDATE())
   left outer join (select [resourceName] as SQL_Instance_Name, round(avg(value),0) as [Value]
		from [DBA_Watcher_DB].[General].[VMWareVMMetrics] dssel with (nolock)
		where dssel.[timestamp] > dateadd(hh, -1, GETDATE()) and dssel.metric = 'storage|totalWriteLatency_average' 
		group by [resourceName]) dssel on dssel.SQL_Instance_Name like si.SQL_Instance_Name
		left outer join [DBA_Watcher_DB].[Daily].[SQL_Stats_Extended] sie (nolock) on si.SQL_Instance_Name = sie.SQL_Instance_Name and sie.virtual_machine_type_desc not like 'HYPERVISOR'
   where Peak = 'y' and si.[dns_Name] like '' and Status like 'Active'
   group by [Application_Name],si.SQL_Instance_Name, dssel.[value]) as r
   group by r.[Application Name]



GO
/****** Object:  View [dbo].[Peak_Performance_Report_By_App_2_hour]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


















CREATE       view [dbo].[Peak_Performance_Report_By_App_2_hour] as


select distinct r.[Application Name] as [Application Name],  getdate() as Date_time, avg(r.[CPU AVG]) as [CPU AVG], avg(r.[CPU Peak]) as [CPU Peak], 
round(avg(r.BCHR),2) as BCHR, isnull(avg(r.[I O Stalls Avg]),0) as [I O Stalls Avg] from
(
SELECT distinct si.SQL_Instance_Name,[Application_Name] as [Application Name],  avg([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) as [CPU AVG], case when max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) >100 then 100 else max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) end as [CPU Peak], 
round(avg(case when ([Buffer_cache_hit_ratio]) >100 then 100 else
	[Buffer_cache_hit_ratio] end),2) as 'BCHR', isnull(dssel.[value],0) as [I O Stalls Avg]
   FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
   join [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] sdao with (nolock) on si.[SQL_Instance_Name] = sdao.[SQL_Instance_Name]  and sdao.[role_desc] not like '' and sdao.[role_desc] not like 'SECONDARY'
   join [DBA_Watcher_DB].[General].[SQL_Statistics_CPU] dssc with (nolock) on dssc.SQL_Instance_Name = si.SQL_Instance_Name and dssc.Pull_Time > dateadd(hh, -2, GETDATE())
   join [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] dss with (nolock) on dss.SQL_Instance_Name = si.SQL_Instance_Name and dss.Pull_Time > dateadd(hh, -2, GETDATE())
   left outer join (select [resourceName] as SQL_Instance_Name, round(avg(value),0) as [Value]
		from [DBA_Watcher_DB].[General].[VMWareVMMetrics] dssel with (nolock)
		where dssel.[timestamp] > dateadd(hh, -2, GETDATE()) and dssel.metric = 'storage|totalWriteLatency_average' 
		group by [resourceName]) dssel on dssel.SQL_Instance_Name like si.SQL_Instance_Name
   left outer join [DBA_Watcher_DB].[Daily].[SQL_Stats_Extended] sie (nolock) on si.SQL_Instance_Name = sie.SQL_Instance_Name and sie.virtual_machine_type_desc not like 'HYPERVISOR'
   where Peak = 'y'
   group by [Application_Name],si.SQL_Instance_Name,dssel.[value]
union
SELECT distinct si.SQL_Instance_Name,[Application_Name] as [Application Name], avg([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) as [CPU AVG], case when max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) >100 then 100 else max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) end as [CPU Peak], 
round(avg(case when ([Buffer_cache_hit_ratio]) >100 then 100 else
	[Buffer_cache_hit_ratio] end),2) as 'BCHR', isnull(dssel.[value],0) as [I O Stalls Avg]
   FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
   join [DBA_Watcher_DB].[General].[SQL_Statistics_CPU]  dssc with (nolock) on dssc.SQL_Instance_Name = si.SQL_Instance_Name and dssc.Pull_Time > dateadd(hh, -2, GETDATE())
   join [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] dss with (nolock) on dss.SQL_Instance_Name = si.SQL_Instance_Name and dss.Pull_Time > dateadd(hh, -2, GETDATE())
   left outer join (select [resourceName] as SQL_Instance_Name, round(avg(value),0) as [Value]
		from [DBA_Watcher_DB].[General].[VMWareVMMetrics] dssel with (nolock)
		where dssel.[timestamp] > dateadd(hh, -2, GETDATE()) and dssel.metric = 'storage|totalWriteLatency_average' 
		group by [resourceName]) dssel on dssel.SQL_Instance_Name like si.SQL_Instance_Name
		left outer join [DBA_Watcher_DB].[Daily].[SQL_Stats_Extended] sie (nolock) on si.SQL_Instance_Name = sie.SQL_Instance_Name and sie.virtual_machine_type_desc not like 'HYPERVISOR'
   where Peak = 'y' and si.[dns_Name] like '' and Status like 'Active'
   group by [Application_Name],si.SQL_Instance_Name, dssel.[value]) as r
   group by r.[Application Name]



GO
/****** Object:  View [dbo].[Peak_Performance_Report_By_App_Morning]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


















CREATE       view [dbo].[Peak_Performance_Report_By_App_Morning] as


select distinct r.[Application Name] as [Application Name],  getdate() as Date_time, avg(r.[CPU AVG]) as [CPU AVG], avg(r.[CPU Peak]) as [CPU Peak], 
round(avg(r.BCHR),2) as BCHR, isnull(avg(r.[I O Stalls Avg]),0) as [I O Stalls Avg] from
(
SELECT distinct si.SQL_Instance_Name,[Application_Name] as [Application Name],  avg([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) as [CPU AVG], case when max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) >100 then 100 else max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) end as [CPU Peak], 
round(avg(case when ([Buffer_cache_hit_ratio]) >100 then 100 else
	[Buffer_cache_hit_ratio] end),2) as 'BCHR', isnull(dssel.[value],0) as [I O Stalls Avg]
   FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
   join [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] sdao with (nolock) on si.[SQL_Instance_Name] = sdao.[SQL_Instance_Name]  and sdao.[role_desc] not like '' and sdao.[role_desc] not like 'SECONDARY'
   join [DBA_Watcher_DB].[General].[SQL_Statistics_CPU] dssc with (nolock) on dssc.SQL_Instance_Name = si.SQL_Instance_Name and dssc.Pull_Time > dateadd(hh, -16, GETDATE())
   join [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] dss with (nolock) on dss.SQL_Instance_Name = si.SQL_Instance_Name and dss.Pull_Time > dateadd(hh, -16, GETDATE())
   left outer join (select [resourceName] as SQL_Instance_Name, round(avg(value),0) as [Value]
		from [DBA_Watcher_DB].[General].[VMWareVMMetrics] dssel with (nolock)
		where dssel.[timestamp] > dateadd(hh, -16, GETDATE()) and dssel.metric = 'storage|totalWriteLatency_average' 
		group by [resourceName]) dssel on dssel.SQL_Instance_Name like si.SQL_Instance_Name
   left outer join [DBA_Watcher_DB].[Daily].[SQL_Stats_Extended] sie (nolock) on si.SQL_Instance_Name = sie.SQL_Instance_Name and sie.virtual_machine_type_desc not like 'HYPERVISOR'
   where Peak = 'y'
   group by [Application_Name],si.SQL_Instance_Name,dssel.[value]
union
SELECT distinct si.SQL_Instance_Name,[Application_Name] as [Application Name], avg([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) as [CPU AVG], case when max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) >100 then 100 else max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) end as [CPU Peak], 
round(avg(case when ([Buffer_cache_hit_ratio]) >100 then 100 else
	[Buffer_cache_hit_ratio] end),2) as 'BCHR', isnull(dssel.[value],0) as [I O Stalls Avg]
   FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
   join [DBA_Watcher_DB].[General].[SQL_Statistics_CPU]  dssc with (nolock) on dssc.SQL_Instance_Name = si.SQL_Instance_Name and dssc.Pull_Time > dateadd(hh, -16, GETDATE())
   join [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] dss with (nolock) on dss.SQL_Instance_Name = si.SQL_Instance_Name and dss.Pull_Time > dateadd(hh, -16, GETDATE())
   left outer join (select [resourceName] as SQL_Instance_Name, round(avg(value),0) as [Value]
		from [DBA_Watcher_DB].[General].[VMWareVMMetrics] dssel with (nolock)
		where dssel.[timestamp] > dateadd(hh, -16, GETDATE()) and dssel.metric = 'storage|totalWriteLatency_average' 
		group by [resourceName]) dssel on dssel.SQL_Instance_Name like si.SQL_Instance_Name
		left outer join [DBA_Watcher_DB].[Daily].[SQL_Stats_Extended] sie (nolock) on si.SQL_Instance_Name = sie.SQL_Instance_Name and sie.virtual_machine_type_desc not like 'HYPERVISOR'
   where Peak = 'y' and si.[dns_Name] like '' and Status like 'Active'
   group by [Application_Name],si.SQL_Instance_Name, dssel.[value]) as r
   group by r.[Application Name]



GO
/****** Object:  View [dbo].[Peak_Performance_Report_By_App_Nightly]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


















CREATE       view [dbo].[Peak_Performance_Report_By_App_Nightly] as


select distinct r.[Application Name] as [Application Name],  getdate() as Date_time, avg(r.[CPU AVG]) as [CPU AVG], avg(r.[CPU Peak]) as [CPU Peak], 
round(avg(r.BCHR),2) as BCHR, isnull(avg(r.[I O Stalls Avg]),0) as [I O Stalls Avg] from
(
SELECT distinct si.SQL_Instance_Name,[Application_Name] as [Application Name],  avg([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) as [CPU AVG], case when max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) >100 then 100 else max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) end as [CPU Peak], 
round(avg(case when ([Buffer_cache_hit_ratio]) >100 then 100 else
	[Buffer_cache_hit_ratio] end),2) as 'BCHR', isnull(dssel.[value],0) as [I O Stalls Avg]
   FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
   join [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] sdao with (nolock) on si.[SQL_Instance_Name] = sdao.[SQL_Instance_Name]  and sdao.[role_desc] not like '' and sdao.[role_desc] not like 'SECONDARY'
   join [DBA_Watcher_DB].[General].[SQL_Statistics_CPU] dssc with (nolock) on dssc.SQL_Instance_Name = si.SQL_Instance_Name and dssc.Pull_Time > dateadd(hh, -8, GETDATE())
   join [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] dss with (nolock) on dss.SQL_Instance_Name = si.SQL_Instance_Name and dss.Pull_Time > dateadd(hh, -8, GETDATE())
   left outer join (select [resourceName] as SQL_Instance_Name, round(avg(value),0) as [Value]
		from [DBA_Watcher_DB].[General].[VMWareVMMetrics] dssel with (nolock)
		where dssel.[timestamp] > dateadd(hh, -8, GETDATE()) and dssel.metric = 'storage|totalWriteLatency_average' 
		group by [resourceName]) dssel on dssel.SQL_Instance_Name like si.SQL_Instance_Name
   left outer join [DBA_Watcher_DB].[Daily].[SQL_Stats_Extended] sie (nolock) on si.SQL_Instance_Name = sie.SQL_Instance_Name and sie.virtual_machine_type_desc not like 'HYPERVISOR'
   where Peak = 'y'
   group by [Application_Name],si.SQL_Instance_Name,dssel.[value]
union
SELECT distinct si.SQL_Instance_Name,[Application_Name] as [Application Name], avg([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) as [CPU AVG], case when max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) >100 then 100 else max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) end as [CPU Peak], 
round(avg(case when ([Buffer_cache_hit_ratio]) >100 then 100 else
	[Buffer_cache_hit_ratio] end),2) as 'BCHR', isnull(dssel.[value],0) as [I O Stalls Avg]
   FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
   join [DBA_Watcher_DB].[General].[SQL_Statistics_CPU]  dssc with (nolock) on dssc.SQL_Instance_Name = si.SQL_Instance_Name and dssc.Pull_Time > dateadd(hh, -8, GETDATE())
   join [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] dss with (nolock) on dss.SQL_Instance_Name = si.SQL_Instance_Name and dss.Pull_Time > dateadd(hh, -8, GETDATE())
   left outer join (select [resourceName] as SQL_Instance_Name, round(avg(value),0) as [Value]
		from [DBA_Watcher_DB].[General].[VMWareVMMetrics] dssel with (nolock)
		where dssel.[timestamp] > dateadd(hh, -8, GETDATE()) and dssel.metric = 'storage|totalWriteLatency_average' 
		group by [resourceName]) dssel on dssel.SQL_Instance_Name like si.SQL_Instance_Name
		left outer join [DBA_Watcher_DB].[Daily].[SQL_Stats_Extended] sie (nolock) on si.SQL_Instance_Name = sie.SQL_Instance_Name and sie.virtual_machine_type_desc not like 'HYPERVISOR'
   where Peak = 'y' and si.[dns_Name] like '' and Status like 'Active'
   group by [Application_Name],si.SQL_Instance_Name, dssel.[value]) as r
   group by r.[Application Name]



GO
/****** Object:  View [dbo].[Peak_Performance_Report_By_App_Weekly]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


















CREATE       view [dbo].[Peak_Performance_Report_By_App_Weekly] as


select distinct r.[Application Name] as [Application Name],  getdate() as Date_time, avg(r.[CPU AVG]) as [CPU AVG], avg(r.[CPU Peak]) as [CPU Peak], 
round(avg(r.BCHR),2) as BCHR, isnull(avg(r.[I O Stalls Avg]),0) as [I O Stalls Avg] from
(
SELECT distinct si.SQL_Instance_Name,[Application_Name] as [Application Name],  avg([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) as [CPU AVG], case when max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) >100 then 100 else max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) end as [CPU Peak], 
round(avg(case when ([Buffer_cache_hit_ratio]) >100 then 100 else
	[Buffer_cache_hit_ratio] end),2) as 'BCHR', isnull(dssel.[value],0) as [I O Stalls Avg]
   FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
   join [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] sdao with (nolock) on si.[SQL_Instance_Name] = sdao.[SQL_Instance_Name]  and sdao.[role_desc] not like '' and sdao.[role_desc] not like 'SECONDARY'
   join [DBA_Watcher_DB].[General].[SQL_Statistics_CPU] dssc with (nolock) on dssc.SQL_Instance_Name = si.SQL_Instance_Name and dssc.Pull_Time > dateadd(day, -7, GETDATE())
   join [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] dss with (nolock) on dss.SQL_Instance_Name = si.SQL_Instance_Name and dss.Pull_Time > dateadd(day, -7, GETDATE())
   left outer join (select [resourceName] as SQL_Instance_Name, round(avg(value),0) as [Value]
		from [DBA_Watcher_DB].[General].[VMWareVMMetrics] dssel with (nolock)
		where dssel.[timestamp] > dateadd(day, -7, GETDATE()) and dssel.metric = 'storage|totalWriteLatency_average' 
		group by [resourceName]) dssel on dssel.SQL_Instance_Name like si.SQL_Instance_Name
   left outer join [DBA_Watcher_DB].[Daily].[SQL_Stats_Extended] sie (nolock) on si.SQL_Instance_Name = sie.SQL_Instance_Name and sie.virtual_machine_type_desc not like 'HYPERVISOR'
   where Peak = 'y'
   group by [Application_Name],si.SQL_Instance_Name,dssel.[value]
union
SELECT distinct si.SQL_Instance_Name,[Application_Name] as [Application Name], avg([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) as [CPU AVG], case when max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) >100 then 100 else max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) end as [CPU Peak], 
round(avg(case when ([Buffer_cache_hit_ratio]) >100 then 100 else
	[Buffer_cache_hit_ratio] end),2) as 'BCHR', isnull(dssel.[value],0) as [I O Stalls Avg]
   FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
   join [DBA_Watcher_DB].[General].[SQL_Statistics_CPU]  dssc with (nolock) on dssc.SQL_Instance_Name = si.SQL_Instance_Name and dssc.Pull_Time > dateadd(day, -7, GETDATE())
   join [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] dss with (nolock) on dss.SQL_Instance_Name = si.SQL_Instance_Name and dss.Pull_Time > dateadd(day, -7, GETDATE())
   left outer join (select [resourceName] as SQL_Instance_Name, round(avg(value),0) as [Value]
		from [DBA_Watcher_DB].[General].[VMWareVMMetrics] dssel with (nolock)
		where dssel.[timestamp] > dateadd(day, -7, GETDATE()) and dssel.metric = 'storage|totalWriteLatency_average' 
		group by [resourceName]) dssel on dssel.SQL_Instance_Name like si.SQL_Instance_Name
		left outer join [DBA_Watcher_DB].[Daily].[SQL_Stats_Extended] sie (nolock) on si.SQL_Instance_Name = sie.SQL_Instance_Name and sie.virtual_machine_type_desc not like 'HYPERVISOR'
   where Peak = 'y' and si.[dns_Name] like '' and Status like 'Active'
   group by [Application_Name],si.SQL_Instance_Name, dssel.[value]) as r
   group by r.[Application Name]



GO
/****** Object:  View [dbo].[Peak_Performance_Report_By_App_Monthly]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


















CREATE       view [dbo].[Peak_Performance_Report_By_App_Monthly] as


select distinct r.[Application Name] as [Application Name],  getdate() as Date_time, avg(r.[CPU AVG]) as [CPU AVG], avg(r.[CPU Peak]) as [CPU Peak], 
round(avg(r.BCHR),2) as BCHR, isnull(avg(r.[I O Stalls Avg]),0) as [I O Stalls Avg] from
(
SELECT distinct si.SQL_Instance_Name,[Application_Name] as [Application Name],  avg([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) as [CPU AVG], case when max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) >100 then 100 else max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) end as [CPU Peak], 
round(avg(case when ([Buffer_cache_hit_ratio]) >100 then 100 else
	[Buffer_cache_hit_ratio] end),2) as 'BCHR', isnull(dssel.[value],0) as [I O Stalls Avg]
   FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
   join [DBA_Watcher_DB].[General].[SQL_Database_AlwaysOn_Current] sdao with (nolock) on si.[SQL_Instance_Name] = sdao.[SQL_Instance_Name]  and sdao.[role_desc] not like '' and sdao.[role_desc] not like 'SECONDARY'
   join [DBA_Watcher_DB].[General].[SQL_Statistics_CPU] dssc with (nolock) on dssc.SQL_Instance_Name = si.SQL_Instance_Name and dssc.Pull_Time > dateadd(day, -30, GETDATE())
   join [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] dss with (nolock) on dss.SQL_Instance_Name = si.SQL_Instance_Name and dss.Pull_Time > dateadd(day, -30, GETDATE())
   left outer join (select [resourceName] as SQL_Instance_Name, round(avg(value),0) as [Value]
		from [DBA_Watcher_DB].[General].[VMWareVMMetrics] dssel with (nolock)
		where dssel.[timestamp] > dateadd(day, -30, GETDATE()) and dssel.metric = 'storage|totalWriteLatency_average' 
		group by [resourceName]) dssel on dssel.SQL_Instance_Name like si.SQL_Instance_Name
   left outer join [DBA_Watcher_DB].[Daily].[SQL_Stats_Extended] sie (nolock) on si.SQL_Instance_Name = sie.SQL_Instance_Name and sie.virtual_machine_type_desc not like 'HYPERVISOR'
   where Peak = 'y'
   group by [Application_Name],si.SQL_Instance_Name,dssel.[value]
union
SELECT distinct si.SQL_Instance_Name,[Application_Name] as [Application Name], avg([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) as [CPU AVG], case when max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) >100 then 100 else max([SQLProcessUtilization]/ isnull(si.numa_node_count, 1)) end as [CPU Peak], 
round(avg(case when ([Buffer_cache_hit_ratio]) >100 then 100 else
	[Buffer_cache_hit_ratio] end),2) as 'BCHR', isnull(dssel.[value],0) as [I O Stalls Avg]
   FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
   join [DBA_Watcher_DB].[General].[SQL_Statistics_CPU]  dssc with (nolock) on dssc.SQL_Instance_Name = si.SQL_Instance_Name and dssc.Pull_Time > dateadd(day, -30, GETDATE())
   join [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] dss with (nolock) on dss.SQL_Instance_Name = si.SQL_Instance_Name and dss.Pull_Time > dateadd(day, -30, GETDATE())
   left outer join (select [resourceName] as SQL_Instance_Name, round(avg(value),0) as [Value]
		from [DBA_Watcher_DB].[General].[VMWareVMMetrics] dssel with (nolock)
		where dssel.[timestamp] > dateadd(day, -30, GETDATE()) and dssel.metric = 'storage|totalWriteLatency_average' 
		group by [resourceName]) dssel on dssel.SQL_Instance_Name like si.SQL_Instance_Name
		left outer join [DBA_Watcher_DB].[Daily].[SQL_Stats_Extended] sie (nolock) on si.SQL_Instance_Name = sie.SQL_Instance_Name and sie.virtual_machine_type_desc not like 'HYPERVISOR'
   where Peak = 'y' and si.[dns_Name] like '' and Status like 'Active'
   group by [Application_Name],si.SQL_Instance_Name, dssel.[value]) as r
   group by r.[Application Name]



GO
/****** Object:  View [dbo].[Inventory_OWCA]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE   view [dbo].[Inventory_OWCA] as
SELECT [SQL_Instance_Name],[DNS],[SQL_username] as [collector_username] ,[SQL_password] as [collector_password]
FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
inner join [DBA_Watcher_DB].[Settings].[General] ss with (nolock) on si.Team = ss.Team
where [enabled] = 'y' and ([Login_Domain] like 'OWCA' or [Login_Domain] like 'OWCADMZ') and [SQL_Instance_Name] not in (select [SQL_Instance_Name]
from [DBA_Watcher_DB].[Settings].[Monitoring_Override] with (nolock) where getdate()>[Start_Time]  and getdate()<[End_Time])
GO
/****** Object:  Table [General].[SQL_Database_Details_History]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_Details_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Database_name] [nvarchar](200) NULL,
	[compatibility_level] [tinyint] NOT NULL,
	[recovery_model_desc] [nvarchar](100) NULL,
	[Data_Size_GB] [float] NULL,
	[Log_Size_GB] [float] NULL,
	[Log_Used_Size_GB] [float] NULL,
	[Percent_Log_Used] [bigint] NULL,
	[log_reuse_wait_desc] [nvarchar](100) NULL,
	[state_desc] [nvarchar](100) NULL,
	[is_read_only] [varchar](100) NOT NULL,
	[user_access_desc] [nvarchar](100) NULL,
	[snapshot_isolation_state_desc] [nvarchar](100) NULL,
	[is_read_committed_snapshot_on] [bit] NULL,
	[Active_Transactions] [bigint] NULL,
	[Transactions_sec] [bigint] NULL,
	[Repl_Trans_Rate] [bigint] NULL,
	[Backup_Restore_Throughput_sec] [bigint] NULL,
	[DBCC_Logical_Scan_Bytes_sec] [bigint] NULL,
	[Log_Growths] [bigint] NULL,
	[Query_Store_physical_reads] [bigint] NULL,
	[Query_Store_logical_reads] [bigint] NULL,
	[Query_Store_logical_writes] [bigint] NULL,
	[Query_Store_CPU_usage] [bigint] NULL,
	[create_date] [smalldatetime] NULL,
	[collation_name] [sysname] NULL,
	[page_verify_option_desc] [nvarchar](100) NULL,
	[is_in_standby] [bit] NULL,
	[is_cleanly_shutdown] [bit] NULL,
	[is_auto_create_stats_on] [bit] NULL,
	[is_auto_update_stats_on] [bit] NULL,
	[is_auto_update_stats_async_on] [bit] NULL,
	[is_ansi_null_default_on] [bit] NULL,
	[is_ansi_nulls_on] [bit] NULL,
	[is_ansi_padding_on] [bit] NULL,
	[is_ansi_warnings_on] [bit] NULL,
	[is_arithabort_on] [bit] NULL,
	[is_concat_null_yields_null_on] [bit] NULL,
	[is_numeric_roundabort_on] [bit] NULL,
	[is_quoted_identifier_on] [bit] NULL,
	[is_fulltext_enabled] [bit] NULL,
	[is_trustworthy_on] [bit] NULL,
	[is_parameterization_forced] [bit] NULL,
	[is_master_key_encrypted_by_server] [bit] NOT NULL,
	[is_published] [bit] NOT NULL,
	[is_subscribed] [bit] NOT NULL,
	[is_distributor] [bit] NOT NULL,
	[is_broker_enabled] [bit] NOT NULL,
	[is_auto_close_on] [bit] NOT NULL,
	[is_auto_shrink_on] [bit] NULL,
	[is_supplemental_logging_enabled] [bit] NULL,
	[is_merge_published] [bit] NOT NULL,
	[is_date_correlation_on] [bit] NOT NULL,
	[is_cdc_enabled] [bit] NOT NULL,
	[is_encrypted] [bit] NULL,
	[target_recovery_time_in_seconds] [int] NULL,
	[is_query_store_on] [int] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20260521-155233]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20260521-155233] ON [General].[SQL_Database_Details_History]
(
	[Pull_Time] ASC,
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Database_Details]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_Details](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Database_name] [nvarchar](200) NULL,
	[compatibility_level] [tinyint] NOT NULL,
	[recovery_model_desc] [nvarchar](100) NULL,
	[Data_Size_GB] [float] NULL,
	[Log_Size_GB] [float] NULL,
	[Log_Used_Size_GB] [float] NULL,
	[Percent_Log_Used] [bigint] NULL,
	[log_reuse_wait_desc] [nvarchar](100) NULL,
	[state_desc] [nvarchar](100) NULL,
	[is_read_only] [varchar](100) NOT NULL,
	[user_access_desc] [nvarchar](100) NULL,
	[snapshot_isolation_state_desc] [nvarchar](100) NULL,
	[is_read_committed_snapshot_on] [bit] NULL,
	[Active_Transactions] [bigint] NULL,
	[Transactions_sec] [bigint] NULL,
	[Repl_Trans_Rate] [bigint] NULL,
	[Backup_Restore_Throughput_sec] [bigint] NULL,
	[DBCC_Logical_Scan_Bytes_sec] [bigint] NULL,
	[Log_Growths] [bigint] NULL,
	[Query_Store_physical_reads] [bigint] NULL,
	[Query_Store_logical_reads] [bigint] NULL,
	[Query_Store_logical_writes] [bigint] NULL,
	[Query_Store_CPU_usage] [bigint] NULL,
	[create_date] [smalldatetime] NULL,
	[collation_name] [sysname] NULL,
	[page_verify_option_desc] [nvarchar](100) NULL,
	[is_in_standby] [bit] NULL,
	[is_cleanly_shutdown] [bit] NULL,
	[is_auto_create_stats_on] [bit] NULL,
	[is_auto_update_stats_on] [bit] NULL,
	[is_auto_update_stats_async_on] [bit] NULL,
	[is_ansi_null_default_on] [bit] NULL,
	[is_ansi_nulls_on] [bit] NULL,
	[is_ansi_padding_on] [bit] NULL,
	[is_ansi_warnings_on] [bit] NULL,
	[is_arithabort_on] [bit] NULL,
	[is_concat_null_yields_null_on] [bit] NULL,
	[is_numeric_roundabort_on] [bit] NULL,
	[is_quoted_identifier_on] [bit] NULL,
	[is_fulltext_enabled] [bit] NULL,
	[is_trustworthy_on] [bit] NULL,
	[is_parameterization_forced] [bit] NULL,
	[is_master_key_encrypted_by_server] [bit] NOT NULL,
	[is_published] [bit] NOT NULL,
	[is_subscribed] [bit] NOT NULL,
	[is_distributor] [bit] NOT NULL,
	[is_broker_enabled] [bit] NOT NULL,
	[is_auto_close_on] [bit] NOT NULL,
	[is_auto_shrink_on] [bit] NULL,
	[is_supplemental_logging_enabled] [bit] NULL,
	[is_merge_published] [bit] NOT NULL,
	[is_date_correlation_on] [bit] NOT NULL,
	[is_cdc_enabled] [bit] NOT NULL,
	[is_encrypted] [bit] NULL,
	[target_recovery_time_in_seconds] [int] NULL,
	[is_query_store_on] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20260521-155116]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20260521-155116] ON [General].[SQL_Database_Details]
(
	[Pull_Time] ASC,
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  View [General].[SQL_Database_Details_View]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [General].[SQL_Database_Details_View]
   AS
SELECT [SQL_Instance_Name],[Pull_Time],[Database_name],[compatibility_level],[recovery_model_desc],[Data_Size_GB],[Log_Size_GB],[Log_Used_Size_GB],[Percent_Log_Used],[log_reuse_wait_desc]
,[state_desc],[is_read_only],[user_access_desc],[snapshot_isolation_state_desc],[is_read_committed_snapshot_on],[Active_Transactions],[Transactions_sec],[Repl_Trans_Rate],[Backup_Restore_Throughput_sec]
,[DBCC_Logical_Scan_Bytes_sec],[Log_Growths],[Query_Store_physical_reads],[Query_Store_logical_reads],[Query_Store_logical_writes],[Query_Store_CPU_usage],[create_date],[collation_name],[page_verify_option_desc]
,[is_in_standby],[is_cleanly_shutdown],[is_auto_create_stats_on],[is_auto_update_stats_on],[is_auto_update_stats_async_on],[is_ansi_null_default_on],[is_ansi_nulls_on],[is_ansi_padding_on]
,[is_ansi_warnings_on],[is_arithabort_on],[is_concat_null_yields_null_on],[is_numeric_roundabort_on],[is_quoted_identifier_on],[is_fulltext_enabled],[is_trustworthy_on],[is_parameterization_forced]
,[is_master_key_encrypted_by_server],[is_published],[is_subscribed],[is_distributor],[is_broker_enabled],[is_auto_close_on],[is_auto_shrink_on],[is_supplemental_logging_enabled],[is_merge_published]
,[is_date_correlation_on],[is_cdc_enabled],[is_encrypted]
FROM General.SQL_Database_Details with (nolock)
union
SELECT [SQL_Instance_Name],[Pull_Time],[Database_name],[compatibility_level],[recovery_model_desc],[Data_Size_GB],[Log_Size_GB],[Log_Used_Size_GB],[Percent_Log_Used],[log_reuse_wait_desc]
,[state_desc],[is_read_only],[user_access_desc],[snapshot_isolation_state_desc],[is_read_committed_snapshot_on],[Active_Transactions],[Transactions_sec],[Repl_Trans_Rate],[Backup_Restore_Throughput_sec]
,[DBCC_Logical_Scan_Bytes_sec],[Log_Growths],[Query_Store_physical_reads],[Query_Store_logical_reads],[Query_Store_logical_writes],[Query_Store_CPU_usage],[create_date],[collation_name],[page_verify_option_desc]
,[is_in_standby],[is_cleanly_shutdown],[is_auto_create_stats_on],[is_auto_update_stats_on],[is_auto_update_stats_async_on],[is_ansi_null_default_on],[is_ansi_nulls_on],[is_ansi_padding_on]
,[is_ansi_warnings_on],[is_arithabort_on],[is_concat_null_yields_null_on],[is_numeric_roundabort_on],[is_quoted_identifier_on],[is_fulltext_enabled],[is_trustworthy_on],[is_parameterization_forced]
,[is_master_key_encrypted_by_server],[is_published],[is_subscribed],[is_distributor],[is_broker_enabled],[is_auto_close_on],[is_auto_shrink_on],[is_supplemental_logging_enabled],[is_merge_published]
,[is_date_correlation_on],[is_cdc_enabled],[is_encrypted]
FROM General.SQL_Database_Details_History with (nolock)
union
SELECT si.DNS_Name as [SQL_Instance_Name],[Pull_Time],[Database_name],[compatibility_level],[recovery_model_desc],[Data_Size_GB],[Log_Size_GB],[Log_Used_Size_GB],[Percent_Log_Used],[log_reuse_wait_desc]
,[state_desc],[is_read_only],[user_access_desc],[snapshot_isolation_state_desc],[is_read_committed_snapshot_on],[Active_Transactions],[Transactions_sec],[Repl_Trans_Rate],[Backup_Restore_Throughput_sec]
,[DBCC_Logical_Scan_Bytes_sec],[Log_Growths],[Query_Store_physical_reads],[Query_Store_logical_reads],[Query_Store_logical_writes],[Query_Store_CPU_usage],[create_date],[collation_name],[page_verify_option_desc]
,[is_in_standby],[is_cleanly_shutdown],[is_auto_create_stats_on],[is_auto_update_stats_on],[is_auto_update_stats_async_on],[is_ansi_null_default_on],[is_ansi_nulls_on],[is_ansi_padding_on]
,[is_ansi_warnings_on],[is_arithabort_on],[is_concat_null_yields_null_on],[is_numeric_roundabort_on],[is_quoted_identifier_on],[is_fulltext_enabled],[is_trustworthy_on],[is_parameterization_forced]
,[is_master_key_encrypted_by_server],[is_published],[is_subscribed],[is_distributor],[is_broker_enabled],[is_auto_close_on],[is_auto_shrink_on],[is_supplemental_logging_enabled],[is_merge_published]
,[is_date_correlation_on],[is_cdc_enabled],[is_encrypted]
FROM General.SQL_Database_Details ao with (nolock)
join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock) on ao.SQL_Instance_Name = si.SQL_Instance_Name and ao.AlwaysOn = 'Primary'
union
SELECT si.DNS_Name as [SQL_Instance_Name],[Pull_Time],[Database_name],[compatibility_level],[recovery_model_desc],[Data_Size_GB],[Log_Size_GB],[Log_Used_Size_GB],[Percent_Log_Used],[log_reuse_wait_desc]
,[state_desc],[is_read_only],[user_access_desc],[snapshot_isolation_state_desc],[is_read_committed_snapshot_on],[Active_Transactions],[Transactions_sec],[Repl_Trans_Rate],[Backup_Restore_Throughput_sec]
,[DBCC_Logical_Scan_Bytes_sec],[Log_Growths],[Query_Store_physical_reads],[Query_Store_logical_reads],[Query_Store_logical_writes],[Query_Store_CPU_usage],[create_date],[collation_name],[page_verify_option_desc]
,[is_in_standby],[is_cleanly_shutdown],[is_auto_create_stats_on],[is_auto_update_stats_on],[is_auto_update_stats_async_on],[is_ansi_null_default_on],[is_ansi_nulls_on],[is_ansi_padding_on]
,[is_ansi_warnings_on],[is_arithabort_on],[is_concat_null_yields_null_on],[is_numeric_roundabort_on],[is_quoted_identifier_on],[is_fulltext_enabled],[is_trustworthy_on],[is_parameterization_forced]
,[is_master_key_encrypted_by_server],[is_published],[is_subscribed],[is_distributor],[is_broker_enabled],[is_auto_close_on],[is_auto_shrink_on],[is_supplemental_logging_enabled],[is_merge_published]
,[is_date_correlation_on],[is_cdc_enabled],[is_encrypted]
FROM General.SQL_Database_Details_History ao with (nolock)
join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock) on ao.SQL_Instance_Name = si.SQL_Instance_Name and ao.AlwaysOn = 'Primary'
GO
/****** Object:  Table [General].[SQL_Database_File_Details]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_File_Details](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[database_name] [nvarchar](200) NULL,
	[state_desc] [nvarchar](100) NULL,
	[type_desc] [nvarchar](100) NULL,
	[name] [sysname] NULL,
	[physical_name] [nvarchar](1000) NULL,
	[growth] [int] NULL,
	[is_percent_growth] [bit] NULL,
	[Size_on_disk_GB] [float] NULL,
	[Drive] [nvarchar](1000) NULL,
	[Drive_Name] [nvarchar](1000) NULL,
	[Drive_Size_GB] [bigint] NULL,
	[Drive_Free_Space_GB] [bigint] NULL,
	[Drive_Full_Percent] [float] NULL,
	[GB_Written] [float] NULL,
	[GB_Read] [float] NULL,
	[io_stall_write_ms] [bigint] NULL,
	[io_stall_read_ms] [bigint] NULL,
	[WriteLatency] [float] NULL,
	[ReadLatency] [float] NULL,
	[Latency] [float] NULL,
	[AvgMBPerRead] [float] NULL,
	[AvgMBPerWrite] [float] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-104349]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-104349] ON [General].[SQL_Database_File_Details]
(
	[SQL_Instance_Name] ASC,
	[database_name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Database_File_Details_History]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_File_Details_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[database_name] [nvarchar](200) NULL,
	[state_desc] [nvarchar](100) NULL,
	[type_desc] [nvarchar](100) NULL,
	[name] [sysname] NULL,
	[physical_name] [nvarchar](1000) NULL,
	[growth] [int] NULL,
	[is_percent_growth] [bit] NULL,
	[Size_on_disk_GB] [float] NULL,
	[Drive] [nvarchar](1000) NULL,
	[Drive_Name] [nvarchar](1000) NULL,
	[Drive_Size_GB] [bigint] NULL,
	[Drive_Free_Space_GB] [bigint] NULL,
	[Drive_Full_Percent] [float] NULL,
	[GB_Written] [float] NULL,
	[GB_Read] [float] NULL,
	[io_stall_write_ms] [bigint] NULL,
	[io_stall_read_ms] [bigint] NULL,
	[WriteLatency] [float] NULL,
	[ReadLatency] [float] NULL,
	[Latency] [float] NULL,
	[AvgMBPerRead] [float] NULL,
	[AvgMBPerWrite] [float] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-105233]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-105233] ON [General].[SQL_Database_File_Details_History]
(
	[SQL_Instance_Name] ASC,
	[database_name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  View [General].[SQL_Database_File_Details_View]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [General].[SQL_Database_File_Details_View]
   AS
SELECT [SQL_Instance_Name],[Pull_Time],[database_name],[state_desc],[type_desc],[name],[physical_name],[growth],[is_percent_growth],[Size_on_disk_GB],[Drive],[Drive_Name],[Drive_Size_GB]
,[Drive_Free_Space_GB],[Drive_Full_Percent],[GB_Written],[GB_Read],[io_stall_write_ms],[io_stall_read_ms],[WriteLatency],[ReadLatency],[Latency],[AvgMBPerRead],[AvgMBPerWrite]
FROM [DBA_Watcher_DB].[General].[SQL_Database_File_Details] with (nolock)
union
SELECT [SQL_Instance_Name],[Pull_Time],[database_name],[state_desc],[type_desc],[name],[physical_name],[growth],[is_percent_growth],[Size_on_disk_GB],[Drive],[Drive_Name],[Drive_Size_GB]
,[Drive_Free_Space_GB],[Drive_Full_Percent],[GB_Written],[GB_Read],[io_stall_write_ms],[io_stall_read_ms],[WriteLatency],[ReadLatency],[Latency],[AvgMBPerRead],[AvgMBPerWrite]
FROM [DBA_Watcher_DB].[General].[SQL_Database_File_Details_History] with (nolock)
GO
/****** Object:  Table [General].[SQL_Statistics_CPU_History]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Statistics_CPU_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Collection_Time] [smalldatetime] NULL,
	[SQLProcessUtilization] [int] NULL,
	[SystemIdle] [int] NULL,
	[OtherProcessUtilization] [int] NULL,
	[PageFaults] [bigint] NULL,
	[SQLMemoryUtilization] [int] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230913-081716]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230913-081716] ON [General].[SQL_Statistics_CPU_History]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  View [General].[SQL_Statistics_CPU_View]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO







CREATE VIEW [General].[SQL_Statistics_CPU_View]
   AS
SELECT ao.[SQL_Instance_Name],[Pull_Time],[Collection_Time],[SQLProcessUtilization],[SystemIdle],[OtherProcessUtilization],[PageFaults],[SQLMemoryUtilization]
FROM [DBA_Watcher_DB].[General].[SQL_Statistics_CPU] ao with (nolock)
Union
SELECT ao.[SQL_Instance_Name],[Pull_Time],[Collection_Time],[SQLProcessUtilization],[SystemIdle],[OtherProcessUtilization],[PageFaults],[SQLMemoryUtilization]
FROM [DBA_Watcher_DB].[General].[SQL_Statistics_CPU_History] ao with (nolock)
union
SELECT si.dns_name as [SQL_Instance_Name],[Pull_Time],[Collection_Time],[SQLProcessUtilization],[SystemIdle],[OtherProcessUtilization],[PageFaults],[SQLMemoryUtilization]
FROM [DBA_Watcher_DB].[General].[SQL_Statistics_CPU] ao with (nolock)
join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock) on ao.SQL_Instance_Name = si.SQL_Instance_Name and ao.AlwaysOn = 'Primary'
Union
SELECT si.dns_name as [SQL_Instance_Name],[Pull_Time],[Collection_Time],[SQLProcessUtilization],[SystemIdle],[OtherProcessUtilization],[PageFaults],[SQLMemoryUtilization]
FROM [DBA_Watcher_DB].[General].[SQL_Statistics_CPU_History] ao with (nolock)
join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock) on ao.SQL_Instance_Name = si.SQL_Instance_Name and ao.AlwaysOn = 'Primary'
GO
/****** Object:  Table [General].[SQL_Statistics_Usage_History]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Statistics_Usage_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Page_Life] [bigint] NULL,
	[Buffer_cache_hit_ratio] [float] NULL,
	[User_Connections] [bigint] NULL,
	[Logical_Connections] [bigint] NULL,
	[Transactions] [bigint] NULL,
	[Free_Space_in_tempdb_GB] [float] NULL,
	[Version_Store_Size_GB] [float] NULL,
	[Memory_Grants_Pending] [bigint] NULL,
	[Memory_Grants_Outstanding] [bigint] NULL,
	[TargetMemory_GB] [float] NULL,
	[TotalMemory_GB] [float] NULL,
	[Connection_Memory_MB] [float] NULL,
	[Database_Cache_Memory_MB] [float] NULL,
	[Free_Memory_MB] [float] NULL,
	[Granted_Workspace_Memory_MB] [float] NULL,
	[Lock_Memory_MB] [float] NULL,
	[Maximum_Workspace_Memory_MB] [float] NULL,
	[Optimizer_Memory_MB] [float] NULL,
	[Reserved_Server_Memory_MB] [float] NULL,
	[SQL_Cache_Memory_MB] [float] NULL,
	[Stolen_Server_Memory_MB] [float] NULL,
	[Log_Pool_Memory_MB] [float] NULL,
	[Batch_Requests] [bigint] NULL,
	[SQL_Compilations] [bigint] NULL,
	[SQL_ReCompilations] [bigint] NULL,
	[Page_lookups] [bigint] NULL,
	[Page_reads] [bigint] NULL,
	[Page_writes] [bigint] NULL,
	[Query_Store_CPU_usage] [bigint] NULL,
	[Query_Store_physical_reads] [bigint] NULL,
	[Query_Store_logical_reads] [bigint] NULL,
	[Query_Store_logical_writes] [bigint] NULL,
	[Batch_Req_500ms_1000ms] [bigint] NULL,
	[Batch_Req_1000ms_2000ms] [bigint] NULL,
	[Batch_Req_2000ms_5000ms] [bigint] NULL,
	[Batch_Req_5000ms_10000ms] [bigint] NULL,
	[Batch_Req_10000ms_20000ms] [bigint] NULL,
	[Batch_Req_20000ms_50000ms] [bigint] NULL,
	[Batch_Req_50000ms_100000ms] [bigint] NULL,
	[Batch_Req_100000ms_Plus] [bigint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230913-082429]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230913-082429] ON [General].[SQL_Statistics_Usage_History]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  View [General].[SQL_Statistics_Usage_View]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [General].[SQL_Statistics_Usage_View]
   AS
SELECT [SQL_Instance_Name],[Pull_Time],[Page_Life],[Buffer_cache_hit_ratio],[User_Connections],[Logical_Connections],[Transactions],[Free_Space_in_tempdb_GB],[Version_Store_Size_GB],[Memory_Grants_Pending],[Memory_Grants_Outstanding]
,[TargetMemory_GB],[TotalMemory_GB],[Connection_Memory_MB],[Database_Cache_Memory_MB],[Free_Memory_MB],[Granted_Workspace_Memory_MB],[Lock_Memory_MB],[Maximum_Workspace_Memory_MB],[Optimizer_Memory_MB]
,[Reserved_Server_Memory_MB],[SQL_Cache_Memory_MB],[Stolen_Server_Memory_MB],[Log_Pool_Memory_MB],[Batch_Requests],[SQL_Compilations],[SQL_ReCompilations],[Page_lookups],[Page_reads],[Page_writes]
,[Query_Store_CPU_usage],[Query_Store_physical_reads],[Query_Store_logical_reads],[Query_Store_logical_writes],[Batch_Req_500ms_1000ms],[Batch_Req_1000ms_2000ms],[Batch_Req_2000ms_5000ms],[Batch_Req_5000ms_10000ms]
,[Batch_Req_10000ms_20000ms],[Batch_Req_20000ms_50000ms],[Batch_Req_50000ms_100000ms],[Batch_Req_100000ms_Plus]
FROM [DBA_Watcher_DB].[General].[SQL_Statistics_Usage] ao with (nolock)
union
SELECT [SQL_Instance_Name],[Pull_Time],[Page_Life],[Buffer_cache_hit_ratio],[User_Connections],[Logical_Connections],[Transactions],[Free_Space_in_tempdb_GB],[Version_Store_Size_GB],[Memory_Grants_Pending],[Memory_Grants_Outstanding]
,[TargetMemory_GB],[TotalMemory_GB],[Connection_Memory_MB],[Database_Cache_Memory_MB],[Free_Memory_MB],[Granted_Workspace_Memory_MB],[Lock_Memory_MB],[Maximum_Workspace_Memory_MB],[Optimizer_Memory_MB]
,[Reserved_Server_Memory_MB],[SQL_Cache_Memory_MB],[Stolen_Server_Memory_MB],[Log_Pool_Memory_MB],[Batch_Requests],[SQL_Compilations],[SQL_ReCompilations],[Page_lookups],[Page_reads],[Page_writes]
,[Query_Store_CPU_usage],[Query_Store_physical_reads],[Query_Store_logical_reads],[Query_Store_logical_writes],[Batch_Req_500ms_1000ms],[Batch_Req_1000ms_2000ms],[Batch_Req_2000ms_5000ms],[Batch_Req_5000ms_10000ms]
,[Batch_Req_10000ms_20000ms],[Batch_Req_20000ms_50000ms],[Batch_Req_50000ms_100000ms],[Batch_Req_100000ms_Plus]
FROM [DBA_Watcher_DB].[General].[SQL_Statistics_Usage_History] ao with (nolock)
union
SELECT si.DNS_Name as [SQL_Instance_Name],[Pull_Time],[Page_Life],[Buffer_cache_hit_ratio],[User_Connections],[Logical_Connections],[Transactions],[Free_Space_in_tempdb_GB],[Version_Store_Size_GB],[Memory_Grants_Pending],[Memory_Grants_Outstanding]
,[TargetMemory_GB],[TotalMemory_GB],[Connection_Memory_MB],[Database_Cache_Memory_MB],[Free_Memory_MB],[Granted_Workspace_Memory_MB],[Lock_Memory_MB],[Maximum_Workspace_Memory_MB],[Optimizer_Memory_MB]
,[Reserved_Server_Memory_MB],[SQL_Cache_Memory_MB],[Stolen_Server_Memory_MB],[Log_Pool_Memory_MB],[Batch_Requests],[SQL_Compilations],[SQL_ReCompilations],[Page_lookups],[Page_reads],[Page_writes]
,[Query_Store_CPU_usage],[Query_Store_physical_reads],[Query_Store_logical_reads],[Query_Store_logical_writes],[Batch_Req_500ms_1000ms],[Batch_Req_1000ms_2000ms],[Batch_Req_2000ms_5000ms],[Batch_Req_5000ms_10000ms]
,[Batch_Req_10000ms_20000ms],[Batch_Req_20000ms_50000ms],[Batch_Req_50000ms_100000ms],[Batch_Req_100000ms_Plus]
FROM [DBA_Watcher_DB].[General].[SQL_Statistics_Usage_History] ao with (nolock)
join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock) on ao.SQL_Instance_Name = si.SQL_Instance_Name and ao.AlwaysOn = 'Primary'
union
SELECT si.DNS_Name as [SQL_Instance_Name],[Pull_Time],[Page_Life],[Buffer_cache_hit_ratio],[User_Connections],[Logical_Connections],[Transactions],[Free_Space_in_tempdb_GB],[Version_Store_Size_GB],[Memory_Grants_Pending],[Memory_Grants_Outstanding]
,[TargetMemory_GB],[TotalMemory_GB],[Connection_Memory_MB],[Database_Cache_Memory_MB],[Free_Memory_MB],[Granted_Workspace_Memory_MB],[Lock_Memory_MB],[Maximum_Workspace_Memory_MB],[Optimizer_Memory_MB]
,[Reserved_Server_Memory_MB],[SQL_Cache_Memory_MB],[Stolen_Server_Memory_MB],[Log_Pool_Memory_MB],[Batch_Requests],[SQL_Compilations],[SQL_ReCompilations],[Page_lookups],[Page_reads],[Page_writes]
,[Query_Store_CPU_usage],[Query_Store_physical_reads],[Query_Store_logical_reads],[Query_Store_logical_writes],[Batch_Req_500ms_1000ms],[Batch_Req_1000ms_2000ms],[Batch_Req_2000ms_5000ms],[Batch_Req_5000ms_10000ms]
,[Batch_Req_10000ms_20000ms],[Batch_Req_20000ms_50000ms],[Batch_Req_50000ms_100000ms],[Batch_Req_100000ms_Plus]
FROM [DBA_Watcher_DB].[General].[SQL_Statistics_Usage_History] ao with (nolock)
join [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock) on ao.SQL_Instance_Name = si.SQL_Instance_Name and ao.AlwaysOn = 'Primary'
GO
/****** Object:  View [dbo].[Inventory_MS_DEV]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE view [dbo].[Inventory_MS_DEV] as
SELECT [SQL_Instance_Name],[DNS],[SQL_username] as [collector_username] ,[SQL_password] as [collector_password]
FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
inner join [DBA_Watcher_DB].[Settings].[General] ss with (nolock) on si.Team = ss.Team
where [enabled] = 'y' and [Login_Domain] like 'MS' and [Department] not like 'Prod%' and [SQL_Instance_Name] not in (select [SQL_Instance_Name] 
from [DBA_Watcher_DB].[Settings].[Monitoring_Override] with (nolock) where getdate()>[Start_Time]  and getdate()<[End_Time])
GO
/****** Object:  View [dbo].[Inventory_MS_PROD_CTC]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE view [dbo].[Inventory_MS_PROD_CTC] as
SELECT [SQL_Instance_Name],[DNS],[SQL_username] as [collector_username] ,[SQL_password] as [collector_password]
FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
inner join [DBA_Watcher_DB].[Settings].[General] ss with (nolock) on si.Team = ss.Team
where [enabled] = 'y' and [Login_Domain] like 'MS' and [Department] like 'Prod%' and Location not like 'MN053' and [SQL_Instance_Name] not in (select [SQL_Instance_Name]
from [DBA_Watcher_DB].[Settings].[Monitoring_Override] with (nolock) where getdate()>[Start_Time]  and getdate()<[End_Time])
GO
/****** Object:  View [dbo].[Inventory_MS_PROD_ELR]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE view [dbo].[Inventory_MS_PROD_ELR] as
SELECT [SQL_Instance_Name],[DNS],[SQL_username] as [collector_username] ,[SQL_password] as [collector_password]
FROM [DBA_Watcher_DB].[Config].[SQL_Inventory] si with (nolock)
inner join [DBA_Watcher_DB].[Settings].[General] ss with (nolock) on si.Team = ss.Team
where [enabled] = 'y' and [Login_Domain] like 'MS' and [Department] like 'Prod%' and Location like '%MN053%' and [SQL_Instance_Name] not in (select [SQL_Instance_Name]
from [DBA_Watcher_DB].[Settings].[Monitoring_Override] with (nolock) where getdate()>[Start_Time]  and getdate()<[End_Time])
GO
/****** Object:  Table [Config].[Azure_Inventory]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Config].[Azure_Inventory](
	[Azure_Instance_Name] [varchar](50) NULL,
	[Date_Added] [smalldatetime] NULL,
	[Department] [varchar](50) NULL,
	[Environment] [varchar](50) NULL,
	[Peak] [varchar](10) NULL,
	[OnShore] [varchar](20) NULL,
	[Priority_Level] [varchar](50) NULL,
	[DNS] [varchar](250) NULL,
	[IP_Address] [sql_variant] NULL,
	[Monitoring_Page] [varchar](500) NULL,
	[Maintainence_Window] [varchar](500) NULL,
	[Location] [varchar](50) NULL,
	[Ask_id] [varchar](50) NULL,
	[CI] [varchar](50) NULL,
	[Application_Name] [varchar](300) NULL,
	[CPU_Count] [int] NOT NULL,
	[PhysicalMemory_GB] [bigint] NULL,
	[Version] [varchar](50) NULL,
	[Backup_Location] [varchar](200) NULL,
	[Service_Level_Owner] [varchar](254) NULL,
	[Service_Level_Owner_Email] [varchar](254) NULL,
	[Workgroup] [varchar](254) NULL,
	[Customer_Email] [varchar](500) NULL,
	[Notes] [varchar](4000) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250811-142546]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250811-142546] ON [Config].[Azure_Inventory]
(
	[Azure_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Config].[MongoDB_Inventory]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Config].[MongoDB_Inventory](
	[MongoDB_Instance_Name] [varchar](100) NULL,
	[Mongo_Atlas_Account] [varchar](100) NULL,
	[Managed_by_ORX] [varchar](50) NULL,
	[Date_Added] [smalldatetime] NULL,
	[Department] [varchar](50) NULL,
	[Environment] [varchar](50) NULL,
	[Peak] [varchar](10) NULL,
	[OnShore] [varchar](20) NULL,
	[Priority_Level] [varchar](50) NULL,
	[DNS] [varchar](250) NULL,
	[IP_Address] [sql_variant] NULL,
	[Monitoring_Page] [varchar](500) NULL,
	[Maintainence_Window] [varchar](500) NULL,
	[Location] [varchar](50) NULL,
	[Ask_id] [varchar](50) NULL,
	[CI] [varchar](50) NULL,
	[Application_Name] [varchar](300) NULL,
	[CPU_Count] [int] NOT NULL,
	[PhysicalMemory_GB] [bigint] NULL,
	[Version] [varchar](50) NULL,
	[Backup_Location] [varchar](200) NULL,
	[Service_Level_Owner] [varchar](254) NULL,
	[Service_Level_Owner_Email] [varchar](254) NULL,
	[Workgroup] [varchar](254) NULL,
	[Customer_Email] [varchar](500) NULL,
	[Notes] [varchar](4000) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250812-154839]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250812-154839] ON [Config].[MongoDB_Inventory]
(
	[MongoDB_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Config].[SQL_Inventory_ASK]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Config].[SQL_Inventory_ASK](
	[askId] [varchar](20) NULL,
	[dateCreated] [datetime] NULL,
	[dateUpdated] [datetime] NULL,
	[createdBy] [varchar](20) NULL,
	[lastUpdatedBy] [varchar](20) NULL,
	[applicationName] [varchar](128) NULL,
	[description] [varchar](4000) NULL,
	[billingBusinessSegmentId] [int] NULL,
	[infrastructureRequired] [bit] NULL,
	[uhgHelpdeskRequired] [bit] NULL,
	[Service-Level Owner] [varchar](20) NULL,
	[Technical Owner] [varchar](20) NULL,
	[Business Owner] [varchar](20) NULL,
	[aliases] [varchar](512) NULL,
	[categoryId] [tinyint] NULL,
	[categoryName] [varchar](20) NULL,
	[lifecycleStageId] [tinyint] NULL,
	[lifecycleStageName] [varchar](128) NULL,
	[acquiredEntityId] [varchar](64) NULL,
	[acquiredEntityName] [varchar](64) NULL,
	[enclaveEnvironmentId] [tinyint] NULL,
	[enclaveEnvironmentName] [varchar](128) NULL,
	[softwareTypeId] [tinyint] NULL,
	[softwareTypeName] [varchar](20) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240809-065233]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240809-065233] ON [Config].[SQL_Inventory_ASK]
(
	[askId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Config].[SQL_Inventory_Azure]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Config].[SQL_Inventory_Azure](
	[SQL_Instance_Name] [varchar](50) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[DatabaseName] [varchar](100) NULL,
	[ApplicationName] [varchar](150) NULL,
	[Created] [smalldatetime] NULL,
	[Owner] [varchar](50) NULL,
	[GroupName] [varchar](50) NULL,
	[Database_CurrentSize_MB] [bigint] NULL,
	[ChargebackMetric] [varchar](40) NULL,
	[ChargebackQty] [bigint] NULL,
	[ProjectNumber] [varchar](40) NULL,
	[ASKGlobalApplicationId] [varchar](50) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230818-094335]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230818-094335] ON [Config].[SQL_Inventory_Azure]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Config].[SQL_Inventory_Backup]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Config].[SQL_Inventory_Backup](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Date_Added] [smalldatetime] NULL,
	[Login_Domain] [varchar](20) NULL,
	[Department] [varchar](50) NULL,
	[Status] [varchar](50) NULL,
	[Peak] [varchar](10) NULL,
	[OnShore] [varchar](20) NULL,
	[Priority_Level] [varchar](50) NULL,
	[Enabled] [varchar](1) NULL,
	[Team] [varchar](50) NULL,
	[DNS] [varchar](250) NULL,
	[IP_Address] [sql_variant] NULL,
	[Host] [varchar](50) NULL,
	[Clustered] [varchar](10) NULL,
	[DNS_Name] [varchar](50) NULL,
	[DNS_Name_desc] [varchar](200) NULL,
	[LastRestartTime] [smalldatetime] NULL,
	[LastFailoverTime] [smalldatetime] NULL,
	[Next_Windows_Patch] [varchar](500) NULL,
	[Maintainence_Window] [varchar](500) NULL,
	[Location] [varchar](50) NULL,
	[Ask_id] [varchar](50) NULL,
	[CI] [varchar](50) NULL,
	[Application_Name] [varchar](300) NULL,
	[CPU_Count] [int] NOT NULL,
	[PhysicalMemory_GB] [bigint] NULL,
	[SQLMaxMemory_GB] [bigint] NULL,
	[SQLVersion] [varchar](50) NULL,
	[Version] [sql_variant] NULL,
	[OSDescription] [varchar](200) NULL,
	[Backup_Location] [varchar](200) NULL,
	[Service_Level_Owner] [varchar](254) NULL,
	[Service_Level_Owner_Email] [varchar](254) NULL,
	[Customer_Email] [varchar](500) NULL,
	[PriorityLevel] [varchar](5) NULL,
	[parentVcenter] [varchar](500) NULL,
	[parentCluster] [varchar](500) NULL,
	[parentDatacenter] [varchar](500) NULL,
	[numa_node_count] [int] NULL,
	[Notes] [varchar](4000) NULL,
	[SQL_Patch_Windows] [varchar](100) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Config].[SQL_Inventory_Diplomat]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Config].[SQL_Inventory_Diplomat](
	[ID] [int] NULL,
	[LinkedServerName] [varchar](200) NULL,
	[ServerName] [varchar](200) NULL,
	[InstanceName] [varchar](200) NULL,
	[ServerVersion] [varchar](400) NULL,
	[ServerDescription] [varchar](400) NULL,
	[IPAddress] [varchar](200) NULL,
	[Port] [bigint] NULL,
	[DBEngineLogin] [varchar](200) NULL,
	[AgentLogin] [varchar](200) NULL,
	[ServerMemoryMB] [bigint] NULL,
	[MinMemory] [bigint] NULL,
	[MaxMemory] [bigint] NULL,
	[LogicalCPU] [bigint] NULL,
	[HyperThreadRatio] [bigint] NULL,
	[PhysicalCPU] [bigint] NULL,
	[PacketSize] [bigint] NULL,
	[Edition] [varchar](200) NULL,
	[ProductVersion] [varchar](200) NULL,
	[ResourceVersion] [varchar](200) NULL,
	[ProductLevel] [varchar](200) NULL,
	[EngineEdition] [int] NULL,
	[ResourceLastUpdateDateTime] [varchar](200) NULL,
	[IsVirtualized] [varchar](200) NULL,
	[DateInventoryLastUpdated] [varchar](200) NULL,
	[ACTIVE] [varchar](200) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240809-065255]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240809-065255] ON [Config].[SQL_Inventory_Diplomat]
(
	[ServerName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Config].[SQL_Inventory_Domain]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Config].[SQL_Inventory_Domain](
	[Domain] [varchar](200) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[SamAccountName] [varchar](500) NULL,
	[Created] [smalldatetime] NULL,
	[Department] [varchar](500) NULL,
	[Description] [varchar](500) NULL,
	[DisplayName] [varchar](500) NULL,
	[EmployeeID] [varchar](500) NULL,
	[Enabled] [varchar](500) NULL,
	[GivenName] [varchar](500) NULL,
	[Surname] [varchar](500) NULL,
	[EmailAddress] [varchar](500) NULL,
	[LastBadPasswordAttempt] [varchar](500) NULL,
	[LastLogonDate] [datetime] NULL,
	[LockedOut] [varchar](500) NULL,
	[PasswordExpired] [varchar](500) NULL,
	[PasswordLastSet] [datetime] NULL,
	[PasswordNeverExpires] [varchar](500) NULL,
	[Name] [varchar](500) NULL,
	[ObjectClass] [varchar](500) NULL,
	[UserPrincipalName] [varchar](500) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230818-094513]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230818-094513] ON [Config].[SQL_Inventory_Domain]
(
	[SamAccountName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Config].[SQL_Inventory_MNA]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Config].[SQL_Inventory_MNA](
	[SQL_Instance_Name] [varchar](50) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Status_desc] [varchar](50) NULL,
	[Environment_desc] [varchar](50) NULL,
	[category_desc] [varchar](50) NULL,
	[Version] [varchar](50) NULL,
	[IsClustered] [varchar](20) NULL,
	[InstanceName] [varchar](50) NULL,
	[DNS] [varchar](200) NULL,
	[SupportLevel] [varchar](50) NULL,
	[SupportLevelDescription] [varchar](200) NULL,
	[LOB] [varchar](200) NULL,
	[Assignment_Group] [varchar](200) NULL,
	[Distribution_List] [varchar](200) NULL,
	[IsAzurePack] [varchar](200) NULL,
	[Support_Group_Assigned_On] [smalldatetime] NULL,
	[Support_Group_Assigned_By] [varchar](200) NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230803-142606]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230803-142606] ON [Config].[SQL_Inventory_MNA]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [Config].[SQL_Inventory_Test]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Config].[SQL_Inventory_Test](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Date_Added] [smalldatetime] NULL,
	[Login_Domain] [varchar](20) NULL,
	[Department] [varchar](50) NULL,
	[Status] [varchar](50) NULL,
	[Peak] [varchar](10) NULL,
	[OnShore] [varchar](20) NULL,
	[Priority_Level] [varchar](50) NULL,
	[Enabled] [varchar](1) NULL,
	[Team] [varchar](50) NULL,
	[DNS] [varchar](250) NULL,
	[IP_Address] [sql_variant] NULL,
	[Host] [varchar](50) NULL,
	[Clustered] [varchar](10) NULL,
	[DNS_Name] [varchar](50) NULL,
	[DNS_Name_desc] [varchar](200) NULL,
	[LastRestartTime] [smalldatetime] NULL,
	[LastFailoverTime] [smalldatetime] NULL,
	[Next_Windows_Patch] [varchar](500) NULL,
	[Maintainence_Window] [varchar](500) NULL,
	[Location] [varchar](50) NULL,
	[Ask_id] [varchar](50) NULL,
	[CI] [varchar](50) NULL,
	[Application_Name] [varchar](300) NULL,
	[CPU_Count] [int] NOT NULL,
	[PhysicalMemory_GB] [bigint] NULL,
	[SQLMaxMemory_GB] [bigint] NULL,
	[SQLVersion] [varchar](50) NULL,
	[Version] [sql_variant] NULL,
	[OSDescription] [varchar](200) NULL,
	[Backup_Location] [varchar](200) NULL,
	[Service_Level_Owner] [varchar](254) NULL,
	[Service_Level_Owner_Email] [varchar](254) NULL,
	[Customer_Email] [varchar](500) NULL,
	[PriorityLevel] [varchar](5) NULL,
	[parentVcenter] [varchar](500) NULL,
	[parentCluster] [varchar](500) NULL,
	[parentDatacenter] [varchar](500) NULL,
	[numa_node_count] [int] NULL,
	[Notes] [varchar](4000) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Config].[SQL_Inventory_VMProperties]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Config].[SQL_Inventory_VMProperties](
	[Name] [varchar](50) NULL,
	[collect_dt] [varchar](32) NULL,
	[FQDN] [varchar](100) NULL,
	[powerState] [varchar](40) NULL,
	[OS] [varchar](200) NULL,
	[numCpu] [varchar](20) NULL,
	[numCoresPerSocket] [varchar](20) NULL,
	[memoryMB] [varchar](200) NULL,
	[memoryGB] [varchar](20) NULL,
	[cpuAllocation_limit] [varchar](40) NULL,
	[cpuAllocation_reservation] [varchar](40) NULL,
	[memoryAllocation_limit] [varchar](40) NULL,
	[memoryAllocation_reservation] [varchar](40) NULL,
	[vcpu_hotadd] [varchar](40) NULL,
	[vcpu_hotremove] [varchar](40) NULL,
	[mem_hotadd] [varchar](40) NULL,
	[thinEnabled] [varchar](40) NULL,
	[diskSpace] [varchar](40) NULL,
	[numVMDKs] [varchar](40) NULL,
	[MOID] [varchar](40) NULL,
	[parentVcenter] [varchar](40) NULL,
	[parentCluster] [varchar](40) NULL,
	[parentDatacenter] [varchar](50) NULL,
	[parentHost] [varchar](50) NULL,
	[UUID] [varchar](70) NULL,
	[resourceId] [varchar](64) NULL,
	[folder] [varchar](200) NULL,
	[ipAddress] [varchar](30) NULL,
	[toolsRunningStatus] [varchar](80) NULL,
	[toolsVersion] [varchar](40) NULL,
	[toolsVersionStatus2] [varchar](80) NULL,
	[VRMOwner] [varchar](80) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230818-094649]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230818-094649] ON [Config].[SQL_Inventory_VMProperties]
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Daily].[SQL_Instances_Configs]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Daily].[SQL_Instances_Configs](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Config_Name] [varchar](100) NULL,
	[value] [bigint] NULL,
	[value_in_use] [bigint] NULL,
	[description] [varchar](400) NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230713-080047]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230713-080047] ON [Daily].[SQL_Instances_Configs]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [Daily].[SQL_Instances_Configs_History]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Daily].[SQL_Instances_Configs_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Config_Name] [varchar](100) NULL,
	[value_old] [bigint] NULL,
	[value_new] [bigint] NULL,
	[description] [varchar](400) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230713-091457]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230713-091457] ON [Daily].[SQL_Instances_Configs_History]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Daily].[SQL_Missing_Index]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Daily].[SQL_Missing_Index](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[DatabaseName] [nvarchar](128) NULL,
	[UniqueCompiles] [bigint] NOT NULL,
	[UniqueCompiles_Change] [bigint] NULL,
	[AvgTotalUserCost] [float] NULL,
	[AvgTotalUserCost_Change] [float] NULL,
	[AvgUserImpact] [float] NULL,
	[AvgUserImpact_Change] [float] NULL,
	[IndexAdvantage] [float] NULL,
	[IndexAdvantage_Change] [float] NULL,
	[FullyQualifiedObjectName] [nvarchar](1000) NULL,
	[EqualityColumns] [nvarchar](1000) NULL,
	[InEqualityColumns] [nvarchar](1000) NULL,
	[IncludedColumns] [nvarchar](1000) NULL,
	[ProposedIndex] [varchar](1000) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230714-082036]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230714-082036] ON [Daily].[SQL_Missing_Index]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Daily].[SQL_OS_Info]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Daily].[SQL_OS_Info](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[host_platform] [nvarchar](256) NOT NULL,
	[host_distribution] [nvarchar](256) NOT NULL,
	[host_release] [nvarchar](256) NOT NULL,
	[host_service_pack_level] [nvarchar](256) NOT NULL,
	[host_sku] [int] NULL,
	[os_language_version] [int] NOT NULL,
	[host_architecture] [nvarchar](256) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240809-071618]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240809-071618] ON [Daily].[SQL_OS_Info]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Daily].[SQL_Server_Logins]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Daily].[SQL_Server_Logins](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[loginname] [nvarchar](128) NOT NULL,
	[type_desc] [nvarchar](200) NULL,
	[default_database_name] [nvarchar](128) NULL,
	[default_language_name] [nvarchar](128) NULL,
	[Locked] [varchar](20) NOT NULL,
	[Disabled] [varchar](20) NOT NULL,
	[create_date] [smalldatetime] NULL,
	[modify_date] [smalldatetime] NULL,
	[denylogin] [int] NULL,
	[hasaccess] [int] NULL,
	[isntname] [int] NULL,
	[isntuser] [int] NULL,
	[sysadmin] [int] NULL,
	[securityadmin] [int] NULL,
	[serveradmin] [int] NULL,
	[setupadmin] [int] NULL,
	[processadmin] [int] NULL,
	[diskadmin] [int] NULL,
	[dbcreator] [int] NULL,
	[bulkadmin] [int] NULL,
	[is_policy_checked] [bit] NULL,
	[is_expiration_checked] [bit] NULL,
	[status] [smallint] NULL,
	[System] [nvarchar](600) NOT NULL,
	[SQL_BadPasswordCount] [sql_variant] NULL,
	[SQL_BadPasswordTime] [smalldatetime] NULL,
	[SQL_PasswordSetAge] [int] NULL,
	[SQL_HistoryLength] [sql_variant] NULL,
	[SQL_IsExpired] [sql_variant] NULL,
	[SQL_IsMustChange] [sql_variant] NULL,
	[SQL_LockoutTime] [smalldatetime] NULL,
	[SQL_PasswordLastSetTime] [smalldatetime] NULL,
	[sid] [varchar](200) NULL,
	[PasswordHash] [varchar](200) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240809-071633]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240809-071633] ON [Daily].[SQL_Server_Logins]
(
	[SQL_Instance_Name] ASC,
	[loginname] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Daily].[SQL_Server_Logins_History]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Daily].[SQL_Server_Logins_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Action] [varchar](50) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[loginname] [nvarchar](128) NOT NULL,
	[type_desc] [nvarchar](200) NULL,
	[default_database_name] [nvarchar](128) NULL,
	[default_language_name] [nvarchar](128) NULL,
	[Locked] [varchar](20) NOT NULL,
	[Disabled] [varchar](20) NOT NULL,
	[create_date] [smalldatetime] NULL,
	[modify_date] [smalldatetime] NULL,
	[denylogin] [int] NULL,
	[hasaccess] [int] NULL,
	[isntname] [int] NULL,
	[isntuser] [int] NULL,
	[sysadmin] [int] NULL,
	[securityadmin] [int] NULL,
	[serveradmin] [int] NULL,
	[setupadmin] [int] NULL,
	[processadmin] [int] NULL,
	[diskadmin] [int] NULL,
	[dbcreator] [int] NULL,
	[bulkadmin] [int] NULL,
	[is_policy_checked] [bit] NULL,
	[is_expiration_checked] [bit] NULL,
	[status] [smallint] NULL,
	[System] [nvarchar](600) NOT NULL,
	[SQL_BadPasswordCount] [sql_variant] NULL,
	[SQL_BadPasswordTime] [smalldatetime] NULL,
	[SQL_PasswordSetAge] [int] NULL,
	[SQL_HistoryLength] [sql_variant] NULL,
	[SQL_IsExpired] [sql_variant] NULL,
	[SQL_IsMustChange] [sql_variant] NULL,
	[SQL_LockoutTime] [smalldatetime] NULL,
	[SQL_PasswordLastSetTime] [smalldatetime] NULL,
	[sid] [varchar](200) NULL,
	[PasswordHash] [varchar](200) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240809-071654]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240809-071654] ON [Daily].[SQL_Server_Logins_History]
(
	[SQL_Instance_Name] ASC,
	[loginname] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Daily].[SQL_Server_Registry]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Daily].[SQL_Server_Registry](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NOT NULL,
	[Pull_Time] [smalldatetime] NULL,
	[registry_key] [nvarchar](500) NULL,
	[value_name] [nvarchar](500) NULL,
	[value_data] [varchar](500) NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240809-071709]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240809-071709] ON [Daily].[SQL_Server_Registry]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [Daily].[SQL_WaitStats]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Daily].[SQL_WaitStats](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[WaitType] [nvarchar](100) NULL,
	[Percentage] [decimal](5, 2) NULL,
	[Wait_S] [decimal](16, 2) NULL,
	[Resource_S] [decimal](16, 2) NULL,
	[Signal_S] [decimal](16, 2) NULL,
	[WaitCount] [bigint] NULL,
	[AvgWait_S] [decimal](16, 4) NULL,
	[AvgRes_S] [decimal](16, 4) NULL,
	[AvgSig_S] [decimal](16, 4) NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230714-074250]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230714-074250] ON [Daily].[SQL_WaitStats]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [Daily].[SQL_WorstPerforming]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Daily].[SQL_WorstPerforming](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[ObjectType] [varchar](50) NULL,
	[Database_name] [nvarchar](250) NULL,
	[Schema_Procedure] [nvarchar](500) NULL,
	[text] [nvarchar](max) NULL,
	[last_execution_time] [smalldatetime] NULL,
	[last_worker_time] [bigint] NULL,
	[min_worker_time] [bigint] NULL,
	[max_worker_time] [bigint] NULL,
	[last_physical_reads] [bigint] NULL,
	[min_physical_reads] [bigint] NULL,
	[max_physical_reads] [bigint] NULL,
	[last_logical_writes] [bigint] NULL,
	[min_logical_writes] [bigint] NULL,
	[max_logical_writes] [bigint] NULL,
	[last_logical_reads] [bigint] NULL,
	[min_logical_reads] [bigint] NULL,
	[max_logical_reads] [bigint] NULL,
	[last_elapsed_time] [bigint] NULL,
	[min_elapsed_time] [bigint] NULL,
	[max_elapsed_time] [bigint] NULL,
	[last_rows] [bigint] NULL,
	[min_rows] [bigint] NULL,
	[max_rows] [bigint] NULL,
	[min_dop] [bigint] NULL,
	[max_dop] [bigint] NULL,
	[last_grant_kb] [bigint] NULL,
	[min_grant_kb] [bigint] NULL,
	[max_grant_kb] [bigint] NULL,
	[last_used_grant_kb] [bigint] NULL,
	[min_used_grant_kb] [bigint] NULL,
	[max_used_grant_kb] [bigint] NULL,
	[last_ideal_grant_kb] [bigint] NULL,
	[min_ideal_grant_kb] [bigint] NULL,
	[max_ideal_grant_kb] [bigint] NULL,
	[min_used_threads] [bigint] NULL,
	[max_used_threads] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240814-064224]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240814-064224] ON [Daily].[SQL_WorstPerforming]
(
	[SQL_Instance_Name] ASC,
	[AlwaysOn] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Daily].[SQL_XEvent_Config]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Daily].[SQL_XEvent_Config](
	[SQL_Instance_Name] [varchar](30) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[name] [nvarchar](256) NOT NULL,
	[total_regular_buffers] [int] NOT NULL,
	[regular_buffer_size] [bigint] NOT NULL,
	[total_large_buffers] [int] NOT NULL,
	[large_buffer_size] [bigint] NOT NULL,
	[dropped_event_count] [int] NOT NULL,
	[dropped_buffer_count] [int] NOT NULL,
	[largest_event_dropped_size] [int] NOT NULL,
	[event_retention_mode_desc] [nvarchar](60) NULL,
	[max_dispatch_latency] [int] NULL,
	[max_memory] [int] NULL,
	[max_event_size] [int] NULL,
	[memory_partition_mode] [char](1) NULL,
	[memory_partition_mode_desc] [nvarchar](60) NULL,
	[track_causality] [bit] NULL,
	[startup_state] [bit] NULL,
	[max_events_limit] [nvarchar](3072) NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240814-064241]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240814-064241] ON [Daily].[SQL_XEvent_Config]
(
	[SQL_Instance_Name] ASC,
	[AlwaysOn] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [External].[MNA_Diskspace]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [External].[MNA_Diskspace](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[DNS] [varchar](200) NULL,
	[volume] [varchar](100) NULL,
	[sizeMB] [bigint] NULL,
	[freeSpaceMB] [bigint] NULL,
	[pctFull] [float] NULL,
	[warningThreshold] [float] NULL,
	[criticalThreshold] [float] NULL,
	[startDTS] [smalldatetime] NULL,
	[endDTS] [smalldatetime] NULL,
	[lastUpdatedBy] [varchar](200) NULL,
	[reason] [varchar](1200) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230803-151059]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230803-151059] ON [External].[MNA_Diskspace]
(
	[SQL_Instance_Name] ASC,
	[volume] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [External].[Patching_Diplomat]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [External].[Patching_Diplomat](
	[SQL_Instance_Name] [varchar](200) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[ScheduledExecutionsID] [int] NULL,
	[ScheduledDT] [smalldatetime] NULL,
	[ExecutionDT] [smalldatetime] NULL,
	[completed] [bit] NULL,
	[NotificationEmail] [varchar](200) NULL,
	[ScheduledExecutions] [varchar](8000) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230803-145337]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230803-145337] ON [External].[Patching_Diplomat]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_AgentJobs]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_AgentJobs](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[enabled] [tinyint] NULL,
	[JobName] [varchar](400) NULL,
	[step_id] [int] NULL,
	[step_name] [varchar](400) NULL,
	[last_run_outcome] [int] NULL,
	[last_run_outcome_status] [varchar](20) NULL,
	[Message] [nvarchar](4000) NULL,
	[Status] [varchar](20) NULL,
	[Last_Job_Duration] [int] NULL,
	[AVG_Step_Duration_Min] [int] NULL,
	[Max_Step_Duration_Min] [int] NULL,
	[start_execution_date] [smalldatetime] NULL,
	[stop_execution_date] [smalldatetime] NULL,
	[next_scheduled_run_date] [smalldatetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-091256]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-091256] ON [General].[SQL_AgentJobs]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_AgentJobs_History]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_AgentJobs_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[enabled] [tinyint] NULL,
	[JobName] [varchar](400) NULL,
	[step_id] [int] NULL,
	[step_name] [varchar](400) NULL,
	[last_run_outcome] [int] NULL,
	[last_run_outcome_status] [varchar](20) NULL,
	[Message] [nvarchar](4000) NULL,
	[Status] [varchar](20) NULL,
	[Last_Job_Duration] [int] NULL,
	[AVG_Step_Duration_Min] [int] NULL,
	[Max_Step_Duration_Min] [int] NULL,
	[start_execution_date] [smalldatetime] NULL,
	[stop_execution_date] [smalldatetime] NULL,
	[next_scheduled_run_date] [smalldatetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-091316]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-091316] ON [General].[SQL_AgentJobs_History]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Database_Backup]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_Backup](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Database_name] [varchar](200) NULL,
	[state_desc] [nvarchar](100) NULL,
	[Recovery] [nvarchar](100) NULL,
	[BackupType] [varchar](50) NULL,
	[Days_without_Backup] [int] NULL,
	[Backup_Duration_Min] [int] NULL,
	[Backup_Path] [nvarchar](4000) NULL,
	[LastBackupStart] [smalldatetime] NULL,
	[LastBackupFinish] [smalldatetime] NULL,
	[BackupSize_GB] [numeric](18, 2) NULL,
	[compressed_backup_size_GB] [numeric](18, 2) NULL,
	[BackupSize_MB] [numeric](18, 2) NULL,
	[compressed_backup_size_MB] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250421-085433]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250421-085433] ON [General].[SQL_Database_Backup]
(
	[SQL_Instance_Name] ASC,
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Database_Backup_Current]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_Backup_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Database_name] [varchar](200) NULL,
	[state_desc] [nvarchar](100) NULL,
	[Recovery] [nvarchar](100) NULL,
	[BackupType] [varchar](50) NULL,
	[Days_without_Backup] [int] NULL,
	[Backup_Duration_Min] [int] NULL,
	[Backup_Path] [nvarchar](4000) NULL,
	[LastBackupStart] [smalldatetime] NULL,
	[LastBackupFinish] [smalldatetime] NULL,
	[BackupSize_GB] [numeric](18, 2) NULL,
	[compressed_backup_size_GB] [numeric](18, 2) NULL,
	[BackupSize_MB] [numeric](18, 2) NULL,
	[compressed_backup_size_MB] [numeric](18, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250421-085452]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250421-085452] ON [General].[SQL_Database_Backup_Current]
(
	[SQL_Instance_Name] ASC,
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Database_Backup_History]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_Backup_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Database_name] [varchar](200) NULL,
	[state_desc] [nvarchar](100) NULL,
	[Recovery] [nvarchar](100) NULL,
	[BackupType] [varchar](50) NULL,
	[Days_without_Backup] [int] NULL,
	[Backup_Duration_Min] [int] NULL,
	[Backup_Path] [nvarchar](4000) NULL,
	[LastBackupStart] [smalldatetime] NULL,
	[LastBackupFinish] [smalldatetime] NULL,
	[BackupSize_GB] [numeric](18, 2) NULL,
	[compressed_backup_size_GB] [numeric](18, 2) NULL,
	[BackupSize_MB] [numeric](18, 2) NULL,
	[compressed_backup_size_MB] [numeric](18, 2) NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250421-085517]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250421-085517] ON [General].[SQL_Database_Backup_History]
(
	[SQL_Instance_Name] ASC,
	[AlwaysOn] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Database_CDC]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_CDC](
	[SQL_Instance_Name] [varchar](200) NULL,
	[Database] [varchar](200) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[session_id] [int] NULL,
	[start_time] [datetime] NULL,
	[end_time] [datetime] NULL,
	[duration] [int] NULL,
	[scan_phase] [nvarchar](200) NULL,
	[error_count] [int] NULL,
	[tran_count] [bigint] NULL,
	[last_commit_time] [datetime] NULL,
	[log_record_count] [bigint] NULL,
	[schema_change_count] [int] NULL,
	[command_count] [bigint] NULL,
	[last_commit_cdc_time] [datetime] NULL,
	[latency] [int] NULL,
	[empty_scan_count] [int] NULL,
	[failed_sessions_count] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230915-131033]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230915-131033] ON [General].[SQL_Database_CDC]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Database_CDC_Current]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_CDC_Current](
	[SQL_Instance_Name] [varchar](200) NULL,
	[Database] [varchar](200) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[session_id] [int] NULL,
	[start_time] [datetime] NULL,
	[end_time] [datetime] NULL,
	[duration] [int] NULL,
	[scan_phase] [nvarchar](200) NULL,
	[error_count] [int] NULL,
	[tran_count] [bigint] NULL,
	[last_commit_time] [datetime] NULL,
	[log_record_count] [bigint] NULL,
	[schema_change_count] [int] NULL,
	[command_count] [bigint] NULL,
	[last_commit_cdc_time] [datetime] NULL,
	[latency] [int] NULL,
	[empty_scan_count] [int] NULL,
	[failed_sessions_count] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230915-131045]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230915-131045] ON [General].[SQL_Database_CDC_Current]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Database_Details_Current]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_Details_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Database_name] [nvarchar](200) NULL,
	[compatibility_level] [tinyint] NOT NULL,
	[recovery_model_desc] [nvarchar](100) NULL,
	[Data_Size_GB] [float] NULL,
	[Log_Size_GB] [float] NULL,
	[Log_Used_Size_GB] [float] NULL,
	[Percent_Log_Used] [bigint] NULL,
	[log_reuse_wait_desc] [nvarchar](100) NULL,
	[state_desc] [nvarchar](100) NULL,
	[is_read_only] [varchar](100) NOT NULL,
	[user_access_desc] [nvarchar](100) NULL,
	[snapshot_isolation_state_desc] [nvarchar](100) NULL,
	[is_read_committed_snapshot_on] [bit] NULL,
	[Active_Transactions] [bigint] NULL,
	[Transactions_sec] [bigint] NULL,
	[Repl_Trans_Rate] [bigint] NULL,
	[Backup_Restore_Throughput_sec] [bigint] NULL,
	[DBCC_Logical_Scan_Bytes_sec] [bigint] NULL,
	[Log_Growths] [bigint] NULL,
	[Query_Store_physical_reads] [bigint] NULL,
	[Query_Store_logical_reads] [bigint] NULL,
	[Query_Store_logical_writes] [bigint] NULL,
	[Query_Store_CPU_usage] [bigint] NULL,
	[create_date] [smalldatetime] NULL,
	[collation_name] [sysname] NULL,
	[page_verify_option_desc] [nvarchar](100) NULL,
	[is_in_standby] [bit] NULL,
	[is_cleanly_shutdown] [bit] NULL,
	[is_auto_create_stats_on] [bit] NULL,
	[is_auto_update_stats_on] [bit] NULL,
	[is_auto_update_stats_async_on] [bit] NULL,
	[is_ansi_null_default_on] [bit] NULL,
	[is_ansi_nulls_on] [bit] NULL,
	[is_ansi_padding_on] [bit] NULL,
	[is_ansi_warnings_on] [bit] NULL,
	[is_arithabort_on] [bit] NULL,
	[is_concat_null_yields_null_on] [bit] NULL,
	[is_numeric_roundabort_on] [bit] NULL,
	[is_quoted_identifier_on] [bit] NULL,
	[is_fulltext_enabled] [bit] NULL,
	[is_trustworthy_on] [bit] NULL,
	[is_parameterization_forced] [bit] NULL,
	[is_master_key_encrypted_by_server] [bit] NOT NULL,
	[is_published] [bit] NOT NULL,
	[is_subscribed] [bit] NOT NULL,
	[is_distributor] [bit] NOT NULL,
	[is_broker_enabled] [bit] NOT NULL,
	[is_auto_close_on] [bit] NOT NULL,
	[is_auto_shrink_on] [bit] NULL,
	[is_supplemental_logging_enabled] [bit] NULL,
	[is_merge_published] [bit] NOT NULL,
	[is_date_correlation_on] [bit] NOT NULL,
	[is_cdc_enabled] [bit] NOT NULL,
	[is_encrypted] [bit] NULL,
	[target_recovery_time_in_seconds] [int] NULL,
	[is_query_store_on] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20260521-155204]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20260521-155204] ON [General].[SQL_Database_Details_Current]
(
	[Pull_Time] ASC,
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Database_File_Details_Current]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Database_File_Details_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[database_name] [nvarchar](200) NULL,
	[state_desc] [nvarchar](100) NULL,
	[type_desc] [nvarchar](100) NULL,
	[name] [sysname] NULL,
	[physical_name] [nvarchar](1000) NULL,
	[growth] [int] NULL,
	[is_percent_growth] [bit] NULL,
	[Size_on_disk_GB] [float] NULL,
	[Drive] [nvarchar](1000) NULL,
	[Drive_Name] [nvarchar](1000) NULL,
	[Drive_Size_GB] [bigint] NULL,
	[Drive_Free_Space_GB] [bigint] NULL,
	[Drive_Full_Percent] [float] NULL,
	[GB_Written] [float] NULL,
	[GB_Read] [float] NULL,
	[io_stall_write_ms] [bigint] NULL,
	[io_stall_read_ms] [bigint] NULL,
	[WriteLatency] [float] NULL,
	[ReadLatency] [float] NULL,
	[Latency] [float] NULL,
	[AvgMBPerRead] [float] NULL,
	[AvgMBPerWrite] [float] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-105144]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-105144] ON [General].[SQL_Database_File_Details_Current]
(
	[SQL_Instance_Name] ASC,
	[database_name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Default_Trace]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Default_Trace](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NOT NULL,
	[Pull_Time] [smalldatetime] NULL,
	[name] [nvarchar](400) NULL,
	[subclass_name] [nvarchar](400) NULL,
	[DBName] [nvarchar](400) NULL,
	[LoginName] [nvarchar](400) NULL,
	[HostName] [nvarchar](400) NULL,
	[ApplicationName] [nvarchar](400) NULL,
	[TargetLoginName] [nvarchar](400) NULL,
	[Duration] [bigint] NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[Reads] [bigint] NULL,
	[Writes] [bigint] NULL,
	[CPU] [int] NULL,
	[Permissions] [bigint] NULL,
	[Severity] [int] NULL,
	[ObjectName] [nvarchar](400) NULL,
	[SPID] [int] NULL,
	[TextData] [varchar](400) NULL,
	[ObjectType] [varchar](400) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240814-063730]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240814-063730] ON [General].[SQL_Default_Trace]
(
	[SQL_Instance_Name] ASC,
	[AlwaysOn] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Default_Trace_Current]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Default_Trace_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NOT NULL,
	[Pull_Time] [smalldatetime] NULL,
	[name] [nvarchar](400) NULL,
	[subclass_name] [nvarchar](400) NULL,
	[DBName] [nvarchar](400) NULL,
	[LoginName] [nvarchar](400) NULL,
	[HostName] [nvarchar](400) NULL,
	[ApplicationName] [nvarchar](400) NULL,
	[TargetLoginName] [nvarchar](400) NULL,
	[Duration] [bigint] NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[Reads] [bigint] NULL,
	[Writes] [bigint] NULL,
	[CPU] [int] NULL,
	[Permissions] [bigint] NULL,
	[Severity] [int] NULL,
	[ObjectName] [nvarchar](400) NULL,
	[SPID] [int] NULL,
	[TextData] [varchar](400) NULL,
	[ObjectType] [varchar](400) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240814-063743]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240814-063743] ON [General].[SQL_Default_Trace_Current]
(
	[SQL_Instance_Name] ASC,
	[AlwaysOn] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Default_Trace_History]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Default_Trace_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NOT NULL,
	[Pull_Time] [smalldatetime] NULL,
	[name] [nvarchar](400) NULL,
	[subclass_name] [nvarchar](400) NULL,
	[DBName] [nvarchar](400) NULL,
	[LoginName] [nvarchar](400) NULL,
	[HostName] [nvarchar](400) NULL,
	[ApplicationName] [nvarchar](400) NULL,
	[TargetLoginName] [nvarchar](400) NULL,
	[Duration] [bigint] NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[Reads] [bigint] NULL,
	[Writes] [bigint] NULL,
	[CPU] [int] NULL,
	[Permissions] [bigint] NULL,
	[Severity] [int] NULL,
	[ObjectName] [nvarchar](400) NULL,
	[SPID] [int] NULL,
	[TextData] [varchar](400) NULL,
	[ObjectType] [varchar](400) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240814-063759]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240814-063759] ON [General].[SQL_Default_Trace_History]
(
	[SQL_Instance_Name] ASC,
	[AlwaysOn] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Instances_Details]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Instances_Details](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[TimeZone] [varchar](100) NULL,
	[DomainName] [nvarchar](4000) NULL,
	[IP_Address] [sql_variant] NULL,
	[Port] [sql_variant] NULL,
	[CPU_Count] [int] NULL,
	[PhysicalMemory_MB] [bigint] NULL,
	[Clustered] [varchar](50) NOT NULL,
	[Server_Type] [varchar](50) NOT NULL,
	[SQLVersion] [varchar](50) NULL,
	[SP] [sql_variant] NULL,
	[Version] [sql_variant] NULL,
	[Build_Level] [sql_variant] NULL,
	[Edition] [sql_variant] NULL,
	[LastRestartTime] [smalldatetime] NULL,
	[Install_Date] [smalldatetime] NULL,
	[SQL_Agent_Status] [nvarchar](256) NULL,
	[WindowsVersionBuild] [varchar](50) NOT NULL,
	[Total_Data_Size_GB] [float] NULL,
	[Total_Log_Size_GB] [float] NULL,
	[Total_Log_Size_Used_GB] [float] NULL,
	[User_Database_Count] [int] NULL,
	[Databases] [nvarchar](max) NOT NULL,
	[Default_Data_Path] [sql_variant] NULL,
	[Default_Log_Path] [sql_variant] NULL,
	[Login_Security] [varchar](50) NOT NULL,
	[Default_Collation] [sql_variant] NULL,
	[AlwaysOn_Manager_Status] [varchar](50) NOT NULL,
	[AlwaysOn_Feature_Status] [varchar](50) NOT NULL,
	[IsFullTextInstalled] [varchar](50) NOT NULL,
	[FilestreamConfiguredLevel] [varchar](50) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-083035]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-083035] ON [General].[SQL_Instances_Details]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Instances_Details_Current]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Instances_Details_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[TimeZone] [varchar](100) NULL,
	[DomainName] [nvarchar](4000) NULL,
	[IP_Address] [sql_variant] NULL,
	[Port] [sql_variant] NULL,
	[CPU_Count] [int] NULL,
	[PhysicalMemory_MB] [bigint] NULL,
	[Clustered] [varchar](50) NOT NULL,
	[Server_Type] [varchar](50) NOT NULL,
	[SQLVersion] [varchar](50) NULL,
	[SP] [sql_variant] NULL,
	[Version] [sql_variant] NULL,
	[Build_Level] [sql_variant] NULL,
	[Edition] [sql_variant] NULL,
	[LastRestartTime] [smalldatetime] NULL,
	[Install_Date] [smalldatetime] NULL,
	[SQL_Agent_Status] [nvarchar](256) NULL,
	[WindowsVersionBuild] [varchar](50) NOT NULL,
	[Total_Data_Size_GB] [float] NULL,
	[Total_Log_Size_GB] [float] NULL,
	[Total_Log_Size_Used_GB] [float] NULL,
	[User_Database_Count] [int] NULL,
	[Databases] [nvarchar](max) NOT NULL,
	[Default_Data_Path] [sql_variant] NULL,
	[Default_Log_Path] [sql_variant] NULL,
	[Login_Security] [varchar](50) NOT NULL,
	[Default_Collation] [sql_variant] NULL,
	[AlwaysOn_Manager_Status] [varchar](50) NOT NULL,
	[AlwaysOn_Feature_Status] [varchar](50) NOT NULL,
	[IsFullTextInstalled] [varchar](50) NOT NULL,
	[FilestreamConfiguredLevel] [varchar](50) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-083145]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-083145] ON [General].[SQL_Instances_Details_Current]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Instances_Details_History]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Instances_Details_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[TimeZone] [varchar](100) NULL,
	[DomainName] [nvarchar](4000) NULL,
	[IP_Address] [sql_variant] NULL,
	[Port] [sql_variant] NULL,
	[CPU_Count] [int] NULL,
	[PhysicalMemory_MB] [bigint] NULL,
	[Clustered] [varchar](50) NOT NULL,
	[Server_Type] [varchar](50) NOT NULL,
	[SQLVersion] [varchar](50) NULL,
	[SP] [sql_variant] NULL,
	[Version] [sql_variant] NULL,
	[Build_Level] [sql_variant] NULL,
	[Edition] [sql_variant] NULL,
	[LastRestartTime] [smalldatetime] NULL,
	[Install_Date] [smalldatetime] NULL,
	[SQL_Agent_Status] [nvarchar](256) NULL,
	[WindowsVersionBuild] [varchar](50) NOT NULL,
	[Total_Data_Size_GB] [float] NULL,
	[Total_Log_Size_GB] [float] NULL,
	[Total_Log_Size_Used_GB] [float] NULL,
	[User_Database_Count] [int] NULL,
	[Databases] [nvarchar](max) NOT NULL,
	[Default_Data_Path] [sql_variant] NULL,
	[Default_Log_Path] [sql_variant] NULL,
	[Login_Security] [varchar](50) NOT NULL,
	[Default_Collation] [sql_variant] NULL,
	[AlwaysOn_Manager_Status] [varchar](50) NOT NULL,
	[AlwaysOn_Feature_Status] [varchar](50) NOT NULL,
	[IsFullTextInstalled] [varchar](50) NOT NULL,
	[FilestreamConfiguredLevel] [varchar](50) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-083156]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-083156] ON [General].[SQL_Instances_Details_History]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Server_ErrorLog]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Server_ErrorLog](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[LogDate] [smalldatetime] NULL,
	[ProcessInfo] [varchar](60) NULL,
	[Text] [varchar](8000) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-160407]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-160407] ON [General].[SQL_Server_ErrorLog]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Server_ErrorLog_Current]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Server_ErrorLog_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[LogDate] [smalldatetime] NULL,
	[ProcessInfo] [varchar](60) NULL,
	[Text] [varchar](8000) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-160427]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-160427] ON [General].[SQL_Server_ErrorLog_Current]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Sessions_Catalog]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Sessions_Catalog](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[SessionID] [smallint] NULL,
	[status] [nchar](100) NULL,
	[Blocking_Session] [smallint] NULL,
	[open_tran] [smallint] NULL,
	[login_name] [nvarchar](200) NULL,
	[cmd] [nchar](80) NULL,
	[Last_Wait_Type] [nchar](100) NULL,
	[WaitTime] [bigint] NULL,
	[Host] [nvarchar](200) NULL,
	[Program] [nvarchar](200) NULL,
	[last_batch] [smalldatetime] NULL,
	[Database_Name] [nvarchar](200) NULL,
	[client_interface_name] [nvarchar](200) NULL,
	[login_time] [smalldatetime] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-164529]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-164529] ON [General].[SQL_Sessions_Catalog]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Sessions_Catalog_Current]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Sessions_Catalog_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[SessionID] [smallint] NULL,
	[status] [nchar](100) NULL,
	[Blocking_Session] [smallint] NULL,
	[open_tran] [smallint] NULL,
	[login_name] [nvarchar](200) NULL,
	[cmd] [nchar](80) NULL,
	[Last_Wait_Type] [nchar](100) NULL,
	[WaitTime] [bigint] NULL,
	[Host] [nvarchar](200) NULL,
	[Program] [nvarchar](200) NULL,
	[last_batch] [smalldatetime] NULL,
	[Database_Name] [nvarchar](200) NULL,
	[client_interface_name] [nvarchar](200) NULL,
	[login_time] [smalldatetime] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-164614]    Script Date: 6/6/2026 9:22:39 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-164614] ON [General].[SQL_Sessions_Catalog_Current]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Sessions_Catalog_History]    Script Date: 6/6/2026 9:22:39 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Sessions_Catalog_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[SessionID] [smallint] NULL,
	[status] [nchar](100) NULL,
	[Blocking_Session] [smallint] NULL,
	[open_tran] [smallint] NULL,
	[login_name] [nvarchar](200) NULL,
	[cmd] [nchar](80) NULL,
	[Last_Wait_Type] [nchar](100) NULL,
	[WaitTime] [bigint] NULL,
	[Host] [nvarchar](200) NULL,
	[Program] [nvarchar](200) NULL,
	[last_batch] [smalldatetime] NULL,
	[Database_Name] [nvarchar](200) NULL,
	[client_interface_name] [nvarchar](200) NULL,
	[login_time] [smalldatetime] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230912-164656]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230912-164656] ON [General].[SQL_Sessions_Catalog_History]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Sessions_Details]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Sessions_Details](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[SessionID] [smallint] NULL,
	[status] [nvarchar](50) NULL,
	[Blocking_Session] [smallint] NULL,
	[LeadBlocker] [varchar](50) NULL,
	[waitresource] [nvarchar](256) NULL,
	[open_tran] [smallint] NULL,
	[login_name] [nvarchar](200) NULL,
	[cmd] [nvarchar](100) NULL,
	[Text] [nvarchar](max) NULL,
	[Last_Wait_Type] [nvarchar](100) NULL,
	[WaitTime_Sec] [float] NULL,
	[WaitTime] [bigint] NULL,
	[transaction] [nvarchar](100) NULL,
	[transaction_start_time] [smalldatetime] NULL,
	[transaction_time_sec] [int] NULL,
	[transaction_type] [varchar](100) NULL,
	[transaction_State] [varchar](100) NULL,
	[Host] [nvarchar](200) NULL,
	[Program] [nvarchar](200) NULL,
	[last_batch] [smalldatetime] NULL,
	[Database_Name] [nvarchar](200) NULL,
	[client_interface_name] [nvarchar](100) NULL,
	[client_net_address] [nvarchar](100) NULL,
	[requested_memory_kb] [bigint] NULL,
	[max_used_memory_kb] [bigint] NULL,
	[Session_CPU_Time] [int] NULL,
	[Session_Memory] [int] NULL,
	[Session_Reads] [bigint] NULL,
	[Session_Writes] [bigint] NULL,
	[percent_complete] [real] NULL,
	[estimated_completion_time] [bigint] NULL,
	[UserMB] [float] NULL,
	[InternalMB] [float] NULL,
	[login_time] [smalldatetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-2024419-145436]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-2024419-145436] ON [General].[SQL_Sessions_Details]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Sessions_Details_Current]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Sessions_Details_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[SessionID] [smallint] NULL,
	[status] [nvarchar](50) NULL,
	[Blocking_Session] [smallint] NULL,
	[LeadBlocker] [varchar](50) NULL,
	[waitresource] [nvarchar](256) NULL,
	[open_tran] [smallint] NULL,
	[login_name] [nvarchar](200) NULL,
	[cmd] [nvarchar](100) NULL,
	[Text] [nvarchar](max) NULL,
	[Last_Wait_Type] [nvarchar](100) NULL,
	[WaitTime_Sec] [float] NULL,
	[WaitTime] [bigint] NULL,
	[transaction] [nvarchar](100) NULL,
	[transaction_start_time] [smalldatetime] NULL,
	[transaction_time_sec] [int] NULL,
	[transaction_type] [varchar](100) NULL,
	[transaction_State] [varchar](100) NULL,
	[Host] [nvarchar](200) NULL,
	[Program] [nvarchar](200) NULL,
	[last_batch] [smalldatetime] NULL,
	[Database_Name] [nvarchar](200) NULL,
	[client_interface_name] [nvarchar](100) NULL,
	[client_net_address] [nvarchar](100) NULL,
	[requested_memory_kb] [bigint] NULL,
	[max_used_memory_kb] [bigint] NULL,
	[Session_CPU_Time] [int] NULL,
	[Session_Memory] [int] NULL,
	[Session_Reads] [bigint] NULL,
	[Session_Writes] [bigint] NULL,
	[percent_complete] [real] NULL,
	[estimated_completion_time] [bigint] NULL,
	[UserMB] [float] NULL,
	[InternalMB] [float] NULL,
	[login_time] [smalldatetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-202230219-145507]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-202230219-145507] ON [General].[SQL_Sessions_Details_Current]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Sessions_Details_History]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Sessions_Details_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[SessionID] [smallint] NULL,
	[status] [nchar](50) NULL,
	[Blocking_Session] [smallint] NULL,
	[LeadBlocker] [varchar](50) NULL,
	[waitresource] [nchar](256) NULL,
	[open_tran] [smallint] NULL,
	[login_name] [nvarchar](200) NULL,
	[cmd] [nchar](100) NULL,
	[Text] [nvarchar](max) NULL,
	[Last_Wait_Type] [nchar](100) NULL,
	[WaitTime_Sec] [float] NULL,
	[WaitTime] [bigint] NULL,
	[transaction] [nvarchar](100) NULL,
	[transaction_start_time] [smalldatetime] NULL,
	[transaction_time_sec] [int] NULL,
	[transaction_type] [varchar](100) NULL,
	[transaction_State] [varchar](100) NULL,
	[Host] [nvarchar](200) NULL,
	[Program] [nvarchar](200) NULL,
	[last_batch] [smalldatetime] NULL,
	[Database_Name] [nvarchar](200) NULL,
	[client_interface_name] [nvarchar](100) NULL,
	[client_net_address] [nvarchar](100) NULL,
	[requested_memory_kb] [bigint] NULL,
	[max_used_memory_kb] [bigint] NULL,
	[Session_CPU_Time] [int] NULL,
	[Session_Memory] [int] NULL,
	[Session_Reads] [bigint] NULL,
	[Session_Writes] [bigint] NULL,
	[percent_complete] [real] NULL,
	[estimated_completion_time] [bigint] NULL,
	[UserMB] [float] NULL,
	[InternalMB] [float] NULL,
	[login_time] [smalldatetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230919-145525]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230919-145525] ON [General].[SQL_Sessions_Details_History]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Sessions_Login_History]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Sessions_Login_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[loginname] [nvarchar](128) NULL,
	[Host] [nvarchar](200) NULL,
	[Program] [nvarchar](200) NULL,
	[Database_Name] [nvarchar](200) NULL,
	[client_interface_name] [nvarchar](200) NULL,
	[LastLogin] [smalldatetime] NULL,
	[2025-04] [bigint] NULL,
	[2025-05] [bigint] NULL,
	[2025-06] [bigint] NULL,
	[2025-07] [bigint] NULL,
	[2025-08] [bigint] NULL,
	[2026-05] [bigint] NULL,
	[2026-06] [bigint] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250421-105056]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250421-105056] ON [General].[SQL_Sessions_Login_History]
(
	[SQL_Instance_Name] ASC,
	[loginname] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Statistics_CPU_Current]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Statistics_CPU_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Collection_Time] [smalldatetime] NULL,
	[SQLProcessUtilization] [int] NULL,
	[SystemIdle] [int] NULL,
	[OtherProcessUtilization] [int] NULL,
	[PageFaults] [bigint] NULL,
	[SQLMemoryUtilization] [int] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230913-081618]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230913-081618] ON [General].[SQL_Statistics_CPU_Current]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Statistics_Memory_Current]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Statistics_Memory_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[TotalPhysicalMemory_MB] [bigint] NULL,
	[AvailablePhysicalMemory_MB] [bigint] NULL,
	[SQL_ReservedMemory_MB] [bigint] NULL,
	[SQL_CommittedMemory_MB] [bigint] NULL,
	[TotalPageFile_MB] [bigint] NULL,
	[AvailablePageFile_MB] [bigint] NULL,
	[TotalVirtualAddressSpace_MB] [bigint] NULL,
	[AvailableVirtualAddressSpace_MB] [bigint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240819-145015]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240819-145015] ON [General].[SQL_Statistics_Memory_Current]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Statistics_Usage_Current]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Statistics_Usage_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Page_Life] [bigint] NULL,
	[Buffer_cache_hit_ratio] [float] NULL,
	[User_Connections] [bigint] NULL,
	[Logical_Connections] [bigint] NULL,
	[Transactions] [bigint] NULL,
	[Free_Space_in_tempdb_GB] [float] NULL,
	[Version_Store_Size_GB] [float] NULL,
	[Memory_Grants_Pending] [bigint] NULL,
	[Memory_Grants_Outstanding] [bigint] NULL,
	[TargetMemory_GB] [float] NULL,
	[TotalMemory_GB] [float] NULL,
	[Connection_Memory_MB] [float] NULL,
	[Database_Cache_Memory_MB] [float] NULL,
	[Free_Memory_MB] [float] NULL,
	[Granted_Workspace_Memory_MB] [float] NULL,
	[Lock_Memory_MB] [float] NULL,
	[Maximum_Workspace_Memory_MB] [float] NULL,
	[Optimizer_Memory_MB] [float] NULL,
	[Reserved_Server_Memory_MB] [float] NULL,
	[SQL_Cache_Memory_MB] [float] NULL,
	[Stolen_Server_Memory_MB] [float] NULL,
	[Log_Pool_Memory_MB] [float] NULL,
	[Batch_Requests] [bigint] NULL,
	[SQL_Compilations] [bigint] NULL,
	[SQL_ReCompilations] [bigint] NULL,
	[Page_lookups] [bigint] NULL,
	[Page_reads] [bigint] NULL,
	[Page_writes] [bigint] NULL,
	[Query_Store_CPU_usage] [bigint] NULL,
	[Query_Store_physical_reads] [bigint] NULL,
	[Query_Store_logical_reads] [bigint] NULL,
	[Query_Store_logical_writes] [bigint] NULL,
	[Batch_Req_500ms_1000ms] [bigint] NULL,
	[Batch_Req_1000ms_2000ms] [bigint] NULL,
	[Batch_Req_2000ms_5000ms] [bigint] NULL,
	[Batch_Req_5000ms_10000ms] [bigint] NULL,
	[Batch_Req_10000ms_20000ms] [bigint] NULL,
	[Batch_Req_20000ms_50000ms] [bigint] NULL,
	[Batch_Req_50000ms_100000ms] [bigint] NULL,
	[Batch_Req_100000ms_Plus] [bigint] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230913-082406]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230913-082406] ON [General].[SQL_Statistics_Usage_Current]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Xevent_Deadlocks]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Xevent_Deadlocks](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[EventName] [nvarchar](256) NULL,
	[LoginTimestamp] [datetime] NULL,
	[VictimHostName] [varchar](128) NULL,
	[VictimLoginName] [varchar](256) NULL,
	[VictimDatabase] [varchar](256) NULL,
	[Victimclientapp] [varchar](128) NULL,
	[Victimisolationlevel] [varchar](256) NULL,
	[VictimSQL] [varchar](1000) NULL,
	[VictimProcName] [varchar](256) NULL,
	[VictimKey] [varchar](256) NULL,
	[VictimLockObjectName] [varchar](256) NULL,
	[SurvivorHostName] [varchar](128) NULL,
	[SurvivorLoginName] [varchar](256) NULL,
	[SurvivorDatabase] [varchar](256) NULL,
	[Survivorclientapp] [varchar](128) NULL,
	[Survivorisolationlevel] [varchar](256) NULL,
	[SurvivorSQL] [varchar](1000) NULL,
	[SurvivorProcName] [varchar](256) NULL,
	[SurvivorKey] [varchar](256) NULL,
	[SurvivorLockObjectName] [varchar](256) NULL,
	[XML_Report] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230914-080837]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230914-080837] ON [General].[SQL_Xevent_Deadlocks]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Xevent_Deadlocks_Current]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Xevent_Deadlocks_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[EventName] [nvarchar](256) NULL,
	[LoginTimestamp] [datetime] NULL,
	[VictimHostName] [varchar](128) NULL,
	[VictimLoginName] [varchar](256) NULL,
	[VictimDatabase] [varchar](256) NULL,
	[Victimclientapp] [varchar](128) NULL,
	[Victimisolationlevel] [varchar](256) NULL,
	[VictimSQL] [varchar](1000) NULL,
	[VictimProcName] [varchar](256) NULL,
	[VictimKey] [varchar](256) NULL,
	[VictimLockObjectName] [varchar](256) NULL,
	[SurvivorHostName] [varchar](128) NULL,
	[SurvivorLoginName] [varchar](256) NULL,
	[SurvivorDatabase] [varchar](256) NULL,
	[Survivorclientapp] [varchar](128) NULL,
	[Survivorisolationlevel] [varchar](256) NULL,
	[SurvivorSQL] [varchar](1000) NULL,
	[SurvivorProcName] [varchar](256) NULL,
	[SurvivorKey] [varchar](256) NULL,
	[SurvivorLockObjectName] [varchar](256) NULL,
	[XML_Report] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230914-080825]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230914-080825] ON [General].[SQL_Xevent_Deadlocks_Current]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Xevent_FailedQueries]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Xevent_FailedQueries](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[EventName] [nvarchar](160) NULL,
	[LoginTimestamp] [datetime] NULL,
	[username] [nvarchar](200) NULL,
	[DatabaseName] [nvarchar](100) NULL,
	[client_hostname] [nvarchar](200) NULL,
	[client_app_name] [nvarchar](300) NULL,
	[error_number] [nvarchar](100) NULL,
	[message] [nvarchar](2000) NULL,
	[sql_text] [varchar](max) NULL,
	[Job_IDstring] [nvarchar](100) NULL,
	[plan_handle] [varchar](100) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230914-081224]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230914-081224] ON [General].[SQL_Xevent_FailedQueries]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[SQL_Xevent_FailedQueries_Current]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[SQL_Xevent_FailedQueries_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[EventName] [nvarchar](160) NULL,
	[LoginTimestamp] [datetime] NULL,
	[username] [nvarchar](200) NULL,
	[DatabaseName] [nvarchar](100) NULL,
	[client_hostname] [nvarchar](200) NULL,
	[client_app_name] [nvarchar](300) NULL,
	[error_number] [nvarchar](100) NULL,
	[message] [nvarchar](2000) NULL,
	[sql_text] [varchar](max) NULL,
	[Job_IDstring] [nvarchar](100) NULL,
	[plan_handle] [varchar](100) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230914-081235]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230914-081235] ON [General].[SQL_Xevent_FailedQueries_Current]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[VMWareVMMetrics_Current]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[VMWareVMMetrics_Current](
	[resourceId] [varchar](64) NULL,
	[resourceName] [varchar](16) NULL,
	[metric] [varchar](128) NULL,
	[intervalType] [varchar](8) NULL,
	[rollUpType] [varchar](8) NULL,
	[timestamp] [datetime2](2) NULL,
	[value] [float] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250221-083429]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250221-083429] ON [General].[VMWareVMMetrics_Current]
(
	[resourceName] ASC,
	[metric] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[VMWareVMMetrics_History]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[VMWareVMMetrics_History](
	[resourceId] [varchar](64) NULL,
	[resourceName] [varchar](16) NULL,
	[metric] [varchar](128) NULL,
	[intervalType] [varchar](8) NULL,
	[rollUpType] [varchar](8) NULL,
	[timestamp] [datetime2](2) NULL,
	[value] [float] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250221-083458]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250221-083458] ON [General].[VMWareVMMetrics_History]
(
	[resourceName] ASC,
	[metric] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [General].[VMWareVRLILogs]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[VMWareVRLILogs](
	[Name] [varchar](16) NULL,
	[text] [varchar](4000) NULL,
	[timestamp] [bigint] NULL,
	[timestampString] [varchar](128) NULL,
	[timestampLocal] [varchar](128) NULL,
	[vmw_vcenter] [varchar](64) NULL,
	[vmw_vcenter_id] [varchar](64) NULL,
	[vmw_vr_ops_id] [varchar](64) NULL,
	[hostname] [varchar](16) NULL,
	[vmw_cluster] [varchar](32) NULL,
	[vmw_datacenter] [varchar](32) NULL,
	[vc_event_type] [varchar](128) NULL,
	[vmw_object_id] [varchar](64) NULL,
	[event_type] [varchar](32) NULL,
	[appname] [varchar](16) NULL,
	[source] [varchar](32) NULL,
	[vrlic] [varchar](16) NULL,
	[complete] [varchar](7) NULL,
	[duration] [int] NULL,
	[collect_dt] [varchar](32) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [General].[VMWareVRLILogs_Current]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[VMWareVRLILogs_Current](
	[Name] [varchar](16) NULL,
	[text] [varchar](4000) NULL,
	[timestamp] [bigint] NULL,
	[timestampString] [varchar](128) NULL,
	[timestampLocal] [varchar](128) NULL,
	[vmw_vcenter] [varchar](64) NULL,
	[vmw_vcenter_id] [varchar](64) NULL,
	[vmw_vr_ops_id] [varchar](64) NULL,
	[hostname] [varchar](16) NULL,
	[vmw_cluster] [varchar](32) NULL,
	[vmw_datacenter] [varchar](32) NULL,
	[vc_event_type] [varchar](128) NULL,
	[vmw_object_id] [varchar](64) NULL,
	[event_type] [varchar](32) NULL,
	[appname] [varchar](16) NULL,
	[source] [varchar](32) NULL,
	[vrlic] [varchar](16) NULL,
	[complete] [varchar](7) NULL,
	[duration] [int] NULL,
	[collect_dt] [varchar](32) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [General].[VMWareVRLILogs_History]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [General].[VMWareVRLILogs_History](
	[Name] [varchar](16) NULL,
	[text] [varchar](4000) NULL,
	[timestamp] [bigint] NULL,
	[timestampString] [varchar](128) NULL,
	[timestampLocal] [varchar](128) NULL,
	[vmw_vcenter] [varchar](64) NULL,
	[vmw_vcenter_id] [varchar](64) NULL,
	[vmw_vr_ops_id] [varchar](64) NULL,
	[hostname] [varchar](16) NULL,
	[vmw_cluster] [varchar](32) NULL,
	[vmw_datacenter] [varchar](32) NULL,
	[vc_event_type] [varchar](128) NULL,
	[vmw_object_id] [varchar](64) NULL,
	[event_type] [varchar](32) NULL,
	[appname] [varchar](16) NULL,
	[source] [varchar](32) NULL,
	[vrlic] [varchar](16) NULL,
	[complete] [varchar](7) NULL,
	[duration] [int] NULL,
	[collect_dt] [varchar](32) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Manual].[SQL_Database_Index]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Manual].[SQL_Database_Index](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Table] [nvarchar](388) NULL,
	[IndexName] [sysname] NULL,
	[type_desc] [nvarchar](60) NULL,
	[is_primary_key] [bit] NULL,
	[is_unique_constraint] [bit] NULL,
	[IndexID] [int] NOT NULL,
	[TableRows] [bigint] NULL,
	[UserSeek] [bigint] NOT NULL,
	[UserScans] [bigint] NOT NULL,
	[UserLookups] [bigint] NOT NULL,
	[UserUpdates] [bigint] NOT NULL,
	[last_user_update] [smalldatetime] NULL,
	[user_seeks] [bigint] NULL,
	[user_scans] [bigint] NULL,
	[user_lookups] [bigint] NULL,
	[last_user_lookup] [smalldatetime] NULL,
	[last_user_scan] [smalldatetime] NULL,
	[Create_Date] [smalldatetime] NULL,
	[Modify_Date] [smalldatetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230914-081250]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230914-081250] ON [Manual].[SQL_Database_Index]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC,
	[Table] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Manual].[SQL_Database_Index_Current]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Manual].[SQL_Database_Index_Current](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Table] [nvarchar](388) NULL,
	[IndexName] [sysname] NULL,
	[type_desc] [nvarchar](60) NULL,
	[is_primary_key] [bit] NULL,
	[is_unique_constraint] [bit] NULL,
	[IndexID] [int] NOT NULL,
	[TableRows] [bigint] NULL,
	[UserSeek] [bigint] NOT NULL,
	[UserScans] [bigint] NOT NULL,
	[UserLookups] [bigint] NOT NULL,
	[UserUpdates] [bigint] NOT NULL,
	[last_user_update] [smalldatetime] NULL,
	[user_seeks] [bigint] NULL,
	[user_scans] [bigint] NULL,
	[user_lookups] [bigint] NULL,
	[last_user_lookup] [smalldatetime] NULL,
	[last_user_scan] [smalldatetime] NULL,
	[Create_Date] [smalldatetime] NULL,
	[Modify_Date] [smalldatetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230914-081307]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230914-081307] ON [Manual].[SQL_Database_Index_Current]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC,
	[Table] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Manual].[SQL_Database_QueryStore]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Manual].[SQL_Database_QueryStore](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Database_name] [nvarchar](128) NULL,
	[desired_state_desc] [nvarchar](60) NULL,
	[actual_state_desc] [nvarchar](60) NULL,
	[readonly_reason] [int] NULL,
	[current_storage_size_mb] [bigint] NULL,
	[max_storage_size_mb] [bigint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230914-081324]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230914-081324] ON [Manual].[SQL_Database_QueryStore]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC,
	[Database_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Manual].[SQL_Database_Table]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Manual].[SQL_Database_Table](
	[SQL_Instance_Name] [varchar](30) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Table] [nvarchar](388) NULL,
	[partition_number] [int] NOT NULL,
	[Row_Count] [bigint] NULL,
	[TotalSpace_GB] [numeric](37, 14) NULL,
	[Identity_Column] [sysname] NULL,
	[is_published] [bit] NOT NULL,
	[DATA_TYPE] [nvarchar](128) NULL,
	[Current_Identity] [bigint] NULL,
	[Max_Identity] [varchar](8000) NULL,
	[percent_full] [numeric](38, 6) NULL,
	[user_updates] [bigint] NULL,
	[last_user_update] [smalldatetime] NULL,
	[user_seeks] [bigint] NULL,
	[user_scans] [bigint] NULL,
	[user_lookups] [bigint] NULL,
	[last_Stats_Update] [smalldatetime] NULL,
	[Create_Date] [smalldatetime] NULL,
	[Modify_Date] [smalldatetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250411-132113]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250411-132113] ON [Manual].[SQL_Database_Table]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Manual].[SQL_Database_Table_Current]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Manual].[SQL_Database_Table_Current](
	[SQL_Instance_Name] [varchar](30) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Table] [nvarchar](388) NULL,
	[partition_number] [int] NOT NULL,
	[Row_Count] [bigint] NULL,
	[TotalSpace_GB] [numeric](37, 14) NULL,
	[Identity_Column] [sysname] NULL,
	[is_published] [bit] NOT NULL,
	[DATA_TYPE] [nvarchar](128) NULL,
	[Current_Identity] [bigint] NULL,
	[Max_Identity] [varchar](8000) NULL,
	[percent_full] [numeric](38, 6) NULL,
	[user_updates] [bigint] NULL,
	[last_user_update] [smalldatetime] NULL,
	[user_seeks] [bigint] NULL,
	[user_scans] [bigint] NULL,
	[user_lookups] [bigint] NULL,
	[last_Stats_Update] [smalldatetime] NULL,
	[Create_Date] [smalldatetime] NULL,
	[Modify_Date] [smalldatetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250411-132129]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250411-132129] ON [Manual].[SQL_Database_Table_Current]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Notifications].[Alert_History]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Notifications].[Alert_History](
	[Team] [varchar](50) NULL,
	[SQL_Instance_Name] [varchar](50) NULL,
	[Department] [varchar](50) NULL,
	[Alert] [varchar](50) NULL,
	[Send_Time] [smalldatetime] NULL,
	[Method] [varchar](20) NULL,
	[Header] [varchar](600) NULL,
	[Body] [varchar](2400) NULL,
	[Target_Email] [varchar](1000) NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240813-160839]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240813-160839] ON [Notifications].[Alert_History]
(
	[Team] ASC,
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [Notifications].[MNA]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Notifications].[MNA](
	[DNS] [varchar](200) NULL,
	[Pull_Time] [datetime] NULL,
	[createdOn] [datetime] NULL,
	[DaysOld] [bigint] NULL,
	[daysUntilAlertPurged] [bigint] NULL,
	[eventName] [varchar](200) NULL,
	[id] [bigint] NULL,
	[eventID] [bigint] NULL,
	[severity] [varchar](100) NULL,
	[databaseName] [varchar](500) NULL,
	[volumeName] [varchar](100) NULL,
	[hpsdTicketNbr] [varchar](500) NULL,
	[LOB] [varchar](50) NULL,
	[Assignment_Group] [varchar](200) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230803-142539]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230803-142539] ON [Notifications].[MNA]
(
	[DNS] ASC,
	[createdOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Settings].[Alert_Override]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Settings].[Alert_Override](
	[SQL_Instance_Name] [varchar](50) NULL,
	[Alert] [varchar](50) NULL,
	[Status] [varchar](20) NULL,
	[Start_Time] [datetime] NULL,
	[End_Time] [datetime] NULL,
	[Reason] [varchar](500) NULL,
	[Username] [varchar](50) NULL,
	[Date_Entered] [datetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240813-160925]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240813-160925] ON [Settings].[Alert_Override]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Settings].[DriveSpace_Request]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Settings].[DriveSpace_Request](
	[SQL_Instance_Name] [varchar](50) NULL,
	[Username] [varchar](50) NULL,
	[Date_Entered] [datetime] NULL,
	[Drive] [varchar](50) NULL,
	[Ticket] [varchar](200) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240814-064016]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240814-064016] ON [Settings].[DriveSpace_Request]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Settings].[Grooming]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Settings].[Grooming](
	[Collector] [varchar](150) NULL,
	[History] [int] NULL,
	[Delete] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240814-063947]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240814-063947] ON [Settings].[Grooming]
(
	[Collector] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Settings].[SQL_PatchLevel]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Settings].[SQL_PatchLevel](
	[BuildNumber] [varchar](32) NULL,
	[Description] [varchar](256) NULL,
	[ReleaseDate] [varchar](30) NULL,
	[SQLVersionName] [varchar](64) NULL,
	[PatchDate] [datetime] NULL,
	[WebLink] [varchar](512) NULL,
	[Updated] [datetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20240814-064150]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20240814-064150] ON [Settings].[SQL_PatchLevel]
(
	[BuildNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Team].[Team_Patching_History]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Team].[Team_Patching_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[Version] [varchar](50) NULL,
	[DBA_Name] [varchar](50) NULL,
	[Updated] [datetime] NULL,
	[Emailed] [varchar](200) NULL,
	[Change] [varchar](200) NULL,
	[Change_Status] [varchar](200) NULL,
	[Change_Time] [varchar](50) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230803-142623]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230803-142623] ON [Config].[SQL_Inventory_MNA]
(
	[Status_desc] ASC,
	[LOB] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230713-080123]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230713-080123] ON [Daily].[SQL_Instances_Configs]
(
	[Config_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230713-161017]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230713-161017] ON [Daily].[SQL_Instances_Configs]
(
	[SQL_Instance_Name] ASC,
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230714-082103]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230714-082103] ON [Daily].[SQL_Missing_Index]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230714-074325]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230714-074325] ON [Daily].[SQL_WaitStats]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-091327]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-091327] ON [General].[SQL_AgentJobs]
(
	[Status] ASC,
	[stop_execution_date] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-091632]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-091632] ON [General].[SQL_Database_AlwaysOn]
(
	[availability_mode_desc] ASC,
	[failover_mode_desc] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-101134]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-101134] ON [General].[SQL_Database_AlwaysOn]
(
	[SQL_Instance_Name] ASC,
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IXNC_DBA_Watcher_DB_database_state_desc]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [IXNC_DBA_Watcher_DB_database_state_desc] ON [General].[SQL_Database_AlwaysOn_Current]
(
	[database_state_desc] ASC
)
INCLUDE([availability_mode_desc]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IXNC_DBA_Watcher_DB_role_desc]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [IXNC_DBA_Watcher_DB_role_desc] ON [General].[SQL_Database_AlwaysOn_Current]
(
	[role_desc] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-091727]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-091727] ON [General].[SQL_Database_AlwaysOn_Current]
(
	[availability_mode_desc] ASC,
	[failover_mode_desc] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Index [NonClusteredIndex-20230912-091747]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-091747] ON [General].[SQL_Database_AlwaysOn_Current]
(
	[redo_queue_size] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-101148]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-101148] ON [General].[SQL_Database_AlwaysOn_Current]
(
	[SQL_Instance_Name] ASC,
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-101226]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-101226] ON [General].[SQL_Database_AlwaysOn_History]
(
	[SQL_Instance_Name] ASC,
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [NonClusteredIndex-20250421-085504]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20250421-085504] ON [General].[SQL_Database_Backup]
(
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Index [IXNC_DBA_Watcher_DB_Pull_Time]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [IXNC_DBA_Watcher_DB_Pull_Time] ON [General].[SQL_Database_Backup_History]
(
	[Pull_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-104719]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-104719] ON [General].[SQL_Database_File_Details]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-104900]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-104900] ON [General].[SQL_Database_File_Details]
(
	[Drive] ASC,
	[Drive_Size_GB] ASC,
	[Drive_Free_Space_GB] ASC,
	[Drive_Full_Percent] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-105159]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-105159] ON [General].[SQL_Database_File_Details_Current]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-105208]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-105208] ON [General].[SQL_Database_File_Details_Current]
(
	[Drive] ASC,
	[Drive_Size_GB] ASC,
	[Drive_Free_Space_GB] ASC,
	[Drive_Full_Percent] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-105247]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-105247] ON [General].[SQL_Database_File_Details_History]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-105257]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-105257] ON [General].[SQL_Database_File_Details_History]
(
	[Drive] ASC,
	[Drive_Size_GB] ASC,
	[Drive_Free_Space_GB] ASC,
	[Drive_Full_Percent] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-164541]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-164541] ON [General].[SQL_Sessions_Catalog]
(
	[login_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-164557]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-164557] ON [General].[SQL_Sessions_Catalog]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-164624]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-164624] ON [General].[SQL_Sessions_Catalog_Current]
(
	[login_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-164633]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-164633] ON [General].[SQL_Sessions_Catalog_Current]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-164706]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-164706] ON [General].[SQL_Sessions_Catalog_History]
(
	[login_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230912-164715]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230912-164715] ON [General].[SQL_Sessions_Catalog_History]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-2023r19-145648]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-2023r19-145648] ON [General].[SQL_Sessions_Details]
(
	[Last_Wait_Type] ASC,
	[WaitTime_Sec] ASC,
	[WaitTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-202e0919-145615]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-202e0919-145615] ON [General].[SQL_Sessions_Details]
(
	[Blocking_Session] ASC,
	[LeadBlocker] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20a30919-145537]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20a30919-145537] ON [General].[SQL_Sessions_Details]
(
	[login_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-2020919-145548]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-2020919-145548] ON [General].[SQL_Sessions_Details_Current]
(
	[login_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-2020919-145628]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-2020919-145628] ON [General].[SQL_Sessions_Details_Current]
(
	[Blocking_Session] ASC,
	[LeadBlocker] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-2022919-145731]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-2022919-145731] ON [General].[SQL_Sessions_Details_Current]
(
	[Last_Wait_Type] ASC,
	[WaitTime_Sec] ASC,
	[WaitTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230919-145603]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230919-145603] ON [General].[SQL_Sessions_Details_History]
(
	[login_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230919-145638]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230919-145638] ON [General].[SQL_Sessions_Details_History]
(
	[Blocking_Session] ASC,
	[LeadBlocker] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230919-145743]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230919-145743] ON [General].[SQL_Sessions_Details_History]
(
	[Last_Wait_Type] ASC,
	[WaitTime_Sec] ASC,
	[WaitTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20250421-105115]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20250421-105115] ON [General].[SQL_Sessions_Login_History]
(
	[Host] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20250421-105125]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20250421-105125] ON [General].[SQL_Sessions_Login_History]
(
	[Program] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20250421-105150]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20250421-105150] ON [General].[SQL_Sessions_Login_History]
(
	[Database_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230913-082146]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230913-082146] ON [General].[SQL_Statistics_CPU]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Index [NonClusteredIndex-20230913-082159]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230913-082159] ON [General].[SQL_Statistics_CPU]
(
	[Collection_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230913-081630]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230913-081630] ON [General].[SQL_Statistics_CPU_Current]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [NonClusteredIndex-20230913-081702]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230913-081702] ON [General].[SQL_Statistics_CPU_Current]
(
	[Collection_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230913-081726]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230913-081726] ON [General].[SQL_Statistics_CPU_History]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Index [NonClusteredIndex-20230913-081736]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230913-081736] ON [General].[SQL_Statistics_CPU_History]
(
	[Collection_Time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230913-082348]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230913-082348] ON [General].[SQL_Statistics_Usage]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230913-082415]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230913-082415] ON [General].[SQL_Statistics_Usage_Current]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20230913-082454]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20230913-082454] ON [General].[SQL_Statistics_Usage_History]
(
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IXNC_DBA_Watcher_DB_metric_timestamp]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [IXNC_DBA_Watcher_DB_metric_timestamp] ON [General].[VMWareVMMetrics]
(
	[metric] ASC,
	[timestamp] ASC
)
INCLUDE([value]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IXNC_DBA_Watcher_DB_timestamp]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [IXNC_DBA_Watcher_DB_timestamp] ON [General].[VMWareVMMetrics_History]
(
	[timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IXNC_DBA_Watcher_DB_Header]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [IXNC_DBA_Watcher_DB_Header] ON [Notifications].[Alert_History]
(
	[Header] ASC
)
INCLUDE([Send_Time]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IXNC_DBA_Watcher_DB_Method_Send_Time]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [IXNC_DBA_Watcher_DB_Method_Send_Time] ON [Notifications].[Alert_History]
(
	[Method] ASC,
	[Send_Time] ASC
)
INCLUDE([Header]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IXNC_DBA_Watcher_DB_SQL_Instance_Name]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [IXNC_DBA_Watcher_DB_SQL_Instance_Name] ON [Notifications].[Alert_History]
(
	[SQL_Instance_Name] ASC
)
INCLUDE([Alert],[Send_Time]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IXNC_DBA_Watcher_DB_SQL_Instance_Name_Method]    Script Date: 6/6/2026 9:22:40 PM ******/
CREATE NONCLUSTERED INDEX [IXNC_DBA_Watcher_DB_SQL_Instance_Name_Method] ON [Notifications].[Alert_History]
(
	[SQL_Instance_Name] ASC,
	[Method] ASC
)
INCLUDE([Header],[Send_Time],[Target_Email]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
ALTER TABLE [Config].[Azure_Inventory] ADD  DEFAULT ('n') FOR [OnShore]
GO
ALTER TABLE [Config].[MongoDB_Inventory] ADD  DEFAULT ('n') FOR [OnShore]
GO
ALTER TABLE [Config].[SQL_Inventory] ADD  DEFAULT ('n') FOR [OnShore]
GO
ALTER TABLE [Config].[SQL_Inventory] ADD  DEFAULT ((1)) FOR [numa_node_count]
GO
ALTER TABLE [General].[SQL_Sessions_Login_History] ADD  DEFAULT ((0)) FOR [2025-04]
GO
ALTER TABLE [General].[SQL_Sessions_Login_History] ADD  DEFAULT ((0)) FOR [2025-05]
GO
ALTER TABLE [General].[SQL_Sessions_Login_History] ADD  DEFAULT ((0)) FOR [2025-06]
GO
ALTER TABLE [General].[SQL_Sessions_Login_History] ADD  DEFAULT ((0)) FOR [2025-07]
GO
ALTER TABLE [General].[SQL_Sessions_Login_History] ADD  DEFAULT ((0)) FOR [2025-08]
GO
ALTER TABLE [General].[SQL_Sessions_Login_History] ADD  DEFAULT ((0)) FOR [2026-05]
GO
ALTER TABLE [General].[SQL_Sessions_Login_History] ADD  DEFAULT ((0)) FOR [2026-06]
GO
/****** Object:  StoredProcedure [Alerts].[SQL_Session_Block_Email]    Script Date: 6/6/2026 9:22:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE  PROCEDURE [Alerts].[SQL_Session_Block_Email] 
@collector varchar(150)
AS
BEGIN 

if object_id('tempdb..#SQL_Session_Block') is not null
    drop table #SQL_Session_Block
if object_id('tempdb..#view_SQL_Session_Block') is not null
    drop table #view_SQL_Session_Block

CREATE TABLE #view_SQL_Session_Block (SQL_Instance_Name varchar(200))
DECLARE @sql nvarchar (1000)
SET @sql = 'INSERT INTO #view select SQL_Instance_Name from [DBA_Watcher_DB].[dbo].' + @collector +''
EXEC sp_executesql @sql

declare @AlertType varchar(50)
set @AlertType = 'SQL_Session_Block'

declare @team varchar(50)
declare @EmailAddress varchar(600)
declare @ReplyAddress varchar(600)
declare @header varchar(200)
declare @tab char(2) = CHAR(9) + CHAR(9)
declare @SQL_Instance_Name varchar(200)
declare @Login_Domain varchar(20)
declare @Department varchar(50)
declare @DepartmentShort varchar(50)
declare @bodytext varchar(2400) = 'Server'
declare @customer_email varchar(200)
declare @PriorityLevel varchar(10)
declare @Application_Name varchar(400)
declare @Service_Level_Owner varchar(200)
declare @Service_Level_Owner_Email varchar(200)

declare @SessionID int
declare @Database_Name varchar(120)
declare @cmd varchar(20)
declare @Text varchar(max)
declare @login_name varchar(50)
declare @host varchar(50)
declare @Count_blocked int
declare @Max_Wait_sec float
declare @Last_Wait_Type varchar(20)
declare @max_used_memory_kb int

SELECT si.Team ,si.Department, si.Login_Domain, PriorityLevel, si.Application_Name, si.[Service_Level_Owner], si.Service_Level_Owner_Email, si.Customer_Email,
ss.SQL_Instance_Name, ss.SessionID, ss.[Database_Name], ss.cmd, ss.Text, ss.login_name, ss.Host, ss2.[Count_blocked], ss2.Max_Wait_sec, cast(ss.[Last_Wait_Type] as varchar) as [Last_Wait_Type], 
ss.[max_used_memory_kb]  
into #SQL_Session_Block
FROM [DBA_Watcher_DB].[dbo].[Inventory_All] si with (nolock)
	inner join [DBA_Watcher_DB].[General].[SQL_Sessions_Current] ss with (nolock) on si.SQL_Instance_Name = ss.SQL_Instance_Name
	inner join (select SQL_Instance_Name, count(sessionid) as [Count_blocked], [Database_Name], max (WaitTime_Sec) as [Max_Wait_sec] 
		from [DBA_Watcher_DB].[General].[SQL_Sessions_Current] with (nolock) where Last_Wait_Type like 'LCK_%' and WaitTime > 300000   
		and Blocking_Session <>0  group by SQL_Instance_Name, [Database_Name]) ss2 on  ss.SQL_Instance_Name = ss2.SQL_Instance_Name and ss.[Database_Name] = ss2.[Database_Name]
where ss.SQL_Instance_Name in (select SQL_Instance_Name from #view_SQL_Session_Block )
and (ss.LeadBlocker = 'Lead' or (ss.SessionID in (SELECT distinct [Blocking_Session] FROM [DBA_Watcher_DB].[General].[SQL_Sessions_Current] ssh 
where ss.SQL_Instance_Name = ssh.SQL_Instance_Name and ssh.Last_Wait_Type like 'LCK_%' and ssh.WaitTime > 400000 and ssh.Blocking_Session <>0))) 
and ss.Blocking_Session = 0 and (Department like 'Prod' or si.Customer_Email not like '' or (si.SQL_Instance_Name in (select ao.SQL_Instance_Name 
from [DBA_Watcher_DB].[Settings].[Alert_Override] ao where ao.[Status] = 'enabled' and ao.[Alert] = @AlertType))) and si.SQL_Instance_Name not in 
(select ao2.SQL_Instance_Name from [DBA_Watcher_DB].[Settings].[Alert_Override] ao2 where ao2.[Status] = 'disabled' and ao2.[Alert] = @AlertType)
order by ss.Text desc

Delete from #SQL_Session_Block where text like '%I_OPT_WMS_CLS_NONSHIP_ORD_INTF%'
Delete from #SQL_Session_Block where text like '%sp_batchinsert_%' and [Count_blocked]<4
Delete from #SQL_Session_Block where text like '%sp_replcmds%' and [Count_blocked]<4
Delete from #SQL_Session_Block where text like '%OracleGG_%' and [Count_blocked]<4

WHILE EXISTS(SELECT * FROM #SQL_Session_Block)
BEGIN  

select top 1 @SQL_Instance_Name = [SQL_Instance_Name], @Login_Domain = [Login_Domain], @Department = [Department],@Application_Name =isnull([Application_Name],''),
@Service_Level_Owner=isnull([Service_Level_Owner],''),@Service_Level_Owner_Email=isnull([Service_Level_Owner_Email],''),@PriorityLevel = PriorityLevel,
@Customer_Email=isnull([Customer_Email],''), @Database_Name = [Database_Name] ,@cmd = [cmd], @Text  = [Text] ,@login_name = [login_name], @SessionID = [SessionID],
@Host = [Host] ,@Count_blocked = [Count_blocked] ,@Max_Wait_sec = [Max_Wait_sec], @Last_Wait_Type = [Last_Wait_Type], @max_used_memory_kb = [max_used_memory_kb], @Team = [team]
from #SQL_Session_Block order by SQL_Instance_Name

Set @EmailAddress = (SELECT [group_email] FROM [DBA_Watcher_DB].[Settings].[General] where [Team] like @team)
Set @ReplyAddress = (SELECT [reply_to] FROM [DBA_Watcher_DB].[Settings].[General] where [Team] like @team)
select @EmailAddress = ''+@EmailAddress  +' ' + ISNULL(@customer_email, '') +'' 
set @DepartmentShort = (select CASE WHEN @Department like '%prod%' Then 'Prod' else 'Dev' END)

Set @header = '[' + @DepartmentShort + ']['+ @Login_Domain +']['+ @SQL_Instance_Name +'] Spid '+ cast(@SessionID as varchar) +' blocking '+ cast(@Count_blocked as varchar) +' for '+ cast(round((@Max_Wait_sec/60),0) as varchar)+' mins'
set @bodytext = ''+ @Department +' Server '+ @SQL_Instance_Name +' Spid '+ cast(@SessionID as varchar) +' blocking '+ cast(@Count_blocked as varchar) +' session for '+ cast(round((@Max_Wait_sec/60),0) as varchar)+' mins.
AppName =   '+@PriorityLevel+' '+@Application_Name+' 
SLO =       '+@Service_Level_Owner+'  '+@Service_Level_Owner_Email+'

Command   '+@cmd+'
Database  '+@Database_Name +'
LoginName '+@login_name+'
Host      '+@host+'
Last Wait '+@Last_Wait_Type+'
Max Memory KB '+cast(@max_used_memory_kb as varchar)+'

'+ SUBSTRING(@Text,1,1600)+''

EXEC msdb.dbo.sp_send_dbmail
    @recipients = @EmailAddress,
	@reply_to = @ReplyAddress,
    @subject = @header,    
	@body_format='TEXT',
	@body = @bodytext ;

Insert into [DBA_Watcher_DB].[Notifications].[Alert_History]([Team],[SQL_Instance_Name],[Department],[Alert]
,[Send_Time],[Method],[Header],[Body],[Target_Email]) VALUES (@Team, @SQL_Instance_Name,@DepartmentShort,@AlertType,cast(getdate() as smalldatetime),'Email',@header,@bodytext,@EmailAddress)

delete from #SQL_Session_Block where [SQL_Instance_Name] in (select top 1 [SQL_Instance_Name] from #SQL_Session_Block order by SQL_Instance_Name)
END  

END
GO
USE [master]
GO
ALTER DATABASE [DBA_Watcher_DB] SET  READ_WRITE 
GO
