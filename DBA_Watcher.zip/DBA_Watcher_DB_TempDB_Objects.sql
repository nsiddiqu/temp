
GO
CREATE TABLE [Baseline].[SQL_Sessions_Details](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Active_Sessions] [int] NULL,
	[Blocked_Sessions] [int] NULL,
	[Open_Trasactions] [int] NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230913-133832]    Script Date: 6/6/2026 9:54:35 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230913-133832] ON [Baseline].[SQL_Sessions_Details]
(
	[SQL_Instance_Name] ASC,
	[Pull_Time] ASC,
	[AlwaysOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [Baseline].[SQL_Statistics_CPU]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Baseline].[SQL_Statistics_CPU](
	[SQL_Instance_Name] [varchar](40) NULL,
	[dotw] [int] NULL,
	[hh] [int] NULL,
	[SQLProcessUtilization] [int] NULL,
	[OtherProcessUtilization] [int] NULL,
	[SystemIdle] [int] NULL,
	[PageFaults] [bigint] NULL,
	[SQLMemoryUtilization] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230914-160310]    Script Date: 6/6/2026 9:54:35 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230914-160310] ON [Baseline].[SQL_Statistics_CPU]
(
	[SQL_Instance_Name] ASC,
	[dotw] ASC,
	[hh] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Baseline].[SQL_Statistics_Memory]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Baseline].[SQL_Statistics_Memory](
	[SQL_Instance_Name] [varchar](50) NULL,
	[dotw] [int] NULL,
	[hh] [int] NULL,
	[TotalPhysicalMemory_MB] [bigint] NULL,
	[AvailablePhysicalMemory_MB] [bigint] NULL,
	[SQL_ReservedMemory_MB] [bigint] NULL,
	[SQL_CommittedMemory_MB] [bigint] NULL,
	[TotalPageFile_MB] [bigint] NULL,
	[AvailablePageFile_MB] [bigint] NULL,
	[TotalVirtualAddressSpace_MB] [bigint] NULL,
	[AvailableVirtualAddressSpace_MB] [bigint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250402-155849]    Script Date: 6/6/2026 9:54:35 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250402-155849] ON [Baseline].[SQL_Statistics_Memory]
(
	[SQL_Instance_Name] ASC,
	[dotw] ASC,
	[hh] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Baseline].[SQL_Statistics_Usage]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Baseline].[SQL_Statistics_Usage](
	[SQL_Instance_Name] [varchar](50) NULL,
	[dotw] [int] NULL,
	[hh] [int] NULL,
	[Page_Life] [bigint] NULL,
	[Buffer_cache_hit_ratio] [float] NULL,
	[User_Connections] [bigint] NULL,
	[Logical_Connections] [bigint] NULL,
	[Transactions] [bigint] NULL,
	[Free_Space_in_tempdb_GB] [float] NULL,
	[Version_Store_Size_GB] [float] NULL,
	[Memory_Grants_Pending] [bigint] NULL,
	[Memory_Grants_Outstanding] [bigint] NULL,
	[TargetMemory_GB] [float] NULL,
	[TotalMemory_GB] [float] NULL,
	[Connection_Memory_MB] [float] NULL,
	[Database_Cache_Memory_MB] [float] NULL,
	[Free_Memory_MB] [float] NULL,
	[Granted_Workspace_Memory_MB] [float] NULL,
	[Lock_Memory_MB] [float] NULL,
	[Maximum_Workspace_Memory_MB] [float] NULL,
	[Optimizer_Memory_MB] [float] NULL,
	[Reserved_Server_Memory_MB] [float] NULL,
	[SQL_Cache_Memory_MB] [float] NULL,
	[Stolen_Server_Memory_MB] [float] NULL,
	[Log_Pool_Memory_MB] [float] NULL,
	[Batch_Requests] [bigint] NULL,
	[SQL_Compilations] [bigint] NULL,
	[SQL_ReCompilations] [bigint] NULL,
	[Page_lookups] [bigint] NULL,
	[Page_reads] [bigint] NULL,
	[Page_writes] [bigint] NULL,
	[Query_Store_CPU_usage] [bigint] NULL,
	[Query_Store_physical_reads] [bigint] NULL,
	[Query_Store_logical_reads] [bigint] NULL,
	[Query_Store_logical_writes] [bigint] NULL,
	[Batch_Req_500ms_1000ms] [bigint] NULL,
	[Batch_Req_1000ms_2000ms] [bigint] NULL,
	[Batch_Req_2000ms_5000ms] [bigint] NULL,
	[Batch_Req_5000ms_10000ms] [bigint] NULL,
	[Batch_Req_10000ms_20000ms] [bigint] NULL,
	[Batch_Req_20000ms_50000ms] [bigint] NULL,
	[Batch_Req_50000ms_100000ms] [bigint] NULL,
	[Batch_Req_100000ms_Plus] [bigint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230914-161540]    Script Date: 6/6/2026 9:54:35 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230914-161540] ON [Baseline].[SQL_Statistics_Usage]
(
	[SQL_Instance_Name] ASC,
	[dotw] ASC,
	[hh] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Baseline].[VMWareVMMetrics]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Baseline].[VMWareVMMetrics](
	[SQL_Instance_Name] [varchar](40) NULL,
	[dotw] [int] NULL,
	[hh] [int] NULL,
	[metric] [varchar](128) NULL,
	[intervalType] [varchar](8) NULL,
	[rollUpType] [varchar](8) NULL,
	[value] [float] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230914-161916]    Script Date: 6/6/2026 9:54:35 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230914-161916] ON [Baseline].[VMWareVMMetrics]
(
	[SQL_Instance_Name] ASC,
	[dotw] ASC,
	[hh] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[vrops_api_key]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[vrops_api_key](
	[token] [varchar](max) NULL,
	[validity] [bigint] NULL,
	[expiresAt] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[vrops_load_errorlog]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[vrops_load_errorlog](
	[resourceName] [varchar](32) NULL,
	[timestamp] [datetime] NULL,
	[errorMessage] [varchar](4000) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[DailyVolume]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[DailyVolume](
	[Name] [varchar](500) NULL,
	[Value] [varchar](500) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[Pager_load]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[Pager_load](
	[date] [smalldatetime] NULL,
	[name] [varchar](100) NULL,
	[name2] [varchar](100) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[SQL_Database_AlwaysOn]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[SQL_Database_AlwaysOn](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[dns_name] [nvarchar](100) NULL,
	[ag_name] [varchar](50) NULL,
	[replica_server_name] [varchar](50) NULL,
	[database_name] [varchar](50) NULL,
	[log_send_queue_size] [bigint] NULL,
	[log_send_rate] [bigint] NULL,
	[redo_queue_size] [bigint] NULL,
	[redo_rate] [bigint] NULL,
	[last_sent_time] [datetime] NULL,
	[last_received_time] [datetime] NULL,
	[role_desc] [nvarchar](100) NULL,
	[database_state_desc] [nvarchar](100) NULL,
	[availability_mode_desc] [nvarchar](100) NULL,
	[failover_mode_desc] [nvarchar](100) NULL,
	[automated_backup_preference_desc] [nvarchar](100) NULL,
	[synchronization_state_desc] [nvarchar](100) NULL,
	[synchronization_health_desc] [nvarchar](100) NULL,
	[secondary_role_allow_connections_desc] [nvarchar](100) NULL,
	[last_commit_time] [datetime] NULL,
	[health_check_timeout] [int] NULL,
	[is_suspended] [bit] NULL,
	[endpoint_url] [nvarchar](500) NULL,
	[join_state_desc] [nvarchar](100) NULL,
	[connected_state_desc] [nvarchar](100) NULL,
	[failure_condition_level] [int] NULL,
	[create_date] [datetime] NULL,
	[modify_date] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[SQL_Database_Details]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[SQL_Database_Details](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Database_name] [nvarchar](200) NULL,
	[compatibility_level] [tinyint] NOT NULL,
	[recovery_model_desc] [nvarchar](100) NULL,
	[Data_Size_GB] [float] NULL,
	[Log_Size_GB] [float] NULL,
	[Log_Used_Size_GB] [float] NULL,
	[Percent_Log_Used] [bigint] NULL,
	[log_reuse_wait_desc] [nvarchar](100) NULL,
	[state_desc] [nvarchar](100) NULL,
	[is_read_only] [varchar](100) NOT NULL,
	[user_access_desc] [nvarchar](100) NULL,
	[snapshot_isolation_state_desc] [nvarchar](100) NULL,
	[is_read_committed_snapshot_on] [bit] NULL,
	[Active_Transactions] [bigint] NULL,
	[Transactions_sec] [bigint] NULL,
	[Repl_Trans_Rate] [bigint] NULL,
	[Backup_Restore_Throughput_sec] [bigint] NULL,
	[DBCC_Logical_Scan_Bytes_sec] [bigint] NULL,
	[Log_Growths] [bigint] NULL,
	[Query_Store_physical_reads] [bigint] NULL,
	[Query_Store_logical_reads] [bigint] NULL,
	[Query_Store_logical_writes] [bigint] NULL,
	[Query_Store_CPU_usage] [bigint] NULL,
	[create_date] [smalldatetime] NULL,
	[collation_name] [sysname] NULL,
	[page_verify_option_desc] [nvarchar](100) NULL,
	[is_in_standby] [bit] NULL,
	[is_cleanly_shutdown] [bit] NULL,
	[is_auto_create_stats_on] [bit] NULL,
	[is_auto_update_stats_on] [bit] NULL,
	[is_auto_update_stats_async_on] [bit] NULL,
	[is_ansi_null_default_on] [bit] NULL,
	[is_ansi_nulls_on] [bit] NULL,
	[is_ansi_padding_on] [bit] NULL,
	[is_ansi_warnings_on] [bit] NULL,
	[is_arithabort_on] [bit] NULL,
	[is_concat_null_yields_null_on] [bit] NULL,
	[is_numeric_roundabort_on] [bit] NULL,
	[is_quoted_identifier_on] [bit] NULL,
	[is_fulltext_enabled] [bit] NULL,
	[is_trustworthy_on] [bit] NULL,
	[is_parameterization_forced] [bit] NULL,
	[is_master_key_encrypted_by_server] [bit] NOT NULL,
	[is_published] [bit] NOT NULL,
	[is_subscribed] [bit] NOT NULL,
	[is_distributor] [bit] NOT NULL,
	[is_broker_enabled] [bit] NOT NULL,
	[is_auto_close_on] [bit] NOT NULL,
	[is_auto_shrink_on] [bit] NULL,
	[is_supplemental_logging_enabled] [bit] NULL,
	[is_merge_published] [bit] NOT NULL,
	[is_date_correlation_on] [bit] NOT NULL,
	[is_cdc_enabled] [bit] NOT NULL,
	[is_encrypted] [bit] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[SQL_Database_Details_Raw]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[SQL_Database_Details_Raw](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Database_name] [nvarchar](200) NULL,
	[compatibility_level] [tinyint] NOT NULL,
	[recovery_model_desc] [nvarchar](100) NULL,
	[Data_Size_GB] [float] NULL,
	[Log_Size_GB] [float] NULL,
	[Log_Used_Size_GB] [float] NULL,
	[Percent_Log_Used] [bigint] NULL,
	[log_reuse_wait_desc] [nvarchar](100) NULL,
	[state_desc] [nvarchar](100) NULL,
	[is_read_only] [varchar](100) NOT NULL,
	[user_access_desc] [nvarchar](100) NULL,
	[snapshot_isolation_state_desc] [nvarchar](100) NULL,
	[is_read_committed_snapshot_on] [bit] NULL,
	[Active_Transactions] [bigint] NULL,
	[Transactions_sec] [bigint] NULL,
	[Repl_Trans_Rate] [bigint] NULL,
	[Backup_Restore_Throughput_sec] [bigint] NULL,
	[DBCC_Logical_Scan_Bytes_sec] [bigint] NULL,
	[Log_Growths] [bigint] NULL,
	[Query_Store_physical_reads] [bigint] NULL,
	[Query_Store_logical_reads] [bigint] NULL,
	[Query_Store_logical_writes] [bigint] NULL,
	[Query_Store_CPU_usage] [bigint] NULL,
	[create_date] [smalldatetime] NULL,
	[collation_name] [sysname] NULL,
	[page_verify_option_desc] [nvarchar](100) NULL,
	[is_in_standby] [bit] NULL,
	[is_cleanly_shutdown] [bit] NULL,
	[is_auto_create_stats_on] [bit] NULL,
	[is_auto_update_stats_on] [bit] NULL,
	[is_auto_update_stats_async_on] [bit] NULL,
	[is_ansi_null_default_on] [bit] NULL,
	[is_ansi_nulls_on] [bit] NULL,
	[is_ansi_padding_on] [bit] NULL,
	[is_ansi_warnings_on] [bit] NULL,
	[is_arithabort_on] [bit] NULL,
	[is_concat_null_yields_null_on] [bit] NULL,
	[is_numeric_roundabort_on] [bit] NULL,
	[is_quoted_identifier_on] [bit] NULL,
	[is_fulltext_enabled] [bit] NULL,
	[is_trustworthy_on] [bit] NULL,
	[is_parameterization_forced] [bit] NULL,
	[is_master_key_encrypted_by_server] [bit] NOT NULL,
	[is_published] [bit] NOT NULL,
	[is_subscribed] [bit] NOT NULL,
	[is_distributor] [bit] NOT NULL,
	[is_broker_enabled] [bit] NOT NULL,
	[is_auto_close_on] [bit] NOT NULL,
	[is_auto_shrink_on] [bit] NULL,
	[is_supplemental_logging_enabled] [bit] NULL,
	[is_merge_published] [bit] NOT NULL,
	[is_date_correlation_on] [bit] NOT NULL,
	[is_cdc_enabled] [bit] NOT NULL,
	[is_encrypted] [bit] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250415-130318]    Script Date: 6/6/2026 9:54:35 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250415-130318] ON [Scratch].[SQL_Database_Details_Raw]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[SQL_Database_File_Details]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[SQL_Database_File_Details](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[database_name] [nvarchar](200) NULL,
	[state_desc] [nvarchar](100) NULL,
	[type_desc] [nvarchar](100) NULL,
	[name] [sysname] NULL,
	[physical_name] [nvarchar](1000) NULL,
	[growth] [int] NULL,
	[is_percent_growth] [bit] NULL,
	[Size_on_disk_GB] [float] NULL,
	[Drive] [nvarchar](1000) NULL,
	[Drive_Name] [nvarchar](1000) NULL,
	[Drive_Size_GB] [bigint] NULL,
	[Drive_Free_Space_GB] [bigint] NULL,
	[Drive_Full_Percent] [float] NULL,
	[GB_Written] [float] NULL,
	[GB_Read] [float] NULL,
	[io_stall_write_ms] [bigint] NULL,
	[io_stall_read_ms] [bigint] NULL,
	[WriteLatency] [float] NULL,
	[ReadLatency] [float] NULL,
	[Latency] [float] NULL,
	[AvgMBPerRead] [float] NULL,
	[AvgMBPerWrite] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[SQL_Enabled_Check]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[SQL_Enabled_Check](
	[SQL_Instance_Name] [varchar](200) NULL,
	[Pull_Time] [datetime] NOT NULL,
	[LastRestartTime] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[SQL_Instances_Configs]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[SQL_Instances_Configs](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Config_Name] [varchar](100) NULL,
	[value] [bigint] NULL,
	[value_in_use] [bigint] NULL,
	[description] [varchar](400) NULL
) ON [PRIMARY]
WITH
(
DATA_COMPRESSION = PAGE
)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20230713-090900]    Script Date: 6/6/2026 9:54:35 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20230713-090900] ON [Scratch].[SQL_Instances_Configs]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[SQL_Instances_Details]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[SQL_Instances_Details](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[TimeZone] [varchar](100) NULL,
	[DomainName] [nvarchar](4000) NULL,
	[IP_Address] [sql_variant] NULL,
	[Port] [sql_variant] NULL,
	[CPU_Count] [int] NULL,
	[PhysicalMemory_MB] [bigint] NULL,
	[Clustered] [varchar](50) NOT NULL,
	[Server_Type] [varchar](50) NOT NULL,
	[SQLVersion] [varchar](50) NULL,
	[SP] [sql_variant] NULL,
	[Version] [sql_variant] NULL,
	[Build_Level] [sql_variant] NULL,
	[Edition] [sql_variant] NULL,
	[LastRestartTime] [smalldatetime] NULL,
	[Install_Date] [smalldatetime] NULL,
	[SQL_Agent_Status] [nvarchar](256) NULL,
	[WindowsVersionBuild] [varchar](50) NOT NULL,
	[Total_Data_Size_GB] [float] NULL,
	[Total_Log_Size_GB] [float] NULL,
	[Total_Log_Size_Used_GB] [float] NULL,
	[User_Database_Count] [int] NULL,
	[Databases] [nvarchar](max) NOT NULL,
	[Default_Data_Path] [sql_variant] NULL,
	[Default_Log_Path] [sql_variant] NULL,
	[Login_Security] [varchar](50) NOT NULL,
	[Default_Collation] [sql_variant] NULL,
	[AlwaysOn_Manager_Status] [varchar](50) NOT NULL,
	[AlwaysOn_Feature_Status] [varchar](50) NOT NULL,
	[IsFullTextInstalled] [varchar](50) NOT NULL,
	[FilestreamConfiguredLevel] [varchar](50) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[SQL_Missing_Index]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[SQL_Missing_Index](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[DatabaseName] [nvarchar](128) NULL,
	[UniqueCompiles] [bigint] NOT NULL,
	[UniqueCompiles_Change] [bigint] NULL,
	[AvgTotalUserCost] [float] NULL,
	[AvgTotalUserCost_Change] [float] NULL,
	[AvgUserImpact] [float] NULL,
	[AvgUserImpact_Change] [float] NULL,
	[IndexAdvantage] [float] NULL,
	[IndexAdvantage_Change] [float] NULL,
	[FullyQualifiedObjectName] [nvarchar](1000) NULL,
	[EqualityColumns] [nvarchar](1000) NULL,
	[InEqualityColumns] [nvarchar](1000) NULL,
	[IncludedColumns] [nvarchar](1000) NULL,
	[ProposedIndex] [varchar](1000) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[SQL_Server_Logins]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[SQL_Server_Logins](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[loginname] [nvarchar](128) NOT NULL,
	[type_desc] [nvarchar](200) NULL,
	[default_database_name] [nvarchar](128) NULL,
	[default_language_name] [nvarchar](128) NULL,
	[Locked] [varchar](20) NOT NULL,
	[Disabled] [varchar](20) NOT NULL,
	[create_date] [smalldatetime] NULL,
	[modify_date] [smalldatetime] NULL,
	[denylogin] [int] NULL,
	[hasaccess] [int] NULL,
	[isntname] [int] NULL,
	[isntuser] [int] NULL,
	[sysadmin] [int] NULL,
	[securityadmin] [int] NULL,
	[serveradmin] [int] NULL,
	[setupadmin] [int] NULL,
	[processadmin] [int] NULL,
	[diskadmin] [int] NULL,
	[dbcreator] [int] NULL,
	[bulkadmin] [int] NULL,
	[is_policy_checked] [bit] NULL,
	[is_expiration_checked] [bit] NULL,
	[status] [smallint] NULL,
	[System] [nvarchar](600) NOT NULL,
	[SQL_BadPasswordCount] [sql_variant] NULL,
	[SQL_BadPasswordTime] [smalldatetime] NULL,
	[SQL_PasswordSetAge] [int] NULL,
	[SQL_HistoryLength] [sql_variant] NULL,
	[SQL_IsExpired] [sql_variant] NULL,
	[SQL_IsMustChange] [sql_variant] NULL,
	[SQL_LockoutTime] [smalldatetime] NULL,
	[SQL_PasswordLastSetTime] [smalldatetime] NULL,
	[sid] [varchar](200) NULL,
	[PasswordHash] [varchar](200) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[SQL_Sessions_Login_History]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[SQL_Sessions_Login_History](
	[SQL_Instance_Name] [varchar](50) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[loginname] [nvarchar](128) NULL,
	[Host] [nvarchar](200) NULL,
	[Program] [nvarchar](200) NULL,
	[Database_Name] [nvarchar](200) NULL,
	[client_interface_name] [nvarchar](200) NULL,
	[Last_Login] [smalldatetime] NULL,
	[Login_Count] [bigint] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[SQL_Statistics_Usage]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[SQL_Statistics_Usage](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Page_Life] [bigint] NULL,
	[Buffer_cache_hit_ratio] [float] NULL,
	[User_Connections] [bigint] NULL,
	[Logical_Connections] [bigint] NULL,
	[Transactions] [bigint] NULL,
	[Free_Space_in_tempdb_GB] [float] NULL,
	[Version_Store_Size_GB] [float] NULL,
	[Memory_Grants_Pending] [bigint] NULL,
	[Memory_Grants_Outstanding] [bigint] NULL,
	[TargetMemory_GB] [float] NULL,
	[TotalMemory_GB] [float] NULL,
	[Connection_Memory_MB] [float] NULL,
	[Database_Cache_Memory_MB] [float] NULL,
	[Free_Memory_MB] [float] NULL,
	[Granted_Workspace_Memory_MB] [float] NULL,
	[Lock_Memory_MB] [float] NULL,
	[Maximum_Workspace_Memory_MB] [float] NULL,
	[Optimizer_Memory_MB] [float] NULL,
	[Reserved_Server_Memory_MB] [float] NULL,
	[SQL_Cache_Memory_MB] [float] NULL,
	[Stolen_Server_Memory_MB] [float] NULL,
	[Log_Pool_Memory_MB] [float] NULL,
	[Batch_Requests] [bigint] NULL,
	[SQL_Compilations] [bigint] NULL,
	[SQL_ReCompilations] [bigint] NULL,
	[Page_lookups] [bigint] NULL,
	[Page_reads] [bigint] NULL,
	[Page_writes] [bigint] NULL,
	[Query_Store_CPU_usage] [bigint] NULL,
	[Query_Store_physical_reads] [bigint] NULL,
	[Query_Store_logical_reads] [bigint] NULL,
	[Query_Store_logical_writes] [bigint] NULL,
	[Batch_Req_500ms_1000ms] [bigint] NULL,
	[Batch_Req_1000ms_2000ms] [bigint] NULL,
	[Batch_Req_2000ms_5000ms] [bigint] NULL,
	[Batch_Req_5000ms_10000ms] [bigint] NULL,
	[Batch_Req_10000ms_20000ms] [bigint] NULL,
	[Batch_Req_20000ms_50000ms] [bigint] NULL,
	[Batch_Req_50000ms_100000ms] [bigint] NULL,
	[Batch_Req_100000ms_Plus] [bigint] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [Scratch].[SQL_Statistics_Usage_Raw]    Script Date: 6/6/2026 9:54:35 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [Scratch].[SQL_Statistics_Usage_Raw](
	[SQL_Instance_Name] [varchar](50) NULL,
	[AlwaysOn] [varchar](20) NULL,
	[Pull_Time] [smalldatetime] NULL,
	[Page_Life] [bigint] NULL,
	[Buffer_cache_hit_ratio] [float] NULL,
	[User_Connections] [bigint] NULL,
	[Logical_Connections] [bigint] NULL,
	[Transactions] [bigint] NULL,
	[Free_Space_in_tempdb_GB] [float] NULL,
	[Version_Store_Size_GB] [float] NULL,
	[Memory_Grants_Pending] [bigint] NULL,
	[Memory_Grants_Outstanding] [bigint] NULL,
	[TargetMemory_GB] [float] NULL,
	[TotalMemory_GB] [float] NULL,
	[Connection_Memory_MB] [float] NULL,
	[Database_Cache_Memory_MB] [float] NULL,
	[Free_Memory_MB] [float] NULL,
	[Granted_Workspace_Memory_MB] [float] NULL,
	[Lock_Memory_MB] [float] NULL,
	[Maximum_Workspace_Memory_MB] [float] NULL,
	[Optimizer_Memory_MB] [float] NULL,
	[Reserved_Server_Memory_MB] [float] NULL,
	[SQL_Cache_Memory_MB] [float] NULL,
	[Stolen_Server_Memory_MB] [float] NULL,
	[Log_Pool_Memory_MB] [float] NULL,
	[Batch_Requests] [bigint] NULL,
	[SQL_Compilations] [bigint] NULL,
	[SQL_ReCompilations] [bigint] NULL,
	[Page_lookups] [bigint] NULL,
	[Page_reads] [bigint] NULL,
	[Page_writes] [bigint] NULL,
	[Query_Store_CPU_usage] [bigint] NULL,
	[Query_Store_physical_reads] [bigint] NULL,
	[Query_Store_logical_reads] [bigint] NULL,
	[Query_Store_logical_writes] [bigint] NULL,
	[Batch_Req_500ms_1000ms] [bigint] NULL,
	[Batch_Req_1000ms_2000ms] [bigint] NULL,
	[Batch_Req_2000ms_5000ms] [bigint] NULL,
	[Batch_Req_5000ms_10000ms] [bigint] NULL,
	[Batch_Req_10000ms_20000ms] [bigint] NULL,
	[Batch_Req_20000ms_50000ms] [bigint] NULL,
	[Batch_Req_50000ms_100000ms] [bigint] NULL,
	[Batch_Req_100000ms_Plus] [bigint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [ClusteredIndex-20250415-121359]    Script Date: 6/6/2026 9:54:35 PM ******/
CREATE CLUSTERED INDEX [ClusteredIndex-20250415-121359] ON [Scratch].[SQL_Statistics_Usage_Raw]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IXNC_DBA_Watcher_DB_Tempdb_SQL_Instance_Name_Database_name]    Script Date: 6/6/2026 9:54:35 PM ******/
CREATE NONCLUSTERED INDEX [IXNC_DBA_Watcher_DB_Tempdb_SQL_Instance_Name_Database_name] ON [Scratch].[SQL_Database_Details]
(
	[SQL_Instance_Name] ASC,
	[Database_name] ASC
)
INCLUDE([Pull_Time],[Transactions_sec],[Backup_Restore_Throughput_sec],[DBCC_Logical_Scan_Bytes_sec]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IXNC_DBA_Watcher_DB_Tempdb_Drive_Full_Percent]    Script Date: 6/6/2026 9:54:35 PM ******/
CREATE NONCLUSTERED INDEX [IXNC_DBA_Watcher_DB_Tempdb_Drive_Full_Percent] ON [Scratch].[SQL_Database_File_Details]
(
	[Drive_Full_Percent] ASC
)
INCLUDE([SQL_Instance_Name],[Drive]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IXNC_DBA_Watcher_DB_Tempdb_SQL_Instance_Name]    Script Date: 6/6/2026 9:54:35 PM ******/
CREATE NONCLUSTERED INDEX [IXNC_DBA_Watcher_DB_Tempdb_SQL_Instance_Name] ON [Scratch].[SQL_Instances_Details]
(
	[SQL_Instance_Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
USE [master]
GO
ALTER DATABASE [DBA_Watcher_DB_Tempdb] SET  READ_WRITE 
GO
