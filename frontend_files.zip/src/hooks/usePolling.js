import { useState, useEffect, useCallback, useRef } from 'react'

/**
 * Polls an async `fetcher` function every `intervalMs`.
 * Returns { data, loading, error, refresh, lastUpdated }
 */
export function usePolling(fetcher, intervalMs = 5000) {
  const [data, setData]               = useState(null)
  const [loading, setLoading]         = useState(true)
  const [error, setError]             = useState(null)
  const [lastUpdated, setLastUpdated] = useState(null)
  const mountedRef                    = useRef(true)

  const refresh = useCallback(async () => {
    try {
      const result = await fetcher()
      if (mountedRef.current) {
        setData(result)
        setError(null)
        setLastUpdated(new Date())
      }
    } catch (err) {
      if (mountedRef.current) setError(err.message)
    } finally {
      if (mountedRef.current) setLoading(false)
    }
  }, [fetcher])

  useEffect(() => {
    mountedRef.current = true
    refresh()
    const id = setInterval(refresh, intervalMs)
    return () => {
      mountedRef.current = false
      clearInterval(id)
    }
  }, [refresh, intervalMs])

  return { data, loading, error, refresh, lastUpdated }
}
