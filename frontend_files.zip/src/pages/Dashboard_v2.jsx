import { useState, useCallback, useRef } from 'react'
import { usePolling } from '../hooks/usePolling'
import { fetchHealthMetrics, fetchSessions, fetchBlockers, fetchLongRunning } from '../services/api'
import TopBar from '../components/TopBar'
import KpiRow from '../components/KpiRow'
import MetricsCharts from '../components/MetricsCharts'
import SessionsTable from '../components/SessionsTable'
import BlockersTable from '../components/BlockersTable'
import LongRunningTable from '../components/LongRunningTable'
import QueryPage from '../components/QueryPage'
import DbaChat from '../components/DbaChat'
import { ErrorBanner } from '../components/UI'

const TABS = [
  { key: 'sessions',    label: 'Active Sessions' },
  { key: 'blockers',    label: 'Lead Blockers' },
  { key: 'longrunning', label: 'Long Running' },
  { key: 'query',       label: 'Custom Query' },
]

export default function Dashboard() {
  const [tab, setTab]         = useState('sessions')
  const [chatOpen, setChatOpen] = useState(true)
  const [history, setHistory] = useState([])
  const histRef               = useRef([])

  // ── Polling ────────────────────────────────────────────────────────────────
  const memoHealth = useCallback(async () => {
    const m = await fetchHealthMetrics()
    const point = {
      t: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      CPU: m.cpu_usage,
      Memory: m.memory_usage_pct,
    }
    histRef.current = [...histRef.current.slice(-19), point]
    setHistory([...histRef.current])
    return m
  }, [])

  const { data: metrics, error: metricsErr, lastUpdated, refresh: refreshMetrics } = usePolling(memoHealth, 5000)
  const { data: sessions, error: sessErr }   = usePolling(useCallback(() => fetchSessions(), []), 5000)
  const { data: blockers, error: blockErr }  = usePolling(useCallback(() => fetchBlockers(), []), 5000)
  const { data: longRunning, error: lrErr }  = usePolling(useCallback(() => fetchLongRunning(30), []), 10000)

  const cpu = metrics?.cpu_usage ?? 0
  const mem = metrics?.memory_usage_pct ?? 0
  const cpuColor = cpu > 80 ? 'var(--red)' : cpu > 60 ? 'var(--yellow)' : 'var(--green)'
  const memColor = mem > 85 ? 'var(--red)' : mem > 70 ? 'var(--yellow)' : 'var(--accent)'
  const anyError = metricsErr || sessErr || blockErr || lrErr
  const tabCount = { sessions: sessions?.length, blockers: blockers?.length, longrunning: longRunning?.length, query: null }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>

      {/* ── Sticky top bar ── */}
      <TopBar metrics={metrics} lastUpdated={lastUpdated} onRefresh={refreshMetrics}>
        {/* Chat toggle button injected via prop — see TopBar update below */}
        <button
          onClick={() => setChatOpen(o => !o)}
          title={chatOpen ? 'Hide Chat' : 'Show DBA Chat'}
          style={{
            background: chatOpen ? 'rgba(0,212,255,0.15)' : 'rgba(0,212,255,0.06)',
            border: `1px solid rgba(0,212,255,${chatOpen ? '0.5' : '0.25'})`,
            color: '#00d4ff', borderRadius: 5, padding: '6px 14px',
            fontFamily: 'var(--font-mono)', fontSize: 12, letterSpacing: 1,
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
          }}>
          <span style={{ fontSize: 14 }}>⬡</span>
          {chatOpen ? 'HIDE CHAT' : 'DBA CHAT'}
        </button>
      </TopBar>

      {/* ── Body: main panel + chat sidebar ── */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>

        {/* ── Main dashboard scrollable area ── */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '24px 28px', minWidth: 0 }}>
          {anyError && <ErrorBanner message={anyError} />}

          <KpiRow
            metrics={metrics}
            blockerCount={blockers?.length ?? 0}
            suspendedCount={sessions?.filter(s => s.status === 'suspended').length ?? 0}
          />

          <MetricsCharts history={history} cpuColor={cpuColor} memColor={memColor} />

          {/* Tab bar */}
          <div style={{ display: 'flex', gap: 0, marginBottom: 16, borderBottom: '1px solid var(--border)' }}>
            {TABS.map(({ key, label }) => {
              const active   = tab === key
              const isAlert  = key === 'blockers' && (blockers?.length ?? 0) > 0
              const color    = isAlert ? 'var(--red)' : active ? 'var(--accent)' : 'var(--muted)'
              return (
                <button key={key} onClick={() => setTab(key)} style={{
                  background: 'none', border: 'none',
                  borderBottom: active ? `2px solid ${isAlert ? 'var(--red)' : 'var(--accent)'}` : '2px solid transparent',
                  color, cursor: 'pointer', padding: '10px 20px',
                  fontFamily: 'var(--font-mono)', fontSize: 13, letterSpacing: 1,
                  display: 'flex', alignItems: 'center', gap: 8, marginBottom: -1, transition: 'color 0.2s',
                }}>
                  {label.toUpperCase()}
                  {tabCount[key] != null && (
                    <span style={{ background: color + '22', color, border: `1px solid ${color}44`, borderRadius: 10, padding: '0 8px', fontSize: 11 }}>
                      {tabCount[key]}
                    </span>
                  )}
                  {isAlert && <span style={{ fontSize: 14 }}>⚠</span>}
                </button>
              )
            })}
          </div>

          {tab === 'sessions'    && <SessionsTable    sessions={sessions} />}
          {tab === 'blockers'    && <BlockersTable    blockers={blockers} />}
          {tab === 'longrunning' && <LongRunningTable queries={longRunning} />}
          {tab === 'query'       && <QueryPage />}

          <div style={{ marginTop: 24, display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ color: 'var(--muted)', fontSize: 11, fontFamily: 'var(--font-mono)' }}>AUTO-REFRESH 5s · LONG-RUNNING 10s</span>
            <span style={{ color: 'var(--muted)', fontSize: 11, fontFamily: 'var(--font-mono)' }}>DBA AGENT v1.0</span>
          </div>
        </div>

        {/* ── Chat sidebar (collapsible) ── */}
        <div style={{
          width: chatOpen ? 420 : 0,
          minWidth: chatOpen ? 420 : 0,
          overflow: 'hidden',
          borderLeft: chatOpen ? '1px solid var(--border)' : 'none',
          transition: 'width 0.3s ease, min-width 0.3s ease',
          flexShrink: 0,
          display: 'flex',
          flexDirection: 'column',
        }}>
          {chatOpen && <DbaChat selectedServer={selectedServer} />}
        </div>

      </div>
    </div>
  )
}
