import { useState, useCallback, useRef } from 'react'
import { usePolling } from '../hooks/usePolling'
import { fetchHealthMetrics, fetchSessions, fetchBlockers, fetchLongRunning } from '../services/api'
import TopBar from '../components/TopBar'
import KpiRow from '../components/KpiRow'
import MetricsCharts from '../components/MetricsCharts'
import SessionsTable from '../components/SessionsTable'
import BlockersTable from '../components/BlockersTable'
import LongRunningTable from '../components/LongRunningTable'
import QueryPage from '../components/QueryPage'
import { ErrorBanner } from '../components/UI'

const TABS = [
  { key: 'sessions',    label: 'Active Sessions' },
  { key: 'blockers',    label: 'Lead Blockers' },
  { key: 'longrunning', label: 'Long Running' },
  { key: 'query',       label: 'Custom Query' },
]

export default function Dashboard() {
  const [tab, setTab]       = useState('sessions')
  const [history, setHistory] = useState([])
  const histRef             = useRef([])

  // ── Polling hooks ──────────────────────────────────────────────────────────
  const memoHealth = useCallback(async () => {
    const m = await fetchHealthMetrics()
    const point = {
      t: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      CPU: m.cpu_usage,
      Memory: m.memory_usage_pct,
    }
    histRef.current = [...histRef.current.slice(-19), point]
    setHistory([...histRef.current])
    return m
  }, [])

  const { data: metrics, error: metricsErr, lastUpdated, refresh: refreshMetrics } = usePolling(memoHealth, 5000)
  const { data: sessions, error: sessErr }     = usePolling(useCallback(() => fetchSessions(), []), 5000)
  const { data: blockers, error: blockErr }    = usePolling(useCallback(() => fetchBlockers(), []), 5000)
  const { data: longRunning, error: lrErr }    = usePolling(useCallback(() => fetchLongRunning(30), []), 10000)

  const cpu = metrics?.cpu_usage ?? 0
  const mem = metrics?.memory_usage_pct ?? 0
  const cpuColor = cpu > 80 ? 'var(--red)' : cpu > 60 ? 'var(--yellow)' : 'var(--green)'
  const memColor = mem > 85 ? 'var(--red)' : mem > 70 ? 'var(--yellow)' : 'var(--accent)'

  const anyError = metricsErr || sessErr || blockErr || lrErr

  const tabCount = { sessions: sessions?.length, blockers: blockers?.length, longrunning: longRunning?.length, query: null }

  return (
    <div style={{ minHeight: '100vh' }}>
      <TopBar metrics={metrics} lastUpdated={lastUpdated} onRefresh={refreshMetrics} />

      <div style={{ padding: '24px 28px' }}>
        {anyError && <ErrorBanner message={anyError} />}

        <KpiRow
          metrics={metrics}
          blockerCount={blockers?.length ?? 0}
          suspendedCount={sessions?.filter(s => s.status === 'suspended').length ?? 0}
        />

        <MetricsCharts history={history} cpuColor={cpuColor} memColor={memColor} />

        {/* Tab bar */}
        <div style={{ display: 'flex', gap: 0, marginBottom: 16, borderBottom: '1px solid var(--border)' }}>
          {TABS.map(({ key, label }) => {
            const active = tab === key
            const isAlert = key === 'blockers' && (blockers?.length ?? 0) > 0
            const color = isAlert ? 'var(--red)' : active ? 'var(--accent)' : 'var(--muted)'
            return (
              <button key={key} onClick={() => setTab(key)} style={{
                background: 'none', border: 'none',
                borderBottom: active ? `2px solid ${isAlert ? 'var(--red)' : 'var(--accent)'}` : '2px solid transparent',
                color, cursor: 'pointer', padding: '10px 20px',
                fontFamily: 'var(--font-mono)', fontSize: 13, letterSpacing: 1,
                display: 'flex', alignItems: 'center', gap: 8, marginBottom: -1,
                transition: 'color 0.2s',
              }}>
                {label.toUpperCase()}
                {tabCount[key] != null && (
                  <span style={{ background: color + '22', color, border: `1px solid ${color}44`, borderRadius: 10, padding: '0 8px', fontSize: 11 }}>
                    {tabCount[key]}
                  </span>
                )}
                {isAlert && <span style={{ fontSize: 14 }}>⚠</span>}
              </button>
            )
          })}
        </div>

        {tab === 'sessions'    && <SessionsTable    sessions={sessions} />}
        {tab === 'blockers'    && <BlockersTable    blockers={blockers} />}
        {tab === 'longrunning' && <LongRunningTable queries={longRunning} />}
        {tab === 'query'       && <QueryPage />}

        <div style={{ marginTop: 24, display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ color: 'var(--muted)', fontSize: 11, fontFamily: 'var(--font-mono)' }}>AUTO-REFRESH 5s · LONG-RUNNING 10s</span>
          <span style={{ color: 'var(--muted)', fontSize: 11, fontFamily: 'var(--font-mono)' }}>DBA AGENT v1.0</span>
        </div>
      </div>
    </div>
  )
}
