/**
 * ServerContext — Phase 1
 * Provides the selected server_id and server list to the entire app.
 * Wrap <App> with <ServerProvider> in main.jsx.
 */
import { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { fetchServers, connectServer } from '../services/api'

const ServerContext = createContext(null)

export function ServerProvider({ children }) {
  const [servers, setServers]           = useState([])   // ServerRegistryEntry[]
  const [selectedId, setSelectedId]     = useState(null) // currently active server_id
  const [loadingServers, setLoading]    = useState(true)
  const [connectError, setConnectError] = useState(null)

  // Load registry on mount
  const loadServers = useCallback(async () => {
    setLoading(true)
    try {
      const list = await fetchServers()
      setServers(list)
      // Auto-select first server if none chosen yet
      if (list.length > 0 && selectedId === null) {
        setSelectedId(list[0].server_id)
      }
    } catch (e) {
      console.error('Failed to load server registry:', e)
    } finally {
      setLoading(false)
    }
  }, [selectedId])

  useEffect(() => { loadServers() }, [])   // eslint-disable-line

  const selectServer = useCallback(async (serverId) => {
    setConnectError(null)
    try {
      await connectServer(serverId)
      setSelectedId(serverId)
    } catch (e) {
      setConnectError(e.message)
    }
  }, [])

  const currentServer = servers.find(s => s.server_id === selectedId) ?? null

  return (
    <ServerContext.Provider value={{
      servers,
      selectedId,
      currentServer,
      loadingServers,
      connectError,
      selectServer,
      reloadServers: loadServers,
    }}>
      {children}
    </ServerContext.Provider>
  )
}

export function useServer() {
  const ctx = useContext(ServerContext)
  if (!ctx) throw new Error('useServer must be used inside <ServerProvider>')
  return ctx
}
