/**
 * ServerPicker.jsx — Phase 1
 * Renders inside the TopBar.
 * - Dropdown of registered servers grouped by environment
 * - "Add server" button that opens an inline modal form
 */
import { useState } from 'react'
import { useServer } from '../context/ServerContext'
import { addServer } from '../services/api'

const ENV_ORDER = ['prod', 'dr', 'dev', 'qa']

const ENV_COLORS = {
  prod: '#ff4444',
  dr:   '#ffd740',
  dev:  '#00e676',
  qa:   '#00d4ff',
}

function envColor(env) {
  return ENV_COLORS[env?.toLowerCase()] ?? '#4a6080'
}

// ─── Inline modal ──────────────────────────────────────────────────────────────
function AddServerModal({ onClose, onAdded }) {
  const [form, setForm] = useState({
    display_name: '', host_name: '', port: 1433,
    db_name: 'master', auth_type: 'sql', db_user: '', db_password: '',
    environment: 'prod', tags: '', notes: '',
  })
  const [saving, setSaving] = useState(false)
  const [err, setErr]       = useState(null)

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  async function handleSubmit() {
    if (!form.display_name || !form.host_name) {
      setErr('Display name and host are required.')
      return
    }
    if (form.auth_type === 'sql' && (!form.db_user || !form.db_password)) {
      setErr('SQL authentication requires a username and password.')
      return
    }
    setSaving(true)
    setErr(null)
    try {
      const srv = await addServer({ ...form, port: Number(form.port) })
      onAdded(srv)
      onClose()
    } catch (e) {
      setErr(e.message)
    } finally {
      setSaving(false)
    }
  }

  const inputStyle = {
    width: '100%', background: 'var(--bg)', border: '1px solid var(--border)',
    color: 'var(--text)', borderRadius: 4, padding: '6px 10px',
    fontFamily: 'var(--font-mono)', fontSize: 12, marginTop: 4,
  }
  const labelStyle = {
    fontSize: 11, color: 'var(--muted)', fontFamily: 'var(--font-mono)',
    letterSpacing: 1, display: 'block', marginTop: 10,
  }

  return (
    /* backdrop */
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.65)',
        zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: 'var(--panel)', border: '1px solid var(--border)',
          borderRadius: 8, padding: 24, width: 440, maxHeight: '80vh',
          overflowY: 'auto',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 700, color: 'var(--accent)', letterSpacing: 2 }}>
            + ADD SERVER
          </span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--muted)', fontSize: 18, lineHeight: 1 }}>✕</button>
        </div>

        {err && (
          <div style={{ background: 'rgba(255,68,68,0.1)', border: '1px solid #ff444440', color: '#ff6666', borderRadius: 4, padding: '8px 12px', fontSize: 12, marginBottom: 12 }}>
            {err}
          </div>
        )}

        <label style={labelStyle}>DISPLAY NAME</label>
        <input style={inputStyle} value={form.display_name} onChange={e => set('display_name', e.target.value)} placeholder="PROD-SQL-01" />

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 80px', gap: 8 }}>
          <div>
            <label style={labelStyle}>HOST / IP</label>
            <input style={inputStyle} value={form.host_name} onChange={e => set('host_name', e.target.value)} placeholder="sqlsrv-prod-01" />
          </div>
          <div>
            <label style={labelStyle}>PORT</label>
            <input style={inputStyle} type="number" value={form.port} onChange={e => set('port', e.target.value)} />
          </div>
        </div>

        <label style={labelStyle}>DATABASE</label>
        <input style={inputStyle} value={form.db_name} onChange={e => set('db_name', e.target.value)} placeholder="master" />

        <label style={labelStyle}>AUTHENTICATION</label>
        <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
          {['sql', 'windows'].map(type => (
            <button key={type} type="button" onClick={() => set('auth_type', type)} style={{
              flex: 1, padding: '7px', borderRadius: 4, cursor: 'pointer',
              fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: 1,
              background: form.auth_type === type ? 'rgba(0,212,255,0.18)' : 'rgba(0,212,255,0.04)',
              border: `1px solid rgba(0,212,255,${form.auth_type === type ? '0.6' : '0.2'})`,
              color: form.auth_type === type ? 'var(--accent)' : 'var(--muted)',
            }}>
              {type === 'sql' ? 'SQL LOGIN' : 'WINDOWS AUTH'}
            </button>
          ))}
        </div>

        {form.auth_type === 'windows' && (
          <div style={{ marginTop: 8, padding: '8px 12px', background: 'rgba(0,230,118,0.06)', border: '1px solid rgba(0,230,118,0.2)', borderRadius: 4, fontSize: 11, color: 'var(--green)', fontFamily: 'var(--font-mono)' }}>
            Uses the Windows account running the backend service — no credentials needed.
          </div>
        )}

        {form.auth_type === 'sql' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <div>
              <label style={labelStyle}>SQL USER</label>
              <input style={inputStyle} value={form.db_user} onChange={e => set('db_user', e.target.value)} placeholder="dba_monitor" />
            </div>
            <div>
              <label style={labelStyle}>PASSWORD</label>
              <input style={inputStyle} type="password" value={form.db_password} onChange={e => set('db_password', e.target.value)} />
            </div>
          </div>
        )}

        <label style={labelStyle}>ENVIRONMENT</label>
        <select style={inputStyle} value={form.environment} onChange={e => set('environment', e.target.value)}>
          {ENV_ORDER.map(e => <option key={e} value={e}>{e.toUpperCase()}</option>)}
        </select>

        <label style={labelStyle}>TAGS (optional, comma-separated)</label>
        <input style={inputStyle} value={form.tags} onChange={e => set('tags', e.target.value)} placeholder="reporting, critical" />

        <label style={labelStyle}>NOTES (optional)</label>
        <input style={inputStyle} value={form.notes} onChange={e => set('notes', e.target.value)} placeholder="" />

        <div style={{ display: 'flex', gap: 10, marginTop: 20, justifyContent: 'flex-end' }}>
          <button onClick={onClose} style={{
            background: 'none', border: '1px solid var(--border)', color: 'var(--muted)',
            borderRadius: 4, padding: '7px 18px', fontFamily: 'var(--font-mono)', fontSize: 12,
          }}>CANCEL</button>
          <button onClick={handleSubmit} disabled={saving} style={{
            background: saving ? 'rgba(0,212,255,0.05)' : 'rgba(0,212,255,0.12)',
            border: '1px solid rgba(0,212,255,0.4)', color: 'var(--accent)',
            borderRadius: 4, padding: '7px 20px', fontFamily: 'var(--font-mono)', fontSize: 12,
            letterSpacing: 1, opacity: saving ? 0.6 : 1,
          }}>
            {saving ? 'CONNECTING...' : 'ADD & TEST'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Main picker ───────────────────────────────────────────────────────────────
export default function ServerPicker() {
  const { servers, selectedId, currentServer, loadingServers, connectError, selectServer, reloadServers } = useServer()
  const [open, setOpen]       = useState(false)
  const [showAdd, setShowAdd] = useState(false)

  // Group servers by environment
  const grouped = ENV_ORDER.reduce((acc, env) => {
    const items = servers.filter(s => s.environment === env)
    if (items.length) acc[env] = items
    return acc
  }, {})

  async function handleAdd(newSrv) {
    await reloadServers()
    selectServer(newSrv.server_id)
  }

  const statusDot = currentServer?.last_status === 'ONLINE'
    ? 'var(--green)' : currentServer?.last_status === 'OFFLINE'
    ? 'var(--red)' : 'var(--yellow)'

  return (
    <>
      {showAdd && <AddServerModal onClose={() => setShowAdd(false)} onAdded={handleAdd} />}

      <div style={{ position: 'relative' }}>

        {/* ── Trigger button ── */}
        <button
          onClick={() => setOpen(o => !o)}
          style={{
            display: 'flex', alignItems: 'center', gap: 8,
            background: open ? 'rgba(0,212,255,0.1)' : 'rgba(0,212,255,0.05)',
            border: '1px solid rgba(0,212,255,0.25)', borderRadius: 5,
            padding: '6px 12px', cursor: 'pointer',
            fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text)',
            minWidth: 200,
          }}
        >
          {/* status dot */}
          <span style={{ width: 7, height: 7, borderRadius: '50%', background: statusDot, flexShrink: 0 }} />

          <span style={{ flex: 1, textAlign: 'left', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {loadingServers ? 'LOADING...' : currentServer ? currentServer.display_name : 'SELECT SERVER'}
          </span>

          {currentServer && (
            <span style={{
              fontSize: 10, padding: '1px 6px', borderRadius: 3,
              background: envColor(currentServer.environment) + '22',
              color: envColor(currentServer.environment), fontWeight: 700, letterSpacing: 1,
            }}>
              {currentServer.environment.toUpperCase()}
            </span>
          )}

          <span style={{ color: 'var(--muted)', fontSize: 10 }}>{open ? '▲' : '▼'}</span>
        </button>

        {/* ── Dropdown panel ── */}
        {open && (
          <div
            style={{
              position: 'absolute', top: 'calc(100% + 6px)', left: 0,
              background: 'var(--panel)', border: '1px solid var(--border)',
              borderRadius: 6, minWidth: 280, zIndex: 500,
              boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
            }}
          >
            {/* grouped server list */}
            {Object.entries(grouped).map(([env, items]) => (
              <div key={env}>
                <div style={{
                  padding: '6px 14px 4px', fontSize: 10, letterSpacing: 2,
                  color: envColor(env), fontFamily: 'var(--font-mono)', fontWeight: 700,
                  borderBottom: '1px solid var(--border)',
                }}>
                  {env.toUpperCase()}
                </div>
                {items.map(srv => {
                  const active = srv.server_id === selectedId
                  return (
                    <button
                      key={srv.server_id}
                      onClick={() => { selectServer(srv.server_id); setOpen(false) }}
                      style={{
                        display: 'flex', alignItems: 'center', gap: 10, width: '100%',
                        background: active ? 'rgba(0,212,255,0.08)' : 'none',
                        border: 'none', borderBottom: '1px solid var(--border)',
                        padding: '9px 14px', cursor: 'pointer', textAlign: 'left',
                      }}
                    >
                      <span style={{
                        width: 6, height: 6, borderRadius: '50%', flexShrink: 0,
                        background: srv.last_status === 'ONLINE' ? 'var(--green)'
                          : srv.last_status === 'OFFLINE' ? 'var(--red)' : '#4a6080',
                      }} />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{
                          fontFamily: 'var(--font-mono)', fontSize: 12,
                          color: active ? 'var(--accent)' : 'var(--text)',
                          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                        }}>
                          {srv.display_name}
                        </div>
                        <div style={{ fontSize: 10, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>
                          {srv.host_name}{srv.port !== 1433 ? `:${srv.port}` : ''}
                        </div>
                      </div>
                      {active && <span style={{ color: 'var(--accent)', fontSize: 10 }}>●</span>}
                    </button>
                  )
                })}
              </div>
            ))}

            {/* divider + add new */}
            <div style={{ padding: '6px 8px', borderTop: '1px solid var(--border)' }}>
              <button
                onClick={() => { setShowAdd(true); setOpen(false) }}
                style={{
                  width: '100%', background: 'rgba(0,212,255,0.05)',
                  border: '1px dashed rgba(0,212,255,0.25)', borderRadius: 4,
                  color: 'var(--accent)', padding: '7px', fontFamily: 'var(--font-mono)',
                  fontSize: 11, letterSpacing: 1, cursor: 'pointer',
                }}
              >
                + ADD SERVER
              </button>
            </div>
          </div>
        )}

        {/* close dropdown on outside click */}
        {open && (
          <div
            onClick={() => setOpen(false)}
            style={{ position: 'fixed', inset: 0, zIndex: 499 }}
          />
        )}
      </div>

      {connectError && (
        <span style={{ fontSize: 11, color: 'var(--red)', fontFamily: 'var(--font-mono)', maxWidth: 260 }}>
          ✕ {connectError}
        </span>
      )}
    </>
  )
}
