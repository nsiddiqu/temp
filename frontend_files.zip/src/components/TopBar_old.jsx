export default function TopBar({ metrics, lastUpdated, onRefresh }) {
  return (
    <div style={{
      background: 'var(--panel)', borderBottom: '1px solid var(--border)',
      padding: '14px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      position: 'sticky', top: 0, zIndex: 100,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--green)', boxShadow: '0 0 8px var(--green)' }} />
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 16, fontWeight: 700, letterSpacing: 3, color: 'var(--accent)' }}>
          DBA AGENT
        </span>
        {metrics && (
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--muted)', borderLeft: '1px solid var(--border)', paddingLeft: 14 }}>
            {metrics.server_name} &nbsp;·&nbsp; {metrics.sql_version?.split('(')[0].trim()} &nbsp;·&nbsp; UP {metrics.uptime_hours}h
          </span>
        )}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        {lastUpdated && (
          <span style={{ fontSize: 11, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>
            REFRESHED {lastUpdated.toLocaleTimeString()}
          </span>
        )}
        <button
          onClick={onRefresh}
          style={{
            background: 'rgba(0,212,255,0.08)', border: '1px solid rgba(0,212,255,0.3)',
            color: 'var(--accent)', borderRadius: 5, padding: '6px 16px',
            fontFamily: 'var(--font-mono)', fontSize: 12, letterSpacing: 1,
            transition: 'background 0.2s',
          }}
          onMouseEnter={e => e.target.style.background = 'rgba(0,212,255,0.16)'}
          onMouseLeave={e => e.target.style.background = 'rgba(0,212,255,0.08)'}
        >
          ↻ REFRESH
        </button>
      </div>
    </div>
  )
}
