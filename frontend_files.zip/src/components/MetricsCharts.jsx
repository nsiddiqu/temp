import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { SectionHeader, ChartTooltip, Skeleton } from './UI'

function SingleChart({ title, dataKey, color, data }) {
  return (
    <div style={{ background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '18px 20px' }}>
      <SectionHeader title={title} color={color} />
      {data.length === 0 ? (
        <Skeleton height={180} />
      ) : (
        <ResponsiveContainer width="100%" height={180}>
          <AreaChart data={data}>
            <defs>
              <linearGradient id={`grad-${dataKey}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor={color} stopOpacity={0.3} />
                <stop offset="95%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="t" tick={{ fill: 'var(--muted)', fontSize: 10 }} interval="preserveStartEnd" />
            <YAxis domain={[0, 100]} tick={{ fill: 'var(--muted)', fontSize: 10 }} unit="%" />
            <Tooltip content={<ChartTooltip />} />
            <Area type="monotone" dataKey={dataKey} stroke={color} fill={`url(#grad-${dataKey})`} strokeWidth={2} dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      )}
    </div>
  )
}

export default function MetricsCharts({ history, cpuColor, memColor }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
      <SingleChart title="CPU Usage"    dataKey="CPU"    color={cpuColor} data={history} />
      <SingleChart title="Memory Usage" dataKey="Memory" color={memColor} data={history} />
    </div>
  )
}
