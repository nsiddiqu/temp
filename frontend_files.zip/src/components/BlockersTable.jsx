import { Panel } from './UI'

const fmtMs = ms => ms >= 1000 ? `${(ms / 1000).toFixed(1)}s` : `${ms}ms`
const trunc = (s, n = 40) => s?.length > n ? s.slice(0, n) + '…' : (s ?? '—')

const TH = ({ children }) => (
  <th style={{ padding: '10px 14px', textAlign: 'left', color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: 1, fontWeight: 600, whiteSpace: 'nowrap', background: '#1a0a0a', borderBottom: '1px solid var(--border)' }}>
    {children}
  </th>
)

export default function BlockersTable({ blockers }) {
  if (!blockers?.length) {
    return (
      <Panel>
        <div style={{ padding: 40, textAlign: 'center' }}>
          <div style={{ fontSize: 36, marginBottom: 10 }}>✓</div>
          <div style={{ color: 'var(--green)', fontFamily: 'var(--font-mono)', fontSize: 14, letterSpacing: 2 }}>NO BLOCKING DETECTED</div>
          <div style={{ color: 'var(--muted)', fontSize: 12, marginTop: 6 }}>All sessions running freely</div>
        </div>
      </Panel>
    )
  }

  return (
    <div>
      <div style={{ background: 'rgba(255,68,68,0.07)', border: '1px solid rgba(255,68,68,0.3)', borderBottom: 'none', borderRadius: '8px 8px 0 0', padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--red)', boxShadow: '0 0 6px var(--red)', animation: 'pulse 1.5s infinite' }} />
        <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }`}</style>
        <span style={{ color: 'var(--red)', fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: 2 }}>
          ACTIVE BLOCKING CHAINS — {blockers.length} CHAIN{blockers.length !== 1 ? 'S' : ''} DETECTED
        </span>
      </div>
      <Panel style={{ borderRadius: '0 0 8px 8px', overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
          <thead>
            <tr>
              {['Blocker SPID', 'Blocker Login', 'Blocked SPID', 'Blocked Login', 'Wait Time', 'Wait Type', 'Blocked Resource', 'Blocker SQL', 'Blocked SQL'].map(h => <TH key={h}>{h}</TH>)}
            </tr>
          </thead>
          <tbody>
            {blockers.map((b, i) => (
              <tr key={i}
                  style={{ borderBottom: '1px solid var(--border)', background: i % 2 === 0 ? 'transparent' : '#120a0a' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,68,68,0.05)'}
                  onMouseLeave={e => e.currentTarget.style.background = i % 2 === 0 ? 'transparent' : '#120a0a'}>
                <td style={{ padding: '10px 14px', color: 'var(--red)', fontFamily: 'var(--font-mono)', fontWeight: 700 }}>{b.blocker_spid}</td>
                <td style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)' }}>
                  {b.blocker_login}<br />
                  <span style={{ color: 'var(--muted)', fontSize: 10 }}>{b.blocker_host}</span>
                </td>
                <td style={{ padding: '10px 14px', color: 'var(--yellow)', fontFamily: 'var(--font-mono)', fontWeight: 700 }}>{b.blocked_spid}</td>
                <td style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)' }}>
                  {b.blocked_login}<br />
                  <span style={{ color: 'var(--muted)', fontSize: 10 }}>{b.blocked_host}</span>
                </td>
                <td style={{ padding: '10px 14px', color: 'var(--red)', fontFamily: 'var(--font-mono)', fontWeight: 700 }}>{fmtMs(b.wait_time_ms)}</td>
                <td style={{ padding: '10px 14px', color: 'var(--yellow)', fontFamily: 'var(--font-mono)', fontSize: 11 }}>{b.wait_type ?? '—'}</td>
                <td style={{ padding: '10px 14px', color: 'var(--yellow)', fontFamily: 'var(--font-mono)', fontSize: 11, maxWidth: 160 }} title={b.blocked_resource}>{trunc(b.blocked_resource, 30)}</td>
                <td style={{ padding: '10px 14px', color: 'var(--muted)', fontFamily: 'var(--font-mono)', maxWidth: 200 }} title={b.blocker_command}>{trunc(b.blocker_command)}</td>
                <td style={{ padding: '10px 14px', color: 'var(--muted)', fontFamily: 'var(--font-mono)', maxWidth: 200 }} title={b.blocked_command}>{trunc(b.blocked_command)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </div>
  )
}
