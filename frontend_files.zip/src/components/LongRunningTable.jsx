import { StatusBadge, Panel } from './UI'

const fmtNum = n => n?.toLocaleString() ?? '—'
const trunc  = (s, n = 60) => s?.length > n ? s.slice(0, n) + '…' : (s ?? '—')
const fmtDur = s => s >= 3600 ? `${(s/3600).toFixed(1)}h` : s >= 60 ? `${(s/60).toFixed(1)}m` : `${s}s`
const durColor = s => s > 300 ? 'var(--red)' : s > 60 ? 'var(--yellow)' : 'var(--text)'

const TH = ({ children }) => (
  <th style={{ padding: '10px 14px', textAlign: 'left', color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: 1, fontWeight: 600, whiteSpace: 'nowrap', background: '#0a1628', borderBottom: '1px solid var(--border)' }}>
    {children}
  </th>
)

export default function LongRunningTable({ queries }) {
  if (!queries?.length) {
    return (
      <Panel>
        <div style={{ padding: 32, textAlign: 'center', color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: 13 }}>
          No long-running queries above threshold.
        </div>
      </Panel>
    )
  }

  return (
    <Panel style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
        <thead>
          <tr>
            {['SPID', 'Login', 'Host', 'Database', 'Duration', 'CPU (ms)', 'Reads', 'Status', 'Wait Type', 'SQL Text'].map(h => <TH key={h}>{h}</TH>)}
          </tr>
        </thead>
        <tbody>
          {queries.map((q, i) => (
            <tr key={q.session_id}
                style={{ borderBottom: '1px solid var(--border)', background: i % 2 === 0 ? 'transparent' : 'var(--panel2)' }}
                onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,107,53,0.05)'}
                onMouseLeave={e => e.currentTarget.style.background = i % 2 === 0 ? 'transparent' : 'var(--panel2)'}>
              <td style={{ padding: '10px 14px', color: 'var(--accent2)', fontFamily: 'var(--font-mono)', fontWeight: 700 }}>{q.session_id}</td>
              <td style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)' }}>{q.login_name}</td>
              <td style={{ padding: '10px 14px', color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>{q.host_name ?? '—'}</td>
              <td style={{ padding: '10px 14px' }}>{q.database_name ?? '—'}</td>
              <td style={{ padding: '10px 14px', color: durColor(q.duration_seconds), fontFamily: 'var(--font-mono)', fontWeight: 700 }}>{fmtDur(q.duration_seconds)}</td>
              <td style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)' }}>{fmtNum(q.cpu_time_ms)}</td>
              <td style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)' }}>{fmtNum(q.logical_reads)}</td>
              <td style={{ padding: '10px 14px' }}><StatusBadge status={q.status} /></td>
              <td style={{ padding: '10px 14px', color: q.wait_type ? 'var(--yellow)' : 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: 11 }}>{q.wait_type ?? '—'}</td>
              <td style={{ padding: '10px 14px', color: 'var(--muted)', fontFamily: 'var(--font-mono)', maxWidth: 300 }} title={q.command_text}>{trunc(q.command_text)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Panel>
  )
}
