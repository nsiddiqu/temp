import { KpiCard } from './UI'

export default function KpiRow({ metrics, blockerCount, suspendedCount }) {
  const cpu = metrics?.cpu_usage ?? null
  const mem = metrics?.memory_usage_pct ?? null

  const cpuColor = cpu === null ? 'var(--accent)' : cpu > 80 ? 'var(--red)' : cpu > 60 ? 'var(--yellow)' : 'var(--green)'
  const memColor = mem === null ? 'var(--accent)' : mem > 85 ? 'var(--red)' : mem > 70 ? 'var(--yellow)' : 'var(--accent)'

  return (
    <div style={{ display: 'flex', gap: 14, marginBottom: 24, flexWrap: 'wrap' }}>
      <KpiCard label="CPU Usage"       value={cpu}                              unit="%"   color={cpuColor} sub="Server utilisation" />
      <KpiCard label="Memory"          value={mem}                              unit="%"   color={memColor} sub={metrics ? `${metrics.memory_used_mb} / ${metrics.memory_total_mb} MB` : '—'} />
      <KpiCard label="Active Sessions" value={metrics?.active_connections}      unit=""    color="var(--accent)"  sub={`${suspendedCount} suspended`} />
      <KpiCard label="Queries / sec"   value={metrics?.queries_per_sec}         unit="qps" color="var(--accent2)" sub="Batch requests" />
      <KpiCard label="Page Life Exp."  value={metrics?.page_life_expectancy}    unit="s"   color={metrics?.page_life_expectancy < 300 ? 'var(--red)' : 'var(--green)'} sub="Buffer pool health" />
      <KpiCard label="Lead Blockers"   value={blockerCount}                     unit=""    color={blockerCount > 0 ? 'var(--red)' : 'var(--green)'} sub={blockerCount > 0 ? 'Chains detected!' : 'No blocking'} />
    </div>
  )
}
