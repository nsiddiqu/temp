/**
 * QueryPage.jsx — Phase 1 update
 * Accepts serverId prop so custom queries run against the selected server.
 * UI is unchanged from the original.
 */
import { useState } from 'react'
import { runCustomQuery } from '../services/api'

const SAMPLE_QUERIES = [
  { label: 'Top CPU sessions',      sql: "SELECT TOP 10 session_id, login_name, cpu_time, status FROM sys.dm_exec_sessions WHERE is_user_process = 1 ORDER BY cpu_time DESC" },
  { label: 'Database sizes',        sql: "SELECT name, CAST(size * 8.0 / 1024 AS DECIMAL(10,1)) AS size_mb FROM sys.master_files ORDER BY size DESC" },
  { label: 'Missing indexes',       sql: "SELECT TOP 10 d.object_id, OBJECT_NAME(d.object_id) AS table_name, d.equality_columns, d.inequality_columns, s.avg_user_impact FROM sys.dm_db_missing_index_details d JOIN sys.dm_db_missing_index_groups g ON d.index_handle = g.index_handle JOIN sys.dm_db_missing_index_group_stats s ON g.index_group_handle = s.group_handle ORDER BY s.avg_user_impact DESC" },
  { label: 'Index fragmentation',   sql: "SELECT OBJECT_NAME(ips.object_id) AS table_name, i.name AS index_name, CAST(ips.avg_fragmentation_in_percent AS DECIMAL(5,1)) AS frag_pct, ips.page_count FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, 'LIMITED') ips JOIN sys.indexes i ON ips.object_id = i.object_id AND ips.index_id = i.index_id WHERE ips.avg_fragmentation_in_percent > 10 AND ips.page_count > 100 ORDER BY ips.avg_fragmentation_in_percent DESC" },
]

export default function QueryPage({ serverId = 0 }) {
  const [sql, setSql]       = useState('')
  const [result, setResult] = useState(null)
  const [error, setError]   = useState(null)
  const [running, setRunning] = useState(false)

  async function execute() {
    if (!sql.trim()) return
    setRunning(true)
    setError(null)
    setResult(null)
    try {
      const res = await runCustomQuery(sql, 500, serverId)
      setResult(res)
    } catch (e) {
      setError(e.message)
    } finally {
      setRunning(false)
    }
  }

  function handleKeyDown(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') execute()
  }

  const mono = { fontFamily: 'var(--font-mono)' }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

      {/* Sample query buttons */}
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {SAMPLE_QUERIES.map(q => (
          <button key={q.label} onClick={() => setSql(q.sql)} style={{
            ...mono, fontSize: 11, background: 'rgba(0,212,255,0.06)',
            border: '1px solid rgba(0,212,255,0.2)', color: 'var(--accent)',
            borderRadius: 4, padding: '4px 12px', letterSpacing: 0.5,
          }}>
            {q.label}
          </button>
        ))}
      </div>

      {/* Editor */}
      <textarea
        value={sql}
        onChange={e => setSql(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="SELECT * FROM sys.databases  -- Ctrl+Enter to run"
        rows={6}
        style={{
          ...mono, fontSize: 13, width: '100%', resize: 'vertical',
          background: 'var(--panel2)', border: '1px solid var(--border)',
          color: 'var(--text)', borderRadius: 6, padding: 14,
        }}
      />

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={execute} disabled={running || !sql.trim()} style={{
          ...mono, fontSize: 12, letterSpacing: 1,
          background: 'rgba(0,212,255,0.12)', border: '1px solid rgba(0,212,255,0.4)',
          color: 'var(--accent)', borderRadius: 5, padding: '7px 22px',
          opacity: running || !sql.trim() ? 0.5 : 1,
        }}>
          {running ? 'RUNNING...' : '▶ EXECUTE  (Ctrl+Enter)'}
        </button>
        <span style={{ ...mono, fontSize: 11, color: 'var(--muted)' }}>
          Server ID: {serverId} &nbsp;·&nbsp; SELECT only · max 500 rows
        </span>
      </div>

      {error && (
        <div style={{
          background: 'rgba(255,68,68,0.08)', border: '1px solid #ff444430',
          color: '#ff6666', borderRadius: 5, padding: '10px 14px', ...mono, fontSize: 12,
        }}>
          {error}
        </div>
      )}

      {result && (
        <div>
          <div style={{ ...mono, fontSize: 11, color: 'var(--muted)', marginBottom: 8 }}>
            {result.row_count} rows · {result.execution_ms}ms
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', ...mono, fontSize: 12 }}>
              <thead>
                <tr>
                  {result.columns.map(col => (
                    <th key={col} style={{
                      textAlign: 'left', padding: '6px 12px',
                      background: 'var(--panel2)', color: 'var(--accent)',
                      borderBottom: '1px solid var(--border)', whiteSpace: 'nowrap',
                    }}>
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {result.rows.map((row, ri) => (
                  <tr key={ri} style={{ background: ri % 2 ? 'var(--panel2)' : 'transparent' }}>
                    {row.map((cell, ci) => (
                      <td key={ci} style={{
                        padding: '5px 12px', borderBottom: '1px solid var(--border)',
                        color: 'var(--text)', maxWidth: 300,
                        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                      }}>
                        {cell === null ? <span style={{ color: 'var(--muted)' }}>NULL</span> : String(cell)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
