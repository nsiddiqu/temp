import { StatusBadge, Panel } from './UI'

const fmtMs  = ms => ms >= 1000 ? `${(ms / 1000).toFixed(1)}s` : `${ms}ms`
const fmtNum = n  => n?.toLocaleString() ?? '—'
const trunc  = (s, n = 55) => s?.length > n ? s.slice(0, n) + '…' : (s ?? '—')

const TH = ({ children }) => (
  <th style={{ padding: '10px 14px', textAlign: 'left', color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: 1, fontWeight: 600, whiteSpace: 'nowrap', background: '#0a1628', borderBottom: '1px solid var(--border)' }}>
    {children}
  </th>
)

export default function SessionsTable({ sessions }) {
  if (!sessions?.length) {
    return (
      <Panel>
        <div style={{ padding: 32, textAlign: 'center', color: 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: 13 }}>
          No active sessions found.
        </div>
      </Panel>
    )
  }

  return (
    <Panel style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
        <thead>
          <tr>
            {['SPID', 'Login', 'Host', 'Database', 'Status', 'Wait Type', 'Wait Time', 'CPU (ms)', 'Reads', 'Command'].map(h => <TH key={h}>{h}</TH>)}
          </tr>
        </thead>
        <tbody>
          {sessions.map((s, i) => (
            <tr key={s.session_id}
                style={{ borderBottom: '1px solid var(--border)', background: i % 2 === 0 ? 'transparent' : 'var(--panel2)' }}
                onMouseEnter={e => e.currentTarget.style.background = 'rgba(0,212,255,0.05)'}
                onMouseLeave={e => e.currentTarget.style.background = i % 2 === 0 ? 'transparent' : 'var(--panel2)'}>
              <td style={{ padding: '10px 14px', color: 'var(--accent)', fontFamily: 'var(--font-mono)', fontWeight: 700 }}>{s.session_id}</td>
              <td style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)' }}>{s.login_name}</td>
              <td style={{ padding: '10px 14px', color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>{s.host_name ?? '—'}</td>
              <td style={{ padding: '10px 14px' }}>{s.database_name ?? '—'}</td>
              <td style={{ padding: '10px 14px' }}><StatusBadge status={s.status} /></td>
              <td style={{ padding: '10px 14px', color: s.wait_type ? 'var(--yellow)' : 'var(--muted)', fontFamily: 'var(--font-mono)', fontSize: 11 }}>{s.wait_type ?? '—'}</td>
              <td style={{ padding: '10px 14px', color: s.wait_time_ms > 5000 ? 'var(--red)' : s.wait_time_ms > 1000 ? 'var(--yellow)' : 'var(--text)', fontFamily: 'var(--font-mono)' }}>
                {s.wait_time_ms ? fmtMs(s.wait_time_ms) : '—'}
              </td>
              <td style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)' }}>{fmtNum(s.cpu_time_ms)}</td>
              <td style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)' }}>{fmtNum(s.logical_reads)}</td>
              <td style={{ padding: '10px 14px', color: 'var(--muted)', fontFamily: 'var(--font-mono)', maxWidth: 280 }} title={s.command}>{trunc(s.command)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Panel>
  )
}
