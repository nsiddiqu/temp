import { useState, useRef, useEffect } from 'react'
import axios from 'axios'

// ── helpers ───────────────────────────────────────────────────────────────────
const api = axios.create({ baseURL: '/api', timeout: 40000 })
const fmtNum = n => (typeof n === 'number' ? n.toLocaleString() : n)

const SUGGESTIONS = [
  'Top 3 CPU consuming queries right now',
  'Show me all blocking sessions',
  'Which queries have the most logical reads today?',
  'List top 5 missing indexes by impact',
  'What are the current wait statistics?',
  'Show me long running queries over 30 seconds',
  'Top 10 queries by total execution time',
  'Which logins have the most active sessions?',
]

// ── Result table rendered inside a chat bubble ────────────────────────────────
function ResultTable({ columns, rows }) {
  if (!columns?.length) return null
  return (
    <div style={{ overflowX: 'auto', marginTop: 10, borderRadius: 6, border: '1px solid rgba(0,212,255,0.15)' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
        <thead>
          <tr style={{ background: 'rgba(0,212,255,0.08)' }}>
            {columns.map(c => (
              <th key={c} style={{ padding: '7px 12px', textAlign: 'left', color: '#00d4ff', fontFamily: 'JetBrains Mono, monospace', fontSize: 10, letterSpacing: 1, whiteSpace: 'nowrap', borderBottom: '1px solid rgba(0,212,255,0.15)' }}>
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} style={{ background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.02)', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
              {row.map((cell, j) => (
                <td key={j} style={{ padding: '7px 12px', fontFamily: 'JetBrains Mono, monospace', color: cell === null ? '#4a6080' : '#c8d8e8', whiteSpace: 'nowrap', maxWidth: 260, overflow: 'hidden', textOverflow: 'ellipsis' }} title={cell === null ? 'NULL' : String(cell)}>
                  {cell === null ? <span style={{ color: '#4a6080' }}>NULL</span> : fmtNum(cell)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// ── SQL code block collapsed by default ───────────────────────────────────────
function SqlBlock({ sql }) {
  const [open, setOpen] = useState(false)
  return (
    <div style={{ marginTop: 8 }}>
      <button onClick={() => setOpen(o => !o)} style={{ background: 'none', border: '1px solid rgba(0,212,255,0.2)', color: '#4a6080', borderRadius: 4, padding: '2px 10px', fontSize: 10, fontFamily: 'JetBrains Mono, monospace', cursor: 'pointer', letterSpacing: 1 }}>
        {open ? '▾ HIDE SQL' : '▸ VIEW SQL'}
      </button>
      {open && (
        <pre style={{ marginTop: 6, background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(0,212,255,0.1)', borderRadius: 5, padding: '10px 14px', fontSize: 11, fontFamily: 'JetBrains Mono, monospace', color: '#7ecfff', overflowX: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
          {sql}
        </pre>
      )}
    </div>
  )
}

// ── Individual chat message bubble ────────────────────────────────────────────
function Message({ msg }) {
  try {
    if (msg.role === 'user') {
      return (
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
          <div style={{ background: 'rgba(0,212,255,0.12)', border: '1px solid rgba(0,212,255,0.25)', borderRadius: '12px 12px 2px 12px', padding: '10px 16px', maxWidth: '75%', color: '#c8d8e8', fontSize: 13 }}>
            {msg.text}
          </div>
        </div>
      )
    }
    if (msg.role === 'error') {
      return (
        <div style={{ display: 'flex', justifyContent: 'flex-start', marginBottom: 16 }}>
          <div style={{ background: 'rgba(255,68,68,0.08)', border: '1px solid rgba(255,68,68,0.25)', borderRadius: '12px 12px 12px 2px', padding: '10px 16px', maxWidth: '85%', color: '#ff7070', fontSize: 12, fontFamily: 'JetBrains Mono, monospace' }}>
            ⚠ {msg.text}
          </div>
        </div>
      )
    }
    // assistant message
    return (
      <div style={{ display: 'flex', justifyContent: 'flex-start', marginBottom: 16 }}>
        <div style={{ maxWidth: '92%' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <div style={{ width: 22, height: 22, borderRadius: '50%', background: 'rgba(255,102,0,0.15)', border: '1px solid rgba(255,102,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, color: '#FF6600' }}>⬡</div>
            <span style={{ color: '#4a6080', fontSize: 10, fontFamily: 'JetBrains Mono, monospace', letterSpacing: 1 }}>SQLTeam CHAT</span>
            {msg.execution_ms != null && <span style={{ color: '#2a4060', fontSize: 10, fontFamily: 'JetBrains Mono, monospace' }}>{msg.execution_ms}ms</span>}
          </div>
          <div style={{ background: 'rgba(15,21,32,0.9)', border: '1px solid rgba(28,42,58,0.8)', borderRadius: '2px 12px 12px 12px', padding: '12px 16px' }}>
            {msg.title && (
              <div style={{ color: '#FF6600', fontFamily: 'JetBrains Mono, monospace', fontSize: 11, letterSpacing: 2, textTransform: 'uppercase', marginBottom: 8, borderBottom: '1px solid rgba(255,102,0,0.15)', paddingBottom: 8 }}>
                {msg.title}
              </div>
            )}
            <p style={{ color: '#a0b8cc', fontSize: 13, lineHeight: 1.6, marginBottom: msg.columns?.length ? 4 : 0 }}>
              {msg.text}
            </p>
            {msg.row_count != null && (
              <div style={{ color: '#4a6080', fontSize: 10, fontFamily: 'JetBrains Mono, monospace', marginTop: 4, marginBottom: 2 }}>
                {msg.row_count} ROW{msg.row_count !== 1 ? 'S' : ''} RETURNED
              </div>
            )}
            {Array.isArray(msg.columns) && msg.columns.length > 0 && (
              <ResultTable columns={msg.columns} rows={msg.rows || []} />
            )}
            {msg.sql && <SqlBlock sql={msg.sql} />}
          </div>
        </div>
      </div>
    )
  } catch (e) {
    return (
      <div style={{ color: '#ff7070', fontSize: 12, padding: '8px 16px', fontFamily: 'JetBrains Mono, monospace' }}>
        ⚠ Error rendering message: {e.message}
      </div>
    )
  }
}

// ── Typing indicator ──────────────────────────────────────────────────────────
function Typing() {
  return (
    <div style={{ display: 'flex', justifyContent: 'flex-start', marginBottom: 16 }}>
      <div style={{ background: 'rgba(15,21,32,0.9)', border: '1px solid rgba(28,42,58,0.8)', borderRadius: '2px 12px 12px 12px', padding: '14px 18px', display: 'flex', gap: 5, alignItems: 'center' }}>
        {[0, 1, 2].map(i => (
          <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: '#00d4ff', opacity: 0.7, animation: `bounce 1.2s ${i * 0.2}s infinite` }} />
        ))}
        <style>{`@keyframes bounce { 0%,80%,100%{transform:translateY(0)} 40%{transform:translateY(-6px)} }`}</style>
      </div>
    </div>
  )
}

// ── Main chat panel ───────────────────────────────────────────────────────────
export default function DbaChat() {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      text: 'Hello! I\'m your DBA Agent. Ask me anything about your SQL Server — I\'ll query the live data and show you the results.',
      title: null, columns: null, rows: null, sql: null,
    }
  ])
  const [input, setInput]   = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef             = useRef(null)
  const inputRef              = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, loading])

  const send = async (question) => {
    const q = (question ?? input).trim()
    if (!q || loading) return
    setInput('')
    setMessages(m => [...m, { role: 'user', text: q }])
    setLoading(true)

    try {
      const { data } = await api.post('/chat/ask', { question: q, max_rows: 50 })
      setMessages(m => [...m, {
        role:         'assistant',
        text:         data.explanation,
        title:        data.title,
        sql:          data.sql,
        columns:      data.columns,
        rows:         data.rows,
        row_count:    data.row_count,
        execution_ms: data.execution_ms,
      }])
    } catch (err) {
  // Safely extract error message regardless of format
  let errorText = 'Unknown error occurred.'
  if (err?.message) {
    errorText = err.message
  }
  // FastAPI 422 errors come back as arrays of objects — flatten to string
  if (typeof errorText === 'object') {
    errorText = JSON.stringify(errorText)
  }
  setMessages(m => [...m, { role: 'error', text: String(errorText) }])
    } finally {
      setLoading(false)
      setTimeout(() => inputRef.current?.focus(), 50)
    }
  }

  const handleKey = e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--bg)' }}>

      {/* Header */}
      <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', background: 'var(--panel)', display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0 }}>
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#00d4ff', boxShadow: '0 0 8px #00d4ff' }} />
        <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 13, fontWeight: 700, letterSpacing: 3, color: '#FF8C00' }}>Optum CHAT</span>
        <span style={{ color: '#4a6080', fontSize: 11, fontFamily: 'JetBrains Mono, monospace' }}>· AI-powered · Live SQL Server data</span>
      </div>

      {/* Suggestion chips — shown when only welcome message */}
      {messages.length === 1 && (
        <div style={{ padding: '12px 16px', display: 'flex', flexWrap: 'wrap', gap: 6, borderBottom: '1px solid var(--border)', flexShrink: 0 }}>
          {SUGGESTIONS.map(s => (
            <button key={s} onClick={() => send(s)} style={{ background: 'rgba(0,212,255,0.06)', border: '1px solid rgba(0,212,255,0.2)', color: '#7ab8cc', borderRadius: 20, padding: '4px 12px', fontSize: 11, fontFamily: 'JetBrains Mono, monospace', cursor: 'pointer', transition: 'all 0.15s', whiteSpace: 'nowrap' }}
              onMouseEnter={e => { e.target.style.background = 'rgba(0,212,255,0.14)'; e.target.style.color = '#00d4ff' }}
              onMouseLeave={e => { e.target.style.background = 'rgba(0,212,255,0.06)'; e.target.style.color = '#7ab8cc' }}>
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Messages scroll area */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '20px 16px', minHeight: 0 }}>
        {messages.map((msg, i) => <Message key={i} msg={msg} />)}
        {loading && <Typing />}
        <div ref={bottomRef} />
      </div>

      {/* Input bar */}
      <div style={{ padding: '12px 16px', borderTop: '1px solid var(--border)', background: 'var(--panel)', flexShrink: 0 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end', background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 8, padding: '8px 12px', transition: 'border-color 0.2s' }}
          onFocusCapture={e => e.currentTarget.style.borderColor = 'rgba(0,212,255,0.5)'}
          onBlurCapture={e => e.currentTarget.style.borderColor = 'rgba(0,212,255,0.2)'}>
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Ask about your SQL Server… e.g. top 3 CPU consuming queries"
            rows={1}
            style={{ flex: 1, background: 'none', border: 'none', outline: 'none', color: '#c8d8e8', fontFamily: 'JetBrains Mono, monospace', fontSize: 12, resize: 'none', lineHeight: 1.5, maxHeight: 80, overflowY: 'auto' }}
            onInput={e => { e.target.style.height = 'auto'; e.target.style.height = Math.min(e.target.scrollHeight, 80) + 'px' }}
          />
          <button onClick={() => send()} disabled={!input.trim() || loading}
            style={{ background: input.trim() && !loading ? 'rgba(0,212,255,0.2)' : 'rgba(0,212,255,0.04)', border: '1px solid rgba(0,212,255,0.3)', borderRadius: 6, color: '#00d4ff', padding: '6px 14px', fontFamily: 'JetBrains Mono, monospace', fontSize: 11, letterSpacing: 1, cursor: input.trim() && !loading ? 'pointer' : 'not-allowed', opacity: loading ? 0.5 : 1, whiteSpace: 'nowrap', transition: 'all 0.15s', flexShrink: 0 }}>
            {loading ? '…' : 'ASK ↵'}
          </button>
        </div>
        <div style={{ color: '#2a4060', fontSize: 10, fontFamily: 'JetBrains Mono, monospace', marginTop: 5, paddingLeft: 2 }}>
          ENTER to send · SHIFT+ENTER for new line · Results from live SQL Server
        </div>
      </div>
    </div>
  )
}
