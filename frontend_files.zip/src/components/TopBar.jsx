import ServerPicker from './ServerPicker'

export default function TopBar({ metrics, lastUpdated, onRefresh, children }) {
  return (
    <div style={{
      background: 'var(--panel)', borderBottom: '1px solid var(--border)',
      padding: '10px 20px', display: 'flex', alignItems: 'center',
      justifyContent: 'space-between', flexShrink: 0, zIndex: 100, gap: 16,
    }}>

      {/* ── Left: logo + server info ── */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, minWidth: 0 }}>
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--green)', boxShadow: '0 0 8px var(--green)', flexShrink: 0 }} />
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 15, fontWeight: 700, letterSpacing: 3, color: 'var(--accent)', whiteSpace: 'nowrap' }}>
          SQLDBA AGENT
        </span>

        {/* Server version / uptime pill — shown when a server is connected */}
        {metrics && (
          <span style={{
            fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted)',
            borderLeft: '1px solid var(--border)', paddingLeft: 14, whiteSpace: 'nowrap',
          }}>
            {metrics.sql_version?.split('(')[0].trim()} &nbsp;·&nbsp; UP {metrics.uptime_hours}h
          </span>
        )}
      </div>

      {/* ── Centre: server picker (takes available space) ── */}
      <div style={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
        <ServerPicker />
      </div>

      {/* ── Right: refresh + extra buttons (chat toggle etc.) ── */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
        {lastUpdated && (
          <span style={{ fontSize: 11, color: 'var(--muted)', fontFamily: 'var(--font-mono)', whiteSpace: 'nowrap' }}>
            {lastUpdated.toLocaleTimeString()}
          </span>
        )}
        <button
          onClick={onRefresh}
          style={{
            background: 'rgba(0,212,255,0.08)', border: '1px solid rgba(0,212,255,0.3)',
            color: 'var(--accent)', borderRadius: 5, padding: '6px 14px',
            fontFamily: 'var(--font-mono)', fontSize: 12, letterSpacing: 1,
          }}
          onMouseEnter={e => e.target.style.background = 'rgba(0,212,255,0.16)'}
          onMouseLeave={e => e.target.style.background = 'rgba(0,212,255,0.08)'}
        >
          ↻ REFRESH
        </button>
        {children}
      </div>
    </div>
  )
}
