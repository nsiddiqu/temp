// ── KPI Card ──────────────────────────────────────────────────────────────────
export function KpiCard({ label, value, unit = '', color, sub }) {
  return (
    <div style={{
      background: 'var(--panel)', border: '1px solid var(--border)',
      borderRadius: 'var(--radius)', padding: '18px 22px', flex: 1, minWidth: 160,
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, ${color}, transparent)` }} />
      <div style={{ color: 'var(--muted)', fontSize: 11, letterSpacing: 2, textTransform: 'uppercase', marginBottom: 8, fontFamily: 'var(--font-mono)' }}>{label}</div>
      <div style={{ color, fontSize: 30, fontWeight: 700, fontFamily: 'var(--font-mono)', lineHeight: 1 }}>
        {value ?? '—'}<span style={{ fontSize: 13, marginLeft: 4, color: 'var(--muted)' }}>{unit}</span>
      </div>
      {sub && <div style={{ color: 'var(--muted)', fontSize: 12, marginTop: 6 }}>{sub}</div>}
    </div>
  )
}

// ── Section header ────────────────────────────────────────────────────────────
export function SectionHeader({ title, count, color = 'var(--accent)' }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
      <div style={{ width: 3, height: 18, background: color, borderRadius: 2 }} />
      <span style={{ color: 'var(--text)', fontFamily: 'var(--font-mono)', fontSize: 13, letterSpacing: 2, textTransform: 'uppercase' }}>{title}</span>
      {count != null && (
        <span style={{ background: color + '22', color, border: `1px solid ${color}44`, borderRadius: 12, padding: '1px 10px', fontSize: 11 }}>{count}</span>
      )}
    </div>
  )
}

// ── Status badge ──────────────────────────────────────────────────────────────
export function StatusBadge({ status }) {
  const map = {
    running:   ['var(--green)',  'RUNNING'],
    suspended: ['var(--yellow)', 'SUSPENDED'],
    sleeping:  ['var(--muted)',  'SLEEPING'],
    runnable:  ['var(--accent)', 'RUNNABLE'],
  }
  const [color, label] = map[status?.toLowerCase()] || ['var(--muted)', (status || '?').toUpperCase()]
  return (
    <span style={{ background: color + '22', color, border: `1px solid ${color}44`, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontFamily: 'var(--font-mono)', letterSpacing: 1 }}>
      {label}
    </span>
  )
}

// ── Chart tooltip ─────────────────────────────────────────────────────────────
export function ChartTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  return (
    <div style={{ background: '#0a1628', border: '1px solid var(--border)', borderRadius: 6, padding: '10px 14px' }}>
      <div style={{ color: 'var(--muted)', fontSize: 11, marginBottom: 6 }}>{label}</div>
      {payload.map(p => (
        <div key={p.name} style={{ color: p.color, fontSize: 13, fontFamily: 'var(--font-mono)' }}>
          {p.name}: <strong>{p.value}%</strong>
        </div>
      ))}
    </div>
  )
}

// ── Error banner ──────────────────────────────────────────────────────────────
export function ErrorBanner({ message }) {
  return (
    <div style={{ background: 'var(--red)11', border: '1px solid var(--red)44', borderRadius: 'var(--radius)', padding: '12px 18px', color: 'var(--red)', fontFamily: 'var(--font-mono)', fontSize: 12, marginBottom: 16 }}>
      ⚠ {message}
    </div>
  )
}

// ── Loading skeleton ──────────────────────────────────────────────────────────
export function Skeleton({ height = 200 }) {
  return (
    <div style={{
      background: 'linear-gradient(90deg, var(--panel) 25%, var(--panel2) 50%, var(--panel) 75%)',
      backgroundSize: '200% 100%',
      animation: 'shimmer 1.5s infinite',
      borderRadius: 'var(--radius)',
      height,
    }}>
      <style>{`@keyframes shimmer { 0%{background-position:200% 0} 100%{background-position:-200% 0} }`}</style>
    </div>
  )
}

// ── Panel wrapper ─────────────────────────────────────────────────────────────
export function Panel({ children, style = {} }) {
  return (
    <div style={{ background: 'var(--panel)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', overflow: 'hidden', ...style }}>
      {children}
    </div>
  )
}
