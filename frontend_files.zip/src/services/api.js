import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 15000,
})

api.interceptors.response.use(
  (res) => res.data,
  (err) => {
    const msg = err.response?.data?.detail || err.message || 'Unknown error'
    return Promise.reject(new Error(msg))
  }
)

// ── Server registry ───────────────────────────────────────────────────────────
export const fetchServers      = ()           => api.get('/servers/')
export const addServer         = (payload)    => api.post('/servers/', payload)
export const removeServer      = (id)         => api.delete(`/servers/${id}`)
export const connectServer     = (id)         => api.post(`/servers/${id}/connect`)
export const testServer        = (id)         => api.get(`/servers/${id}/test`)

// ── Health ────────────────────────────────────────────────────────────────────
export const fetchHealthMetrics = (serverId = 0) =>
  api.get('/health/metrics', { params: { server_id: serverId } })

export const fetchPing = (serverId = 0) =>
  api.get('/health/ping', { params: { server_id: serverId } })

// ── Sessions ──────────────────────────────────────────────────────────────────
export const fetchSessions = (serverId = 0) =>
  api.get('/sessions/', { params: { server_id: serverId } })

export const fetchBlockers = (serverId = 0) =>
  api.get('/sessions/blockers', { params: { server_id: serverId } })

export const fetchLongRunning = (threshold = 30, serverId = 0) =>
  api.get('/sessions/long-running', { params: { threshold, server_id: serverId } })

// ── Custom query ──────────────────────────────────────────────────────────────
export const runCustomQuery = (sql, max_rows = 500, serverId = 0) =>
  api.post('/query/run', { sql, max_rows, server_id: serverId })

// ── Chat ──────────────────────────────────────────────────────────────────────
// Compatibility shim — older DbaChat.jsx versions import askChat from here.
// Current DbaChat.jsx has its own internal axios instance so this won't conflict.
export const askChat = (messages, context = {}) =>
  api.post('/chat/ask', { messages, context })
