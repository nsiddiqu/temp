import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 15000,
})

api.interceptors.response.use(
  (res) => res.data,
  (err) => {
    const detail = err.response?.data?.detail
    let message = 'Unknown error'

    if (typeof detail === 'string') {
      message = detail
    } else if (Array.isArray(detail)) {
      // FastAPI 422 returns array of validation errors
      message = detail.map(e => `${e.loc?.join('.')} — ${e.msg}`).join(', ')
    } else if (detail) {
      message = JSON.stringify(detail)
    } else {
      message = err.message || 'Unknown error'
    }

    return Promise.reject(new Error(message))
  }
)

export const fetchHealthMetrics  = ()                        => api.get('/health/metrics')
export const fetchPing            = ()                        => api.get('/health/ping')
export const fetchSessions        = ()                        => api.get('/sessions/')
export const fetchBlockers        = ()                        => api.get('/sessions/blockers')
export const fetchLongRunning     = (threshold = 30)         => api.get(`/sessions/long-running?threshold=${threshold}`)
export const runCustomQuery       = (sql, max_rows = 500)    => api.post('/query/run', { sql, max_rows })
// Make sure it looks exactly like this:
export const askChat = (sid, question, max_rows = 50) =>   api.post('/chat/ask', { server_id: sid, question, max_rows })